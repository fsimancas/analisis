"""
Módulo de Bitácora de Predicciones y Evaluación Walk-Forward (FAIS Ledger).
Registra predicciones con trazabilidad temporal inmutable para posterior
auditoría de rendimiento, Brier Score, Log-Loss y Retorno de Inversión (ROI).
"""

from .ledger_manager import PredictionLedger

__all__ = ["PredictionLedger"]
