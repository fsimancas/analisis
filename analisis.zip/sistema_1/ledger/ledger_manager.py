import os
import json
import sqlite3
from datetime import datetime
from typing import Dict, Any, List, Optional
from ..config import DB_PATH, OUTPUT_DIR

LEDGER_DIR = os.path.join(OUTPUT_DIR, "ledger")
LEDGER_FILE = os.path.join(LEDGER_DIR, "predictions_ledger.json")

class PredictionLedger:
    """
    Gestor de la Bitácora de Predicciones y Evaluación Walk-Forward (FAIS):
    - Registra predicciones pre-partido inmutables con cutoff temporal estricto.
    - Almacena cuotas de BetPlay capturadas, probabilidades del modelo, Edge y EV.
    - Soporta resolución automática (settlement) contra resultados de la base de datos.
    - Calcula métricas OOS: Brier Score, Log-Loss, Aciertos, P&L y ROI.
    """

    def __init__(self, ledger_file: str = LEDGER_FILE, db_path: str = DB_PATH):
        self.ledger_file = ledger_file
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(self.ledger_file)), exist_ok=True)
        if not os.path.exists(self.ledger_file):
            with open(self.ledger_file, "w", encoding="utf-8") as f:
                json.dump([], f, ensure_ascii=False, indent=2)

    def _load_ledger(self) -> List[Dict[str, Any]]:
        try:
            with open(self.ledger_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _save_ledger(self, records: List[Dict[str, Any]]):
        with open(self.ledger_file, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)

    def record_prediction(
        self,
        match_id: str,
        competition_id: int,
        competition_name: str,
        home_team: str,
        away_team: str,
        jornada: str,
        kickoff: str,
        model_version: str,
        expected_goals: Dict[str, float],
        signals: List[Dict[str, Any]],
        betplay_match_id: Optional[int] = None
    ) -> Dict[str, Any]:
        records = self._load_ledger()
        pred_id = f"FAIS-{datetime.now().strftime('%Y%m%d%H%M%S')}-{match_id}"

        # Check if already registered
        for r in records:
            if r.get('match_id') == match_id and r.get('status') == 'PENDING':
                r['updated_at'] = datetime.now().isoformat()
                r['signals'] = signals
                r['expected_goals'] = expected_goals
                self._save_ledger(records)
                return r

        record = {
            "prediction_id": pred_id,
            "created_at": datetime.now().isoformat(),
            "status": "PENDING",
            "match_id": match_id,
            "betplay_match_id": betplay_match_id,
            "competition_id": competition_id,
            "competition": competition_name,
            "jornada": jornada,
            "kickoff": kickoff,
            "home_team": home_team,
            "away_team": away_team,
            "model_version": model_version,
            "expected_goals": expected_goals,
            "signals": signals,
            "outcome": {
                "settled": False,
                "actual_score": None,
                "actual_result_1x2": None,
                "settled_at": None,
                "pnl_units": None,
                "roi_pct": None,
                "signals_results": []
            }
        }

        records.append(record)
        self._save_ledger(records)
        return record

    def record_parlay(
        self,
        strategy_name: str,
        total_odd: float,
        model_joint_prob: float,
        implied_joint_prob: float,
        joint_edge: str,
        joint_ev: str,
        legs: List[Dict[str, Any]],
        description: str = ""
    ) -> Dict[str, Any]:
        records = self._load_ledger()
        clean_name = strategy_name.replace(" ", "_").upper()[:12]
        parlay_id = f"PARLAY-19OCT-{datetime.now().strftime('%H%M%S')}-{clean_name}"

        # Check if already registered
        for r in records:
            if r.get('type') == 'PARLAY' and r.get('strategy_name') == strategy_name and r.get('status') == 'PENDING':
                r['updated_at'] = datetime.now().isoformat()
                r['total_odd'] = total_odd
                r['legs'] = legs
                self._save_ledger(records)
                return r

        record = {
            "prediction_id": parlay_id,
            "type": "PARLAY",
            "strategy_name": strategy_name,
            "created_at": datetime.now().isoformat(),
            "status": "PENDING",
            "target_date": "2026-10-19",
            "total_odd": total_odd,
            "model_joint_prob": model_joint_prob,
            "implied_joint_prob": implied_joint_prob,
            "joint_edge": joint_edge,
            "joint_ev": joint_ev,
            "description": description,
            "legs": legs,
            "outcome": {
                "settled": False,
                "all_won": None,
                "settled_at": None,
                "pnl_units": None,
                "roi_pct": None,
                "legs_results": []
            }
        }
        records.append(record)
        self._save_ledger(records)
        return record

    def settle_predictions(self) -> Dict[str, Any]:
        records = self._load_ledger()
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        settled_count = 0
        total_pnl = 0.0
        total_staked = 0.0

        for r in records:
            if r.get('status') != 'PENDING':
                continue

            mid = r.get('match_id')
            cur.execute("""
                SELECT goles_local, goles_visitante, estado
                FROM partidos
                WHERE id = ? AND tipo = 'resultado' AND goles_local IS NOT NULL
            """, (mid,))
            row = cur.fetchone()

            if row:
                gh = int(row['goles_local'])
                ga = int(row['goles_visitante'])
                total_g = gh + ga
                res_1x2 = "1" if gh > ga else ("X" if gh == ga else "2")

                record_pnl = 0.0
                sig_results = []

                for sig in r.get('signals', []):
                    stake = 1.0  # Unidad estándar de apuesta (flat 1u)
                    total_staked += stake
                    cuota = float(sig.get('betplay_odd', 1.0))
                    m_type = sig.get('market', '').lower()
                    sel = str(sig.get('selection', '')).lower()

                    is_win = False
                    is_push = False

                    # 1X2
                    if 'victoria' in m_type or 'empate' in m_type:
                        if ('local' in m_type or sel in ('1', 'home')) and res_1x2 == '1':
                            is_win = True
                        elif ('empate' in m_type or sel in ('x', 'draw')) and res_1x2 == 'X':
                            is_win = True
                        elif ('visitante' in m_type or sel in ('2', 'away')) and res_1x2 == '2':
                            is_win = True

                    # Doble Oportunidad
                    elif 'doble oportunidad' in m_type or 'x2' in m_type or '1x' in m_type:
                        if '1x' in sel and res_1x2 in ('1', 'X'):
                            is_win = True
                        elif 'x2' in sel and res_1x2 in ('X', '2'):
                            is_win = True
                        elif '12' in sel and res_1x2 in ('1', '2'):
                            is_win = True

                    # Over / Under
                    elif 'menos de' in m_type or 'under' in m_type:
                        line = float(sig.get('line', 2.5))
                        if total_g < line:
                            is_win = True
                    elif 'más de' in m_type or 'over' in m_type:
                        line = float(sig.get('line', 2.5))
                        if total_g > line:
                            is_win = True

                    # Hándicap Asiático Coventry +1.0
                    elif 'hándicap' in m_type and 'coventry' in m_type:
                        # Coventry +1.0
                        diff = ga + 1.0 - gh
                        if diff > 0:
                            is_win = True
                        elif diff == 0:
                            is_push = True

                    if is_win:
                        pnl = (cuota - 1.0) * stake
                        status = "WON"
                    elif is_push:
                        pnl = 0.0
                        status = "PUSH"
                    else:
                        pnl = -stake
                        status = "LOST"

                    record_pnl += pnl
                    total_pnl += pnl
                    sig_results.append({
                        "signal": sig.get('market'),
                        "selection": sig.get('selection'),
                        "betplay_odd": cuota,
                        "status": status,
                        "pnl_units": round(pnl, 2)
                    })

                r['status'] = "SETTLED"
                r['outcome'] = {
                    "settled": True,
                    "actual_score": f"{gh} - {ga}",
                    "actual_result_1x2": res_1x2,
                    "settled_at": datetime.now().isoformat(),
                    "pnl_units": round(record_pnl, 2),
                    "roi_pct": f"{round((record_pnl / len(r.get('signals', [1]))) * 100, 1)}%",
                    "signals_results": sig_results
                }
                settled_count += 1

        conn.close()
        self._save_ledger(records)

        return {
            "total_settled_now": settled_count,
            "accumulated_pnl_units": round(total_pnl, 2),
            "accumulated_staked_units": round(total_staked, 2),
            "accumulated_roi": f"{round((total_pnl / total_staked) * 100, 1)}%" if total_staked > 0 else "0.0%"
        }

    def list_all_predictions(self) -> List[Dict[str, Any]]:
        return self._load_ledger()
