from typing import Dict, Any, List

class ProfileVisualizer:
    """
    Renderiza en consola el perfil táctico y contextual completo de un equipo.
    """

    @staticmethod
    def render(profile: Dict[str, Any]) -> str:
        lines = []
        team = profile.get("team", "Equipo")
        comp = profile.get("competition", {}).get("nombre_flashscore", "Liga")
        style = profile.get("tactical_style", {})
        gs = profile.get("game_state_dynamics", {})
        pers = profile.get("personnel_and_lineups", {})
        env = profile.get("environmental_and_referee_context", {})
        ti = profile.get("next_match_table_impact", {})

        in_pos = style.get("in_possession", {})
        out_pos = style.get("out_of_possession", {})
        disc = style.get("discipline", {})

        lines.append("=" * 88)
        lines.append(f" PERFIL TÁCTICO Y CONTEXTUAL DE EQUIPO: {team.upper()} ({comp.upper()})")
        lines.append(f" Entrenador: {pers.get('manager', 'N/A')} | Partidos analizados: {style.get('matches_analyzed', 0)}")
        lines.append("=" * 88)

        # 1. Tactical Style
        lines.append("\n[1] SISTEMA DE JUEGO Y ESTILO TÁCTICO:")
        lines.append("  -- CON BALÓN (Fase Ofensiva) --")
        lines.append(f"  * Posesión promedio:            {in_pos.get('average_possession_pct', 'N/A')}")
        lines.append(f"  * Goles Esperados (xG) / partido: {in_pos.get('avg_xg_for', 0.0)}")
        lines.append(f"  * Remates totales / a puerta:   {in_pos.get('avg_shots_per_match', 0.0)} / {in_pos.get('avg_shots_on_target', 0.0)}")
        lines.append(f"  * Tiros dentro del área / Tasa: {in_pos.get('avg_shots_inside_box', 0.0)} ({in_pos.get('box_penetration_rate', 'N/A')})")
        lines.append(f"  * Grandes ocasiones generadas:  {in_pos.get('avg_big_chances_created', 0.0)}")
        lines.append(f"  * Pases por partido / Precisión:{in_pos.get('avg_passes_per_match', 0.0)} ({in_pos.get('passing_accuracy_pct', 'N/A')})")

        lines.append("\n  -- SIN BALÓN (Fase Defensiva y Recuperación) --")
        lines.append(f"  * xG concedido por partido:     {out_pos.get('avg_xg_conceded', 0.0)}")
        lines.append(f"  * Grandes ocasiones concedidas: {out_pos.get('avg_big_chances_conceded', 0.0)}")
        lines.append(f"  * Duelos ganados por partido:   {out_pos.get('avg_duels_won_per_match', 0.0)}")
        lines.append(f"  * Entradas / Intercepciones:    {out_pos.get('avg_tackles_per_match', 0.0)} / {out_pos.get('avg_interceptions_per_match', 0.0)}")
        lines.append(f"  * Despejes por partido:         {out_pos.get('avg_clearances_per_match', 0.0)}")
        lines.append(f"  * Errores que causaron gol:     {out_pos.get('errors_leading_to_goal', 0)}")
        lines.append(f"  * Faltas / Amarillas / Rojas:   {disc.get('avg_fouls_per_match', 0.0)} / {disc.get('total_yellow_cards', 0)} / {disc.get('total_red_cards', 0)}")

        # 2. Game-State Dynamics
        td = gs.get("time_distribution", {})
        wl = gs.get("when_leading", {})
        wt = gs.get("when_tied", {})
        wtr = gs.get("when_trailing", {})

        lines.append("\n" + "-" * 88)
        lines.append("[2] DINÁMICA POR ESTADOS DE JUEGO (GAME-STATE SPLITS):")
        lines.append(f"  * Tiempo en el partido:          Ganando: {td.get('leading_duration_pct', '0%')} | Empatando: {td.get('tied_duration_pct', '0%')} | Perdiendo: {td.get('trailing_duration_pct', '0%')}")
        lines.append(f"  * CUANDO VA GANANDO:            Capacidad de cierre (Lead Defending): {wl.get('lead_defending_rate', '0%')}")
        lines.append(f"                                  Goles a favor / en contra con ventaja: {wl.get('goals_scored_while_leading', 0)} / {wl.get('goals_conceded_while_leading', 0)}")
        lines.append(f"  * CUANDO ESTÁ EMPATANDO:        Minuto promedio 1er gol anotado: {wt.get('avg_minute_first_goal_scored', 'N/A')}")
        lines.append(f"                                  Minuto promedio 1er gol recibido: {wt.get('avg_minute_first_goal_conceded', 'N/A')}")
        lines.append(f"  * CUANDO VA PERDIENDO:          Tasa de empate/reacción: {wtr.get('equalizing_rate', '0%')} | Remontadas: {wtr.get('comeback_win_rate', '0%')}")
        lines.append(f"                                  Goles a favor / en contra en desventaja: {wtr.get('goals_scored_while_trailing', 0)} / {wtr.get('goals_conceded_while_trailing', 0)}")

        # 3. Formations & Lineups
        lines.append("\n" + "-" * 88)
        lines.append("[3] FORMACIONES, ONCE RECURRENTE Y RELEVOS:")
        forms = [f"{f['formation']} ({f['percentage']})" for f in pers.get("tactical_formations", [])]
        lines.append(f"  * Formaciones utilizadas:       {', '.join(forms) if forms else 'N/A'}")

        top11 = pers.get("recurring_starting_xi", [])
        if top11:
            lines.append("  * Once Inicial Tipo (Más titulares):")
            xi_str = ", ".join([f"#{p['dorsal']} {p['player']} ({p['starts_pct']})" for p in top11[:11]])
            lines.append(f"    {xi_str}")

        subs = pers.get("substitution_patterns", {})
        revs = [f"{r['player']} ({r['times_subbed_in']})" for r in subs.get("most_frequent_substitutes_in", [])]
        lines.append(f"  * Ventana de cambios:           Minuto promedio {subs.get('average_substitution_minute', '65\'')}")
        lines.append(f"  * Revulsivos habituales:        {', '.join(revs) if revs else 'N/A'}")

        absences = pers.get("recent_absences_and_injuries", [])
        if absences:
            lines.append("\n  -- Bajas y Ausencias Recientes --")
            for ab in absences:
                lines.append(f"    - #{ab.get('dorsal', '-')} {ab.get('player')}: {ab.get('reason')} ({ab.get('last_reported_match')})")
        else:
            lines.append("  * Bajas recientes:              Sin ausencias reportadas")

        # 4. Environment & Referee
        lines.append("\n" + "-" * 88)
        lines.append("[4] CONTEXTO AMBIENTAL Y CUERPO ARBITRAL:")
        lines.append(f"  * Estadio habitual:             {env.get('stadium', 'N/A')}")
        lines.append(f"  * Superficie del césped:        {env.get('pitch_surface', 'N/A')}")
        lines.append(f"  * Temperatura media en juego:   {env.get('avg_temperature_celsius', 'N/A')}")

        refs = env.get("referees_history", [])
        if refs:
            lines.append("  * Historial con Árbitros:")
            for r in refs[:3]:
                lines.append(f"    - {r['referee']}: {r['matches_officiated']} partidos | {r['avg_yellow_cards_per_match']} amarillas/p | {r['avg_fouls_per_match']} faltas/p")

        # 5. Next Match Table Impact
        if ti and ti.get("next_fixture"):
            nf = ti["next_fixture"]
            sc = ti.get("scenarios", {})
            lines.append("\n" + "-" * 88)
            lines.append(f"[5] IMPACTO EN TABLA (WHAT-IF PRÓXIMO PARTIDO: vs {nf.get('opponent')} - {nf.get('condition').upper()}):")
            lines.append(f"  * SI GANA:   {sc.get('win', {}).get('summary')}")
            lines.append(f"  * SI EMPATA: {sc.get('draw', {}).get('summary')}")
            lines.append(f"  * SI PIERDE: {sc.get('loss', {}).get('summary')}")

        lines.append("=" * 88)
        return "\n".join(lines)
