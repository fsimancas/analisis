import re
from typing import List, Dict, Any

def parse_minute(min_str: Any) -> int:
    if not min_str:
        return 90
    m = re.search(r'(\d+)(?:\+(\d+))?', str(min_str))
    if m:
        base = int(m.group(1))
        extra = int(m.group(2)) if m.group(2) else 0
        return base + extra
    return 90

class GameStateProfiler:
    """
    Calcula el comportamiento de un equipo según el estado del marcador en vivo:
    - Ganando (Leading): minutos en ventaja, goles anotados/recibidos, capacidad de cierre (lead defending).
    - Empatando (Level / Tied): minutos en empate, minutos hasta el primer gol anotado o encajado.
    - Perdiendo (Trailing): minutos en desventaja, capacidad de reacción (equalizing rate / comeback).
    """

    @staticmethod
    def calculate(
        team_name: str,
        matches: List[Dict[str, Any]],
        match_incidents_by_id: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        team_matches = [m for m in matches if m['equipo_local'] == team_name or m['equipo_visitante'] == team_name]
        gp = len(team_matches)
        if gp == 0:
            return {}

        total_match_minutes = gp * 90
        mins_leading = 0
        mins_tied = 0
        mins_trailing = 0

        # Goals in state
        goals_for_when_leading = 0
        goals_against_when_leading = 0

        goals_for_when_tied = 0
        goals_against_when_tied = 0

        goals_for_when_trailing = 0
        goals_against_when_trailing = 0

        # Lead defense & comeback rates
        matches_with_lead = 0
        matches_won_after_lead = 0

        matches_trailed = 0
        matches_equalized = 0
        matches_comeback_win = 0

        first_goal_scored_minutes = []
        first_goal_conceded_minutes = []

        for m in team_matches:
            mid = m['id']
            is_home = (m['equipo_local'] == team_name)
            gh = int(m['goles_local'])
            ga = int(m['goles_visitante'])

            team_final = gh if is_home else ga
            opp_final = ga if is_home else gh

            incs = match_incidents_by_id.get(mid, [])
            # Extract goals chronologically
            goals = []
            for inc in incs:
                tipo = str(inc.get('tipo', ''))
                nota = str(inc.get('nota', ''))
                equipo = inc.get('equipo', '')

                is_goal = False
                if tipo in ('Gol', 'Gol en propia puerta'):
                    is_goal = True
                elif tipo == 'evento' and 'Tarjeta' not in nota and 'Sustitución' not in nota:
                    is_goal = True

                if is_goal and equipo in ('home', 'away'):
                    m_min = parse_minute(inc.get('minuto', ''))
                    goals.append((m_min, equipo))

            goals.sort(key=lambda x: x[0])

            # Did team take a lead at any point?
            had_lead = False
            had_trail = False

            curr_team = 0
            curr_opp = 0
            curr_m = 0

            # First goals
            scored_first_in_match = False
            conceded_first_in_match = False

            for gmin, geq in goals:
                dur = min(gmin, 90) - curr_m
                if dur > 0:
                    if curr_team > curr_opp:
                        mins_leading += dur
                    elif curr_opp > curr_team:
                        mins_trailing += dur
                    else:
                        mins_tied += dur

                curr_m = min(gmin, 90)

                # Track goal event in current state
                is_team_goal = (geq == 'home' and is_home) or (geq == 'away' and not is_home)

                # First goal recording
                if not scored_first_in_match and not conceded_first_in_match:
                    if is_team_goal:
                        first_goal_scored_minutes.append(gmin)
                        scored_first_in_match = True
                    else:
                        first_goal_conceded_minutes.append(gmin)
                        conceded_first_in_match = True

                # Goals by state
                if curr_team > curr_opp:
                    if is_team_goal:
                        goals_for_when_leading += 1
                    else:
                        goals_against_when_leading += 1
                elif curr_opp > curr_team:
                    if is_team_goal:
                        goals_for_when_trailing += 1
                    else:
                        goals_against_when_trailing += 1
                else:  # Tied
                    if is_team_goal:
                        goals_for_when_tied += 1
                    else:
                        goals_against_when_tied += 1

                # Update score
                if is_team_goal:
                    curr_team += 1
                else:
                    curr_opp += 1

                if curr_team > curr_opp:
                    had_lead = True
                if curr_opp > curr_team:
                    had_trail = True

            rem = 90 - curr_m
            if rem > 0:
                if curr_team > curr_opp:
                    mins_leading += rem
                elif curr_opp > curr_team:
                    mins_trailing += rem
                else:
                    mins_tied += rem

            # Evaluate match outcomes after lead or trailing
            if had_lead:
                matches_with_lead += 1
                if team_final > opp_final:
                    matches_won_after_lead += 1

            if had_trail:
                matches_trailed += 1
                if team_final >= opp_final:
                    matches_equalized += 1
                if team_final > opp_final:
                    matches_comeback_win += 1

        lead_defend_rate = round((matches_won_after_lead / matches_with_lead) * 100) if matches_with_lead > 0 else 0
        equalizing_rate = round((matches_equalized / matches_trailed) * 100) if matches_trailed > 0 else 0
        comeback_rate = round((matches_comeback_win / matches_trailed) * 100) if matches_trailed > 0 else 0

        avg_first_scored = round(sum(first_goal_scored_minutes) / len(first_goal_scored_minutes)) if first_goal_scored_minutes else 0
        avg_first_conceded = round(sum(first_goal_conceded_minutes) / len(first_goal_conceded_minutes)) if first_goal_conceded_minutes else 0

        return {
            "time_distribution": {
                "leading_duration_pct": f"{round((mins_leading / total_match_minutes) * 100)}%",
                "tied_duration_pct": f"{round((mins_tied / total_match_minutes) * 100)}%",
                "trailing_duration_pct": f"{round((mins_trailing / total_match_minutes) * 100)}%",
                "total_minutes_leading": mins_leading,
                "total_minutes_tied": mins_tied,
                "total_minutes_trailing": mins_trailing
            },
            "when_leading": {
                "matches_held_lead": matches_with_lead,
                "lead_defending_rate": f"{lead_defend_rate}%",
                "goals_scored_while_leading": goals_for_when_leading,
                "goals_conceded_while_leading": goals_against_when_leading
            },
            "when_tied": {
                "goals_scored_to_break_tie": goals_for_when_tied,
                "goals_conceded_to_break_tie": goals_against_when_tied,
                "avg_minute_first_goal_scored": f"{avg_first_scored} min." if avg_first_scored else "N/A",
                "avg_minute_first_goal_conceded": f"{avg_first_conceded} min." if avg_first_conceded else "N/A"
            },
            "when_trailing": {
                "matches_fallen_behind": matches_trailed,
                "equalizing_rate": f"{equalizing_rate}%",
                "comeback_win_rate": f"{comeback_rate}%",
                "goals_scored_while_trailing": goals_for_when_trailing,
                "goals_conceded_while_trailing": goals_against_when_trailing
            }
        }
