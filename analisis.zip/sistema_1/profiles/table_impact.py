import copy
from typing import List, Dict, Any, Optional

class TableImpactProfiler:
    """
    Simulador determinístico de impacto contextual en la tabla (What-If):
    Calcula exactamente qué pasa si el equipo Gana, Empata o Pierde su próximo partido:
    - Puntos resultantes
    - Puesto en la tabla (Rank)
    - Diferencia de goles (GD)
    - Máximos puntos posibles (MPP)
    - Desplazamiento en la tabla de 5 segmentos
    """

    @staticmethod
    def calculate(
        team_name: str,
        current_league_table: List[Dict[str, Any]],
        upcoming_matches: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        # Find next fixture for the team
        next_match = None
        for m in upcoming_matches:
            if m['equipo_local'] == team_name or m['equipo_visitante'] == team_name:
                next_match = m
                break

        if not next_match:
            return {
                "next_match": None,
                "message": "No se encontraron partidos próximos programados para este equipo."
            }

        is_home = (next_match['equipo_local'] == team_name)
        opponent = next_match['equipo_visitante'] if is_home else next_match['equipo_local']

        # Scenarios simulation: Win (+1 GD default), Draw (0 GD), Loss (-1 GD default)
        scenarios = {
            "win": {"pts_delta": 3, "gf_delta": 2, "ga_delta": 1, "w_delta": 1, "d_delta": 0, "l_delta": 0},
            "draw": {"pts_delta": 1, "gf_delta": 1, "ga_delta": 1, "w_delta": 0, "d_delta": 1, "l_delta": 0},
            "loss": {"pts_delta": 0, "gf_delta": 0, "ga_delta": 1, "w_delta": 0, "d_delta": 0, "l_delta": 1}
        }

        results_scenarios = {}

        for sc_name, deltas in scenarios.items():
            # Clone table
            sim_table = copy.deepcopy(current_league_table)
            team_row = None
            opp_row = None

            for row in sim_table:
                if row['team'] == team_name:
                    team_row = row
                elif row['team'] == opponent:
                    opp_row = row

            if not team_row:
                continue

            # Update team
            team_row['GP'] += 1
            team_row['W'] += deltas['w_delta']
            team_row['D'] += deltas['d_delta']
            team_row['L'] += deltas['l_delta']
            team_row['GF'] += deltas['gf_delta']
            team_row['GA'] += deltas['ga_delta']
            team_row['GD'] = team_row['GF'] - team_row['GA']
            team_row['Pts'] += deltas['pts_delta']
            team_row['PPG'] = round(team_row['Pts'] / team_row['GP'], 2)
            team_row['MPP'] = team_row['Pts'] + (3 * max(0, 38 - team_row['GP']))

            # Update opponent inversely
            if opp_row:
                opp_row['GP'] += 1
                opp_row['W'] += 1 if sc_name == 'loss' else 0
                opp_row['D'] += 1 if sc_name == 'draw' else 0
                opp_row['L'] += 1 if sc_name == 'win' else 0
                opp_row['GF'] += deltas['ga_delta']
                opp_row['GA'] += deltas['gf_delta']
                opp_row['GD'] = opp_row['GF'] - opp_row['GA']
                opp_row['Pts'] += 3 if sc_name == 'loss' else (1 if sc_name == 'draw' else 0)
                opp_row['PPG'] = round(opp_row['Pts'] / opp_row['GP'], 2)
                opp_row['MPP'] = opp_row['Pts'] + (3 * max(0, 38 - opp_row['GP']))

            # Re-rank table
            sim_table.sort(key=lambda x: (x['Pts'], x['GD'], x['GF']), reverse=True)
            new_rank = None
            for idx, r in enumerate(sim_table, start=1):
                if r['team'] == team_name:
                    new_rank = idx
                    break

            # Calculate segment
            leader_pts = sim_table[0]['Pts'] if sim_table else 1
            seg_width = leader_pts / 5.0
            p = team_row['Pts']
            if p <= seg_width:
                seg_name = "5th Segment"
            elif p <= seg_width * 2:
                seg_name = "4th Segment"
            elif p <= seg_width * 3:
                seg_name = "3rd Segment"
            elif p <= seg_width * 4:
                seg_name = "2nd Segment"
            else:
                seg_name = "1st Segment"

            results_scenarios[sc_name] = {
                "projected_rank": new_rank,
                "projected_points": team_row['Pts'],
                "projected_gd": f"{'+' if team_row['GD'] > 0 else ''}{team_row['GD']}",
                "projected_mpp": team_row['MPP'],
                "projected_segment": seg_name,
                "summary": f"Si {sc_name.upper()} quedaría en puesto #{new_rank} con {team_row['Pts']} pts (GD: {'+' if team_row['GD'] > 0 else ''}{team_row['GD']}, {seg_name})."
            }

        return {
            "next_fixture": {
                "jornada": next_match.get('jornada', ''),
                "fecha_hora": next_match.get('fecha_hora', ''),
                "condition": "home" if is_home else "away",
                "opponent": opponent,
                "home_team": next_match.get('equipo_local'),
                "away_team": next_match.get('equipo_visitante')
            },
            "scenarios": results_scenarios
        }
