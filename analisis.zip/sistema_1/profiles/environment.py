from typing import List, Dict, Any
from collections import defaultdict

class EnvironmentProfiler:
    """
    Calcula el perfil ambiental, del estadio y del cuerpo arbitral:
    - Perfil arbitral (árbitros asignados, tarjetas amarillas/rojas, faltas promedio)
    - Condiciones del estadio (superficie del césped, aforo, temperatura promedio)
    """

    @staticmethod
    def calculate(
        team_name: str,
        fotmob_matches_for_team: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        if not fotmob_matches_for_team:
            return {
                "stadium": "No disponible",
                "pitch_surface": "grass (césped natural estándar)",
                "avg_temperature_celsius": "N/A",
                "referees_history": []
            }

        stadiums = []
        surfaces = []
        temperatures = []
        referees = defaultdict(lambda: {"matches": 0, "yellow_cards": 0.0, "red_cards": 0, "fouls": 0.0})

        for m in fotmob_matches_for_team:
            estadio = m.get('estadio_nombre')
            superficie = m.get('estadio_superficie')
            temp = m.get('clima_temperatura')
            ref = m.get('arbitro_nombre')

            if estadio:
                stadiums.append(estadio)
            if superficie:
                surfaces.append(superficie)
            if temp is not None:
                try:
                    temperatures.append(float(temp))
                except ValueError:
                    pass

            if ref:
                r_entry = referees[ref]
                r_entry["matches"] += 1
                try:
                    if m.get('arbitro_amarillas_partido') is not None:
                        r_entry["yellow_cards"] = float(m.get('arbitro_amarillas_partido'))
                    if m.get('arbitro_rojas_total') is not None:
                        r_entry["red_cards"] = int(m.get('arbitro_rojas_total'))
                    if m.get('arbitro_faltas_partido') is not None:
                        r_entry["fouls"] = float(m.get('arbitro_faltas_partido'))
                except (ValueError, TypeError):
                    pass

        main_stadium = max(set(stadiums), key=stadiums.count) if stadiums else "Estadio principal"
        main_surface = max(set(surfaces), key=surfaces.count) if surfaces else "grass"
        avg_temp = round(sum(temperatures) / len(temperatures), 1) if temperatures else None

        referee_summary = [
            {
                "referee": ref,
                "matches_officiated": data["matches"],
                "avg_yellow_cards_per_match": round(data["yellow_cards"], 1),
                "total_red_cards": data["red_cards"],
                "avg_fouls_per_match": round(data["fouls"], 1)
            }
            for ref, data in sorted(referees.items(), key=lambda x: x[1]["matches"], reverse=True)
        ]

        return {
            "stadium": main_stadium,
            "pitch_surface": f"{main_surface} (césped natural)" if main_surface == 'grass' else main_surface,
            "avg_temperature_celsius": f"{avg_temp} °C" if avg_temp is not None else "21.0 °C",
            "referees_history": referee_summary
        }
