import os
import json
import sqlite3
from typing import Dict, Any, List, Optional

from ..db import Database, clean_team_name
from ..config import DB_PATH, OUTPUT_DIR
from ..engine.standings_calc import StandingsCalculator
from .team_style import TeamStyleProfiler
from .game_state import GameStateProfiler
from .personnel import PersonnelProfiler
from .environment import EnvironmentProfiler
from .table_impact import TableImpactProfiler

class TeamProfileEngine:
    """
    Motor integral de generación de perfiles tácticos y contextuales para equipos y jugadores.
    Combina:
    - Estilo táctico (posesión, tiros, xG, pases, duelos, errores)
    - Estados de juego (ganando, empatando, perdiendo y tiempos de reacción)
    - Personal y alineaciones (once recurrente, sustituciones típicas, ausencias y bajas)
    - Contexto ambiental y arbitral (árbitros, tarjetas, césped, temperatura)
    - Impacto determinístico en la tabla (What-If del próximo partido)
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db = Database(db_path)
        self.db_path = db_path

    def close(self):
        self.db.close()

    def _fetch_team_data(self, comp_id: int, team_name: str) -> Dict[str, Any]:
        conn = self.db.connect()
        cur = conn.cursor()

        # 1. Matches
        results = self.db.get_completed_matches(comp_id)
        upcoming = self.db.get_upcoming_matches(comp_id)

        # Filter matches where team participated
        team_results = [m for m in results if m['equipo_local'] == team_name or m['equipo_visitante'] == team_name]
        match_ids = [m['id'] for m in team_results]

        if not match_ids:
            return {
                "results": results,
                "upcoming": upcoming,
                "team_results": [],
                "details": {},
                "lineups": {},
                "stats": {},
                "incidents": {},
                "fotmob": []
            }

        placeholders = ",".join("?" * len(match_ids))

        # 2. Match Details (Tactical system, coach)
        cur.execute(f"""
            SELECT partido_id, sistema_local, sistema_visitante, entrenador_local, entrenador_visitante, rating_medio_local, rating_medio_visitante
            FROM partidos_detalles
            WHERE partido_id IN ({placeholders})
        """, match_ids)
        details_by_id = {r['partido_id']: dict(r) for r in cur.fetchall()}

        # 3. Lineups (Rosters, starting XI, subs, absences)
        cur.execute(f"""
            SELECT partido_id, equipo, rol, dorsal, nombre, posicion, calificacion, minuto_salida, motivo_ausencia
            FROM partidos_alineaciones
            WHERE partido_id IN ({placeholders})
        """, match_ids)
        lineups_by_id: Dict[str, List[Dict[str, Any]]] = {mid: [] for mid in match_ids}
        for r in cur.fetchall():
            lineups_by_id[r['partido_id']].append(dict(r))

        # 4. Tactical Stats (Possession, xG, shots, duels)
        cur.execute(f"""
            SELECT partido_id, periodo, seccion, metrica, valor_local, valor_visitante
            FROM partidos_estadisticas
            WHERE partido_id IN ({placeholders})
        """, match_ids)
        stats_by_id: Dict[str, List[Dict[str, Any]]] = {mid: [] for mid in match_ids}
        for r in cur.fetchall():
            stats_by_id[r['partido_id']].append(dict(r))

        # 5. Incidents (Goals, cards, substitution minutes)
        cur.execute(f"""
            SELECT partido_id, periodo, minuto, equipo, tipo, jugador, jugador_sale, nota
            FROM partidos_incidentes
            WHERE partido_id IN ({placeholders})
            ORDER BY partido_id, rowid ASC
        """, match_ids)
        incidents_by_id: Dict[str, List[Dict[str, Any]]] = {mid: [] for mid in match_ids}
        for r in cur.fetchall():
            incidents_by_id[r['partido_id']].append(dict(r))

        # 6. FotMob Match Details (Referee, Pitch, Temperature)
        cur.execute("""
            SELECT fd.match_id, fp.home_team_name, fp.away_team_name, fd.arbitro_nombre,
                   fd.arbitro_amarillas_partido, fd.arbitro_rojas_total, fd.arbitro_faltas_partido,
                   fd.estadio_nombre, fd.estadio_superficie, fd.clima_temperatura, fd.xg_local, fd.xg_visitante
            FROM fotmob_detalles_partido fd
            JOIN fotmob_partidos fp ON fd.match_id = fp.match_id
            WHERE fp.fotmob_league_id = 87 AND (fp.home_team_name LIKE ? OR fp.away_team_name LIKE ?)
        """, (f"%{team_name}%", f"%{team_name}%"))
        fotmob_matches = [dict(r) for r in cur.fetchall()]

        return {
            "results": results,
            "upcoming": upcoming,
            "team_results": team_results,
            "details": details_by_id,
            "lineups": lineups_by_id,
            "stats": stats_by_id,
            "incidents": incidents_by_id,
            "fotmob": fotmob_matches
        }

    def generate_profile(self, team_name: str, comp_id: int = 84) -> Dict[str, Any]:
        comp_info = self.db.get_competition(comp_id)
        team_name = clean_team_name(team_name)
        data = self._fetch_team_data(comp_id, team_name)

        if not data["team_results"]:
            return {
                "team": team_name,
                "error": f"No se encontraron partidos jugados para el equipo '{team_name}' en competición ID {comp_id}."
            }

        # 1. Tactical Style Profile (In/Out possession)
        style_profile = TeamStyleProfiler.calculate(team_name, data["team_results"], data["stats"])

        # 2. Game-State Splits Profile (Leading, Tied, Trailing)
        gamestate_profile = GameStateProfiler.calculate(team_name, data["team_results"], data["incidents"])

        # 3. Personnel Profile (Lineups, Formations, Subs, Absences)
        personnel_profile = PersonnelProfiler.calculate(
            team_name,
            data["team_results"],
            data["details"],
            data["lineups"],
            data["incidents"]
        )

        # 4. Environment & Referee Profile
        environment_profile = EnvironmentProfiler.calculate(team_name, data["fotmob"])

        # 5. Table Impact (What-If Standings Simulator)
        league_table, _, _ = StandingsCalculator.calculate(data["results"], data["upcoming"])
        table_impact = TableImpactProfiler.calculate(team_name, league_table, data["upcoming"])

        profile = {
            "competition": comp_info,
            "team": team_name,
            "tactical_style": style_profile,
            "game_state_dynamics": gamestate_profile,
            "personnel_and_lineups": personnel_profile,
            "environmental_and_referee_context": environment_profile,
            "next_match_table_impact": table_impact
        }

        return profile

    def export_profile_json(self, profile: Dict[str, Any], output_path: Optional[str] = None) -> str:
        team_slug = profile.get("team", "equipo").lower().replace(" ", "_")
        if not output_path:
            out_dir = os.path.join(OUTPUT_DIR, "profiles")
            os.makedirs(out_dir, exist_ok=True)
            output_path = os.path.join(out_dir, f"perfil_{team_slug}.json")
        else:
            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(profile, f, ensure_ascii=False, indent=2)

        return output_path
