"""
Motor de Perfiles Tácticos y Contextuales de FAIS (Sistema 1).
Provee análisis de estilo táctico (con y sin balón), estados de juego,
alineaciones y ausencias, perfiles ambientales/arbitrales e impacto en tabla.
"""

from .engine import TeamProfileEngine

__all__ = ["TeamProfileEngine"]
