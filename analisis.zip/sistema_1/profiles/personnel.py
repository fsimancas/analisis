import re
from typing import List, Dict, Any
from collections import Counter, defaultdict

class PersonnelProfiler:
    """
    Calcula el perfil de personal, formaciones, alineaciones y ausencias de un equipo:
    - Formaciones tácticas recurrentes (ej. 4-3-3, 4-2-3-1)
    - Once inicial tipo (Starting XI más recurrente con calificaciones medias)
    - Patrones de sustitución (minutos promedio de cambios, jugadores revulsivos habituales)
    - Ausencias y bajas actuales (lesionados, sancionados y su motivo específico)
    """

    @staticmethod
    def calculate(
        team_name: str,
        matches: List[Dict[str, Any]],
        match_details_by_id: Dict[str, Dict[str, Any]],
        match_lineups_by_id: Dict[str, List[Dict[str, Any]]],
        match_incidents_by_id: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        team_matches = [m for m in matches if m['equipo_local'] == team_name or m['equipo_visitante'] == team_name]
        gp = len(team_matches)
        if gp == 0:
            return {}

        # 1. Formaciones tácticas recurrentes
        formations = []
        coaches = []
        for m in team_matches:
            mid = m['id']
            is_home = (m['equipo_local'] == team_name)
            det = match_details_by_id.get(mid, {})
            sys_val = det.get('sistema_local') if is_home else det.get('sistema_visitante')
            coach_val = det.get('entrenador_local') if is_home else det.get('entrenador_visitante')
            if sys_val:
                formations.append(sys_val.strip())
            if coach_val:
                coaches.append(coach_val.strip())

        form_counter = Counter(formations)
        top_formations = [
            {"formation": f, "matches": count, "percentage": f"{round((count / gp) * 100)}%"}
            for f, count in form_counter.most_common(3)
        ]

        main_coach = Counter(coaches).most_common(1)[0][0] if coaches else "Desconocido"

        # 2. Once inicial recurrente (Starting XI)
        player_starts = Counter()
        player_sub_ins = Counter()
        player_ratings = defaultdict(list)
        player_positions = {}
        player_dorsals = {}

        # Ausencias registradas
        absences_map = {}

        for m in team_matches:
            mid = m['id']
            is_home = (m['equipo_local'] == team_name)
            team_venue = 'home' if is_home else 'away'
            lineups = match_lineups_by_id.get(mid, [])

            for p in lineups:
                if p.get('equipo') != team_venue:
                    continue

                pname = p.get('nombre', '').strip()
                if not pname:
                    continue

                rol = p.get('rol', '')
                dorsal = p.get('dorsal', '')
                pos = p.get('posicion', '')
                rating = p.get('calificacion')
                motivo = p.get('motivo_ausencia', '').strip()

                if dorsal:
                    player_dorsals[pname] = dorsal
                if pos:
                    player_positions[pname] = pos
                if rating is not None and isinstance(rating, (int, float)):
                    player_ratings[pname].append(float(rating))

                if rol == 'titular':
                    player_starts[pname] += 1
                elif rol == 'sustituido':
                    player_sub_ins[pname] += 1
                elif rol == 'ausente' or motivo:
                    absences_map[pname] = {
                        "player": pname,
                        "dorsal": dorsal or player_dorsals.get(pname, "-"),
                        "reason": motivo or "Baja no especificada",
                        "last_reported_match": m.get('jornada', '')
                    }

        # Top 11 Titulares recurrentes
        top_11 = []
        for pname, starts in player_starts.most_common(11):
            ratings = player_ratings.get(pname, [])
            avg_r = round(sum(ratings) / len(ratings), 2) if ratings else None
            top_11.append({
                "player": pname,
                "dorsal": player_dorsals.get(pname, "-"),
                "starts": starts,
                "starts_pct": f"{round((starts / gp) * 100)}%",
                "avg_rating": avg_r if avg_r is not None else "-"
            })

        # 3. Patrones de Sustituciones e Incidentes
        sub_in_counter = Counter()
        sub_out_counter = Counter()
        sub_minutes = []

        for m in team_matches:
            mid = m['id']
            is_home = (m['equipo_local'] == team_name)
            team_venue = 'home' if is_home else 'away'
            incs = match_incidents_by_id.get(mid, [])

            for inc in incs:
                if inc.get('equipo') != team_venue:
                    continue
                tipo = inc.get('tipo', '')
                p_in = inc.get('jugador', '').strip()
                p_out = inc.get('jugador_sale', '').strip()
                min_str = inc.get('minuto', '')

                if 'Sustitución' in tipo or p_out:
                    if p_in:
                        sub_in_counter[p_in] += 1
                    if p_out:
                        sub_out_counter[p_out] += 1
                    m_val = re.search(r'\d+', str(min_str))
                    if m_val:
                        sub_minutes.append(int(m_val.group()))

        avg_sub_min = round(sum(sub_minutes) / len(sub_minutes)) if sub_minutes else 65

        top_revulsivos = [
            {"player": p, "times_subbed_in": c}
            for p, c in sub_in_counter.most_common(4)
        ]
        top_sacrificados = [
            {"player": p, "times_subbed_out": c}
            for p, c in sub_out_counter.most_common(4)
        ]

        return {
            "manager": main_coach,
            "tactical_formations": top_formations,
            "recurring_starting_xi": top_11,
            "substitution_patterns": {
                "average_substitution_minute": f"{avg_sub_min}'",
                "most_frequent_substitutes_in": top_revulsivos,
                "most_frequent_substitutes_out": top_sacrificados
            },
            "recent_absences_and_injuries": list(absences_map.values())
        }
