import re
from typing import List, Dict, Any, Optional

def parse_num(val: Any) -> float:
    if val is None:
        return 0.0
    val_str = str(val).strip()
    # Check for percentage like '57%'
    m_pct = re.search(r'(\d+(?:\.\d+)?)%', val_str)
    # Check for pass fraction like '81%(412/506)' or '(412/506)'
    m_frac = re.search(r'\((\d+)/(\d+)\)', val_str)
    if m_frac:
        return float(m_frac.group(1))
    if m_pct:
        return float(m_pct.group(1))
    # Direct float or int
    m_num = re.search(r'[-+]?\d*\.?\d+', val_str)
    if m_num:
        try:
            return float(m_num.group())
        except ValueError:
            return 0.0
    return 0.0

class TeamStyleProfiler:
    """
    Calcula el perfil táctico de un equipo con y sin balón:
    - Posesión promedio (con balón)
    - Generación ofensiva (xG, tiros, tiros dentro del área, grandes ocasiones)
    - Volumen de pase y precisión
    - Perfil defensivo (duelos ganados, entradas, intercepciones, despejes)
    - Errores defensivos y disciplina (faltas, tarjetas)
    """

    @staticmethod
    def calculate(
        team_name: str,
        matches: List[Dict[str, Any]],
        match_stats_by_id: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        team_matches = [m for m in matches if m['equipo_local'] == team_name or m['equipo_visitante'] == team_name]
        gp = len(team_matches)
        if gp == 0:
            return {"error": f"No hay partidos registrados para {team_name}."}

        # Accumulators
        possession_list = []
        xg_for_list = []
        xg_against_list = []
        shots_total_list = []
        shots_on_target_list = []
        shots_inside_box_list = []
        big_chances_for_list = []
        big_chances_against_list = []
        passes_completed_list = []
        passes_total_list = []

        duels_won_list = []
        tackles_list = []
        interceptions_list = []
        clearances_list = []
        errors_goal_list = []
        fouls_list = []
        yellow_cards_list = []
        red_cards_list = []

        for m in team_matches:
            mid = m['id']
            is_home = (m['equipo_local'] == team_name)
            stats = match_stats_by_id.get(mid, [])

            for s in stats:
                metrica = s.get('metrica', '')
                seccion = s.get('seccion', '')
                val_team = s.get('valor_local') if is_home else s.get('valor_visitante')
                val_opp = s.get('valor_visitante') if is_home else s.get('valor_local')

                if metrica == 'Posesión':
                    possession_list.append(parse_num(val_team))
                elif metrica == 'Goles esperados (xG)' and seccion == 'Estadísticas principales':
                    xg_for_list.append(parse_num(val_team))
                    xg_against_list.append(parse_num(val_opp))
                elif metrica == 'Remates totales':
                    shots_total_list.append(parse_num(val_team))
                elif metrica == 'Remates a puerta':
                    shots_on_target_list.append(parse_num(val_team))
                elif metrica == 'Remates dentro del área':
                    shots_inside_box_list.append(parse_num(val_team))
                elif metrica == 'Grandes ocasiones':
                    big_chances_for_list.append(parse_num(val_team))
                    big_chances_against_list.append(parse_num(val_opp))
                elif metrica == 'Pases' and seccion == 'Estadísticas principales':
                    # Parse fraction like 81%(412/506)
                    val_str = str(val_team)
                    m_f = re.search(r'\((\d+)/(\d+)\)', val_str)
                    if m_f:
                        passes_completed_list.append(float(m_f.group(1)))
                        passes_total_list.append(float(m_f.group(2)))
                elif metrica == 'Duelos ganados':
                    duels_won_list.append(parse_num(val_team))
                elif metrica == 'Entradas':
                    tackles_list.append(parse_num(val_team))
                elif metrica == 'Intercepciones':
                    interceptions_list.append(parse_num(val_team))
                elif metrica == 'Despejes':
                    clearances_list.append(parse_num(val_team))
                elif metrica == 'Errores conducentes a gol':
                    errors_goal_list.append(parse_num(val_team))
                elif metrica == 'Faltas':
                    fouls_list.append(parse_num(val_team))
                elif metrica == 'Tarjetas amarillas':
                    yellow_cards_list.append(parse_num(val_team))
                elif metrica == 'Tarjetas rojas':
                    red_cards_list.append(parse_num(val_team))

        def safe_avg(lst: List[float], digits: int = 1) -> float:
            return round(sum(lst) / len(lst), digits) if lst else 0.0

        avg_poss = safe_avg(possession_list, 1)
        tot_passes = sum(passes_total_list)
        comp_passes = sum(passes_completed_list)
        pass_acc = round((comp_passes / tot_passes) * 100, 1) if tot_passes > 0 else 0.0

        return {
            "matches_analyzed": gp,
            "in_possession": {
                "average_possession_pct": f"{avg_poss}%",
                "avg_xg_for": safe_avg(xg_for_list, 2),
                "avg_shots_per_match": safe_avg(shots_total_list, 1),
                "avg_shots_on_target": safe_avg(shots_on_target_list, 1),
                "avg_shots_inside_box": safe_avg(shots_inside_box_list, 1),
                "box_penetration_rate": f"{round((safe_avg(shots_inside_box_list, 1) / max(safe_avg(shots_total_list, 1), 0.1)) * 100)}%",
                "avg_big_chances_created": safe_avg(big_chances_for_list, 1),
                "avg_passes_per_match": safe_avg(passes_total_list, 0),
                "passing_accuracy_pct": f"{pass_acc}%"
            },
            "out_of_possession": {
                "avg_xg_conceded": safe_avg(xg_against_list, 2),
                "avg_big_chances_conceded": safe_avg(big_chances_against_list, 1),
                "avg_duels_won_per_match": safe_avg(duels_won_list, 1),
                "avg_tackles_per_match": safe_avg(tackles_list, 1),
                "avg_interceptions_per_match": safe_avg(interceptions_list, 1),
                "avg_clearances_per_match": safe_avg(clearances_list, 1),
                "errors_leading_to_goal": int(sum(errors_goal_list))
            },
            "discipline": {
                "avg_fouls_per_match": safe_avg(fouls_list, 1),
                "total_yellow_cards": int(sum(yellow_cards_list)),
                "total_red_cards": int(sum(red_cards_list))
            }
        }
