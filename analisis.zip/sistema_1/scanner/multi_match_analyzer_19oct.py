import sqlite3
import math
import random
import re
import os
import sys
from typing import Dict, Any, List, Optional

DB_PATH = r"c:\Users\SIMANCAS\Documents\rey\betplay_flashscore.db"

def clean_team_name(name: str) -> str:
    if not name:
        return ""
    name = re.sub(r'GOL$', '', name.strip())
    name = re.sub(r'\s*\([A-Za-z0-9]+\)$', '', name)
    name = re.sub(r'\s*-\s*[A-Z]{2}$', '', name)  # e.g. Corinthians-SP -> Corinthians
    name = re.sub(r'\s*\(F\)$', '', name)
    return name.strip()

class MatchAnalyzer19Oct:
    def __init__(self, db_path: str = DB_PATH, n_sims: int = 10000):
        self.db_path = db_path
        self.n_sims = n_sims
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row

    def close(self):
        self.conn.close()

    def get_team_history(self, team_name: str) -> Dict[str, Any]:
        cur = self.conn.cursor()
        c_name = clean_team_name(team_name)
        cur.execute("""
            SELECT goles_local, goles_visitante, equipo_local, equipo_visitante
            FROM partidos
            WHERE tipo = 'resultado'
              AND (equipo_local LIKE ? OR equipo_visitante LIKE ?)
              AND goles_local IS NOT NULL
            ORDER BY id DESC
            LIMIT 25
        """, (f"%{c_name}%", f"%{c_name}%"))
        rows = cur.fetchall()

        if not rows:
            return {"sample": 0, "avg_scored": 1.25, "avg_conceded": 1.25}

        scored = []
        conceded = []
        for r in rows:
            gh = int(r['goles_local'])
            ga = int(r['goles_visitante'])
            if c_name.lower() in clean_team_name(r['equipo_local']).lower():
                scored.append(gh)
                conceded.append(ga)
            else:
                scored.append(ga)
                conceded.append(gh)

        return {
            "sample": len(scored),
            "avg_scored": sum(scored) / len(scored) if scored else 1.25,
            "avg_conceded": sum(conceded) / len(conceded) if conceded else 1.25
        }

    def simulate_match(self, home_team: str, away_team: str) -> Dict[str, Any]:
        h_hist = self.get_team_history(home_team)
        a_hist = self.get_team_history(away_team)

        # Baseline goals (2.60 total: 1.45 home / 1.15 away)
        base_h = 1.45
        base_a = 1.15
        league_team_avg = 1.30

        h_att = h_hist['avg_scored'] / league_team_avg if league_team_avg > 0 else 1.0
        a_def = a_hist['avg_conceded'] / league_team_avg if league_team_avg > 0 else 1.0

        a_att = a_hist['avg_scored'] / league_team_avg if league_team_avg > 0 else 1.0
        h_def = h_hist['avg_conceded'] / league_team_avg if league_team_avg > 0 else 1.0

        lambda_h = max(0.20, min(4.50, base_h * h_att * a_def))
        lambda_a = max(0.20, min(4.50, base_a * a_att * h_def))
        total_xg = lambda_h + lambda_a

        # 10,000 Monte Carlo simulations with Knuth Poisson
        h_wins, draws, a_wins = 0, 0, 0
        o05, o15, o25, o35 = 0, 0, 0, 0
        u15, u25, u35, u45 = 0, 0, 0, 0
        btts_y, btts_n = 0, 0
        dc_1x, dc_x2, dc_12 = 0, 0, 0

        score_counts = {}

        def _poiss(lamb):
            if lamb <= 0: return 0
            limit = math.exp(-lamb)
            k = 0
            p = 1.0
            while p > limit:
                k += 1
                p *= random.random()
            return k - 1

        for _ in range(self.n_sims):
            gh = _poiss(lambda_h)
            ga = _poiss(lambda_a)
            tot = gh + ga

            if gh > ga:
                h_wins += 1
                dc_1x += 1
                dc_12 += 1
            elif gh == ga:
                draws += 1
                dc_1x += 1
                dc_x2 += 1
            else:
                a_wins += 1
                dc_x2 += 1
                dc_12 += 1

            if tot > 0.5: o05 += 1
            if tot > 1.5: o15 += 1
            else: u15 += 1

            if tot > 2.5: o25 += 1
            else: u25 += 1

            if tot > 3.5: o35 += 1
            else: u35 += 1

            if tot <= 4.5: u45 += 1

            if gh > 0 and ga > 0:
                btts_y += 1
            else:
                btts_n += 1

            sc = f"{gh}-{ga}"
            score_counts[sc] = score_counts.get(sc, 0) + 1

        n = float(self.n_sims)
        sorted_scores = sorted(score_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        return {
            "lambda_h": round(lambda_h, 3),
            "lambda_a": round(lambda_a, 3),
            "total_xg": round(total_xg, 3),
            "p_1x2": {
                "1": h_wins / n,
                "X": draws / n,
                "2": a_wins / n
            },
            "p_dc": {
                "1X": dc_1x / n,
                "X2": dc_x2 / n,
                "12": dc_12 / n
            },
            "p_goals": {
                "over_0_5": o05 / n,
                "over_1_5": o15 / n,
                "under_1_5": u15 / n,
                "over_2_5": o25 / n,
                "under_2_5": u25 / n,
                "over_3_5": o35 / n,
                "under_3_5": u35 / n,
                "under_4_5": u45 / n
            },
            "p_btts": {
                "yes": btts_y / n,
                "no": btts_n / n
            },
            "top_scores": sorted_scores
        }

    def get_betplay_odds_for_match(self, betplay_id: int) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT mercado, opcion, cuota, linea
            FROM betplay_cuotas
            WHERE partido_id = ?
              AND cuota IS NOT NULL
              AND cuota >= 1.30
              AND cuota <= 1.90
              AND (
                  mercado = 'Total de goles'
                  OR mercado = 'Ambos Equipos Marcarán'
                  OR mercado = 'Doble Oportunidad'
                  OR mercado = 'Resultado Final'
                  OR mercado = 'Hándicap Asiático'
              )
        """, (betplay_id,))
        rows = cur.fetchall()
        odds = []
        for r in rows:
            odds.append({
                "market": r['mercado'],
                "selection": r['opcion'],
                "odd": float(r['cuota']),
                "line": float(r['linea']) if r['linea'] is not None else None
            })
        return odds

def run():
    analyzer = MatchAnalyzer19Oct()
    cur = analyzer.conn.cursor()

    cur.execute("""
        SELECT bp.id, bp.equipo_local, bp.equipo_visitante, bp.competicion, bp.fecha_partido, COUNT(bc.id) as n_odds
        FROM betplay_partidos bp
        JOIN betplay_cuotas bc ON bp.id = bc.partido_id
        WHERE bp.fecha_partido LIKE '%2026-10-19%'
        GROUP BY bp.id
        HAVING n_odds > 500
        ORDER BY bp.fecha_partido ASC
    """)
    matches = cur.fetchall()

    print(f"[*] Analizando {len(matches)} partidos prioritarios de BetPlay para el 19 de Octubre de 2026...")

    all_candidate_legs = []

    for m in matches:
        bp_id = m['id']
        hl = m['equipo_local']
        al = m['equipo_visitante']
        comp = m['competicion']
        kickoff = m['fecha_partido']

        sim = analyzer.simulate_match(hl, al)
        odds = analyzer.get_betplay_odds_for_match(bp_id)

        # Reglas de Descarte Inteligente y Evaluación de Valor
        for o in odds:
            m_name = o['market']
            sel = o['selection']
            cuota = o['odd']
            line = o['line']

            model_prob = 0.0
            discard_reason = None

            # 1. TOTAL DE GOLES
            if m_name == 'Total de goles':
                if line == 0.5:
                    if sel == 'Más de': model_prob = sim['p_goals']['over_0_5']
                elif line == 1.5:
                    if sel == 'Más de':
                        # Descarte si el partido es ultra cerrado y no compensa
                        if sim['total_xg'] < 1.30: discard_reason = "Total xG < 1.30 (Ultra Cerrado)"
                        model_prob = sim['p_goals']['over_1_5']
                    elif sel == 'Menos de':
                        if sim['total_xg'] > 2.0: discard_reason = "Total xG > 2.0 descarta Under 1.5"
                        model_prob = sim['p_goals']['under_1_5']
                elif line == 2.5:
                    if sel == 'Menos de':
                        if sim['total_xg'] > 2.70: discard_reason = "Total xG > 2.70 descarta Under 2.5"
                        model_prob = sim['p_goals']['under_2_5']
                    elif sel == 'Más de':
                        if sim['total_xg'] < 2.30: discard_reason = "Total xG < 2.30 descarta Over 2.5"
                        model_prob = sim['p_goals']['over_2_5']
                elif line == 3.5:
                    if sel == 'Menos de':
                        model_prob = sim['p_goals']['under_3_5']
                    elif sel == 'Más de':
                        if sim['total_xg'] < 2.80: discard_reason = "Total xG < 2.80 descarta Over 3.5"
                        model_prob = sim['p_goals']['over_3_5']
                elif line == 4.5:
                    if sel == 'Menos de':
                        model_prob = sim['p_goals']['under_4_5']

            # 2. AMBOS EQUIPOS MARCARÁN (BTTS)
            elif m_name == 'Ambos Equipos Marcarán':
                if sel == 'Sí':
                    # Condición de descarte del usuario: Si xG total es bajo (<2.10) o 0-0/1-0 dominan, descartar Sí
                    if sim['total_xg'] < 2.10:
                        discard_reason = "Descarte BTTS Sí por bajo xG total (< 2.10)"
                    model_prob = sim['p_btts']['yes']
                elif sel == 'No':
                    if sim['total_xg'] > 2.70:
                        discard_reason = "Descarte BTTS No por alto xG (> 2.70)"
                    model_prob = sim['p_btts']['no']

            # 3. DOBLE OPORTUNIDAD
            elif m_name == 'Doble Oportunidad':
                if sel == '1X': model_prob = sim['p_dc']['1X']
                elif sel == 'X2': model_prob = sim['p_dc']['X2']
                elif sel == '12': model_prob = sim['p_dc']['12']

            # 4. RESULTADO FINAL
            elif m_name == 'Resultado Final':
                if sel == '1' or 'local' in sel.lower(): model_prob = sim['p_1x2']['1']
                elif sel == 'X' or 'empate' in sel.lower(): model_prob = sim['p_1x2']['X']
                elif sel == '2' or 'visitante' in sel.lower(): model_prob = sim['p_1x2']['2']

            if discard_reason or model_prob <= 0.0:
                continue

            implied_prob = 1.0 / cuota
            edge = model_prob - implied_prob
            ev = (model_prob * cuota) - 1.0

            # Guardar candidatos con EV positivo
            if ev > 0.05 and edge > 0.03:
                all_candidate_legs.append({
                    "match_id": bp_id,
                    "home_team": hl,
                    "away_team": al,
                    "competition": comp,
                    "kickoff": kickoff,
                    "total_xg": sim['total_xg'],
                    "market": m_name,
                    "selection": sel,
                    "line": line,
                    "cuota": cuota,
                    "model_prob": model_prob,
                    "implied_prob": implied_prob,
                    "edge": edge,
                    "ev": ev
                })

    analyzer.close()

    # Deduplicar por partido y mercado (tomar la mejor cuota)
    unique_legs = {}
    for leg in all_candidate_legs:
        key = (leg['match_id'], leg['market'], leg['selection'], leg['line'])
        if key not in unique_legs or leg['ev'] > unique_legs[key]['ev']:
            unique_legs[key] = leg

    sorted_legs = sorted(unique_legs.values(), key=lambda x: x['ev'], reverse=True)
    print(f"\n[✓] Total líneas analizadas con Edge positivo (EV > 0 y Cuota 1.30 - 1.90): {len(sorted_legs)}\n")

    for idx, l in enumerate(sorted_legs[:20], 1):
        line_str = f" {l['line']}" if l['line'] is not None else ""
        print(f"[{idx:02d}] {l['home_team']} vs {l['away_team']} ({l['competition']})")
        print(f"     Mercado: {l['market']} -> {l['selection']}{line_str} | Cuota BetPlay: {l['cuota']:.2f}")
        print(f"     xG: {l['total_xg']} | Prob Modelo: {l['model_prob']*100:.1f}% | Implied: {l['implied_prob']*100:.1f}% | Edge: +{l['edge']*100:.1f}% | EV: +{l['ev']*100:.1f}%\n")

if __name__ == "__main__":
    run()
