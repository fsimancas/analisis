"""
Módulo Global de Escaneo y Clasificación de Oportunidades de Mercado (FAIS).
Cruza las 197 competiciones, 76 países, 2,215 árbitros y 60,000+ jugadores
para detectar nichos de mercado con máxima ventaja estadística.
"""

from .market_screener import GlobalMarketScreener

__all__ = ["GlobalMarketScreener"]
