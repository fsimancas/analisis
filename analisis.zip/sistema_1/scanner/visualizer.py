from typing import Dict, Any, List

class GlobalScannerVisualizer:
    """
    Renderiza el reporte consolidado de escaneo global de mercados y arbitraje.
    """

    @staticmethod
    def render(data: Dict[str, Any]) -> str:
        lines = []
        n_comps = data.get("total_competitions_scanned", 197)
        n_refs = data.get("total_referees_scanned", 2215)
        recs = data.get("market_recommendations", [])
        comps = data.get("competitions_breakdown", {})
        refs = data.get("referees_breakdown", {})

        lines.append("=" * 88)
        lines.append(f" ESCANER GLOBAL DE MERCADOS Y OPORTUNIDADES (FAIS MULTI-COMPETICIÓN)")
        lines.append(f" Cobertura: {n_comps} Competiciones | 76 Países | {n_refs} Árbitros FotMob")
        lines.append("=" * 88)

        # 1. Recomendaciones Clave por Mercado
        lines.append("\n[+] MATRIZ DE OPORTUNIDADES POR MERCADO (NICHO Y EDGE):")
        for idx, rec in enumerate(recs, start=1):
            lines.append(f"\n  [{idx}] MERCADO: {rec['market'].upper()}")
            lines.append(f"      Criterio:   {rec['target_profile']}")
            if 'recommended_competitions' in rec:
                lines.append(f"      Top Ligas:  {'; '.join(rec['recommended_competitions'][:3])}")
            if 'recommended_referees' in rec:
                lines.append(f"      Top Árbitros: {'; '.join(rec['recommended_referees'][:3])}")
            lines.append(f"      Justificación: {rec['rationale']}")

        # 2. Ranking de Ligas por Mercados Específicos
        lines.append("\n" + "-" * 88)
        lines.append("[+] RANKING GLOBAL DE COMPETICIONES (MERCADOS DE GOLES):")

        lines.append("\n  -- LIGAS CON MAYOR PROBABILIDAD DE +1.5 GOLES (OVER 1.5) --")
        for i, c in enumerate(comps.get('top_over_15', [])[:5], start=1):
            lines.append(f"    {i}. {c['nombre_flashscore']} ({c['pais_nombre']}): {c['pct_over_15']} (+1.5) | Promedio: {c['promedio_goles']} g/pj ({c['partidos_jugados']} pj)")

        lines.append("\n  -- LIGAS CON MAYOR PROBABILIDAD DE MENOS DE 2.5 GOLES (UNDER 2.5) --")
        for i, c in enumerate(comps.get('top_under_25', [])[:5], start=1):
            lines.append(f"    {i}. {c['nombre_flashscore']} ({c['pais_nombre']}): {c['pct_under_25']} Under 2.5 | Promedio: {c['promedio_goles']} g/pj ({c['partidos_jugados']} pj)")

        lines.append("\n  -- LIGAS CON MAYOR PROBABILIDAD DE AMBOS MARCAN (BTTS: SÍ) --")
        for i, c in enumerate(comps.get('top_btts', [])[:5], start=1):
            lines.append(f"    {i}. {c['nombre_flashscore']} ({c['pais_nombre']}): {c['pct_btts']} BTTS | Promedio: {c['promedio_goles']} g/pj ({c['partidos_jugados']} pj)")

        lines.append("\n  -- LIGAS CON MÁXIMA TENDENCIA AL EMPATE (MERCADO X) --")
        for i, c in enumerate(comps.get('top_draw_parity', [])[:5], start=1):
            lines.append(f"    {i}. {c['nombre_flashscore']} ({c['pais_nombre']}): {c['pct_empates']} Empates ({c['partidos_jugados']} pj)")

        # 3. Ranking de Árbitros
        lines.append("\n" + "-" * 88)
        lines.append("[+] RANKING GLOBAL DE ÁRBITROS (MERCADOS DISCIPLINARIOS):")

        lines.append("\n  -- ÁRBITROS MÁS SEVEROS (OVER TARJETAS AMARILLAS) --")
        for i, r in enumerate(refs.get('top_strict_card_referees', [])[:5], start=1):
            lines.append(f"    {i}. {r['arbitro_nombre']}: {r['avg_amarillas']} amarillas/pj | {r['avg_faltas']} faltas/pj ({r['partidos_dirigidos']} pj)")

        lines.append("\n  -- ÁRBITROS CON MÁS FALTAS SANCIONADAS (OVER FALTAS) --")
        for i, r in enumerate(refs.get('top_foul_calling_referees', [])[:5], start=1):
            lines.append(f"    {i}. {r['arbitro_nombre']}: {r['avg_faltas']} faltas/pj | {r['avg_amarillas']} amarillas/pj ({r['partidos_dirigidos']} pj)")

        lines.append("=" * 88)
        return "\n".join(lines)
