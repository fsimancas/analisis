import sqlite3
from typing import Dict, Any, List
from ..config import DB_PATH

class GlobalMarketScreener:
    """
    Motor global de escaneo de mercados y perfiles multi-entidad:
    - Competiciones: Filtra entre 197 ligas y 76 países para encontrar ligas extremas
      (más goles, Over 1.5, Over 2.5, Under 2.5, BTTS, empates, localía).
    - Árbitros: Clasifica 2,215 árbitros de FotMob según su rigor disciplinario
      (más amarillas/partido, más faltas, rojas).
    - Equipos: Identifica los equipos más extremos del mundo en ataque y defensa.
    - Oportunidades: Genera la matriz de nichos de mercado con mayor probabilidad y edge.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def screen_competitions(self, min_matches: int = 15) -> Dict[str, List[Dict[str, Any]]]:
        conn = self._get_connection()
        cur = conn.cursor()

        # 1. Top Over 1.5
        cur.execute("""
            SELECT pais_nombre, nombre_flashscore, partidos_jugados, promedio_goles, pct_over_15, pct_over_25, pct_btts
            FROM estadisticas_resumen_ligas
            WHERE partidos_jugados >= ?
            ORDER BY CAST(REPLACE(pct_over_15, '%', '') AS INTEGER) DESC, promedio_goles DESC
            LIMIT 10;
        """, (min_matches,))
        top_over15 = [dict(r) for r in cur.fetchall()]

        # 2. Top Over 2.5
        cur.execute("""
            SELECT pais_nombre, nombre_flashscore, partidos_jugados, promedio_goles, pct_over_25, pct_over_15, pct_btts
            FROM estadisticas_resumen_ligas
            WHERE partidos_jugados >= ?
            ORDER BY CAST(REPLACE(pct_over_25, '%', '') AS INTEGER) DESC, promedio_goles DESC
            LIMIT 10;
        """, (min_matches,))
        top_over25 = [dict(r) for r in cur.fetchall()]

        # 3. Top Under 2.5 (Menos de 2.5)
        cur.execute("""
            SELECT pais_nombre, nombre_flashscore, partidos_jugados, promedio_goles, pct_over_25, pct_over_15
            FROM estadisticas_resumen_ligas
            WHERE partidos_jugados >= ?
            ORDER BY CAST(REPLACE(pct_over_25, '%', '') AS INTEGER) ASC, promedio_goles ASC
            LIMIT 10;
        """, (min_matches,))
        top_under25 = []
        for r in cur.fetchall():
            d = dict(r)
            ov25 = int(d['pct_over_25'].replace('%', ''))
            d['pct_under_25'] = f"{100 - ov25}%"
            top_under25.append(d)

        # 4. Top Ambos Marcan (BTTS Sí)
        cur.execute("""
            SELECT pais_nombre, nombre_flashscore, partidos_jugados, promedio_goles, pct_btts, pct_over_15
            FROM estadisticas_resumen_ligas
            WHERE partidos_jugados >= ?
            ORDER BY CAST(REPLACE(pct_btts, '%', '') AS INTEGER) DESC, promedio_goles DESC
            LIMIT 10;
        """, (min_matches,))
        top_btts = [dict(r) for r in cur.fetchall()]

        # 5. Top Localía (% Victorias Local)
        cur.execute("""
            SELECT pais_nombre, nombre_flashscore, partidos_jugados, pct_victorias_local, pct_empates, pct_victorias_visitante
            FROM estadisticas_resumen_ligas
            WHERE partidos_jugados >= ?
            ORDER BY CAST(REPLACE(pct_victorias_local, '%', '') AS INTEGER) DESC
            LIMIT 10;
        """, (min_matches,))
        top_home = [dict(r) for r in cur.fetchall()]

        # 6. Top Empates (% Empates para trading/apuestas a X)
        cur.execute("""
            SELECT pais_nombre, nombre_flashscore, partidos_jugados, pct_empates, pct_victorias_local, pct_victorias_visitante
            FROM estadisticas_resumen_ligas
            WHERE partidos_jugados >= ?
            ORDER BY CAST(REPLACE(pct_empates, '%', '') AS INTEGER) DESC
            LIMIT 10;
        """, (min_matches,))
        top_draws = [dict(r) for r in cur.fetchall()]

        conn.close()

        return {
            "top_over_15": top_over15,
            "top_over_25": top_over25,
            "top_under_25": top_under25,
            "top_btts": top_btts,
            "top_home_dominance": top_home,
            "top_draw_parity": top_draws
        }

    def screen_referees(self, min_matches: int = 5) -> Dict[str, List[Dict[str, Any]]]:
        conn = self._get_connection()
        cur = conn.cursor()

        # 1. Top árbitros con más amarillas por partido (Mercado Over Tarjetas)
        cur.execute("""
            SELECT arbitro_nombre, count(match_id) as partidos_dirigidos,
                   round(avg(arbitro_amarillas_partido), 2) as avg_amarillas,
                   sum(arbitro_rojas_total) as total_rojas,
                   round(avg(arbitro_faltas_partido), 2) as avg_faltas
            FROM fotmob_detalles_partido
            WHERE arbitro_nombre IS NOT NULL AND arbitro_nombre != '' AND arbitro_amarillas_partido > 0
            GROUP BY arbitro_nombre
            HAVING partidos_dirigidos >= ?
            ORDER BY avg_amarillas DESC
            LIMIT 10;
        """, (min_matches,))
        top_yellows = [dict(r) for r in cur.fetchall()]

        # 2. Top árbitros con más faltas por partido (Mercado Faltas)
        cur.execute("""
            SELECT arbitro_nombre, count(match_id) as partidos_dirigidos,
                   round(avg(arbitro_faltas_partido), 2) as avg_faltas,
                   round(avg(arbitro_amarillas_partido), 2) as avg_amarillas
            FROM fotmob_detalles_partido
            WHERE arbitro_nombre IS NOT NULL AND arbitro_nombre != '' AND arbitro_faltas_partido > 0
            GROUP BY arbitro_nombre
            HAVING partidos_dirigidos >= ?
            ORDER BY avg_faltas DESC
            LIMIT 10;
        """, (min_matches,))
        top_fouls = [dict(r) for r in cur.fetchall()]

        # 3. Árbitros más permisivos (Menos tarjetas -> Mercado Under Tarjetas)
        cur.execute("""
            SELECT arbitro_nombre, count(match_id) as partidos_dirigidos,
                   round(avg(arbitro_amarillas_partido), 2) as avg_amarillas,
                   round(avg(arbitro_faltas_partido), 2) as avg_faltas
            FROM fotmob_detalles_partido
            WHERE arbitro_nombre IS NOT NULL AND arbitro_nombre != '' AND arbitro_amarillas_partido > 0
            GROUP BY arbitro_nombre
            HAVING partidos_dirigidos >= ?
            ORDER BY avg_amarillas ASC
            LIMIT 10;
        """, (min_matches,))
        top_permissive = [dict(r) for r in cur.fetchall()]

        conn.close()

        return {
            "top_strict_card_referees": top_yellows,
            "top_foul_calling_referees": top_fouls,
            "top_permissive_referees": top_permissive
        }

    def generate_market_opportunities(self) -> Dict[str, Any]:
        comps = self.screen_competitions()
        refs = self.screen_referees()

        recommendations = [
            {
                "market": "Total de goles: Más de 1.5",
                "target_profile": "Competiciones con > 85% de frecuencia en +1.5",
                "recommended_competitions": [
                    f"{c['nombre_flashscore']} ({c['pais_nombre']}) - {c['pct_over_15']} (+{c['promedio_goles']} g/pj)"
                    for c in comps['top_over_15'][:4]
                ],
                "rationale": "Ligas de altísimo ritmo ofensivo ideales para entradas Over 1.5 o escaleras pre-partido."
            },
            {
                "market": "Total de goles: Menos de 2.5",
                "target_profile": "Competiciones con > 65% de partidos Under 2.5",
                "recommended_competitions": [
                    f"{c['nombre_flashscore']} ({c['pais_nombre']}) - {c['pct_under_25']} Under (prom: {c['promedio_goles']} g/pj)"
                    for c in comps['top_under_25'][:4]
                ],
                "rationale": "Ligas defensivas o de baja eficacia rematadora óptimas para líneas de Under o marcadores bajos."
            },
            {
                "market": "Ambos Equipos Marcarán (BTTS: Sí)",
                "target_profile": "Competiciones con > 65% de partidos con ambos anotando",
                "recommended_competitions": [
                    f"{c['nombre_flashscore']} ({c['pais_nombre']}) - {c['pct_btts']} BTTS"
                    for c in comps['top_btts'][:4]
                ],
                "rationale": "Competiciones con defensas vulnerables y ataques abiertos donde el 'Sí' tiene valor sistemático."
            },
            {
                "market": "Mercado de Tarjetas: Más de 4.5 / 5.5",
                "target_profile": "Árbitros con promedio > 6.5 tarjetas amarillas por encuentro",
                "recommended_referees": [
                    f"{r['arbitro_nombre']} ({r['partidos_dirigidos']} pj): {r['avg_amarillas']} amarillas/p | {r['avg_faltas']} faltas/p"
                    for r in refs['top_strict_card_referees'][:4]
                ],
                "rationale": "Árbitros con bajísima tolerancia a faltas, detonadores sistemáticos del Over de tarjetas."
            },
            {
                "market": "Resultado Final: Empate (X)",
                "target_profile": "Competiciones con > 35% de empates",
                "recommended_competitions": [
                    f"{c['nombre_flashscore']} ({c['pais_nombre']}) - {c['pct_empates']} Empates"
                    for c in comps['top_draw_parity'][:4]
                ],
                "rationale": "Ligas de máxima paridad táctica donde las cuotas de empate (> 3.00) presentan valor esperado positivo."
            }
        ]

        return {
            "total_competitions_scanned": 197,
            "total_referees_scanned": 2215,
            "market_recommendations": recommendations,
            "competitions_breakdown": comps,
            "referees_breakdown": refs
        }
