import sqlite3
import re
from typing import List, Dict, Any, Optional
from .config import DB_PATH

def clean_team_name(name: Optional[str]) -> str:
    if not name:
        return ""
    cleaned = re.sub(r'GOL$', '', name.strip()).strip()
    return cleaned

class Database:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def get_competition(self, comp_id: int) -> Optional[Dict[str, Any]]:
        conn = self.connect()
        cur = conn.cursor()
        cur.execute("SELECT * FROM competiciones WHERE id = ?", (comp_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_completed_matches(self, comp_id: int) -> List[Dict[str, Any]]:
        conn = self.connect()
        cur = conn.cursor()
        cur.execute("""
            SELECT id, competicion_id, tipo, jornada, fecha_hora,
                   equipo_local, equipo_visitante, goles_local, goles_visitante,
                   link, estado
            FROM partidos
            WHERE competicion_id = ? AND tipo = 'resultado' AND goles_local IS NOT NULL
            ORDER BY rowid ASC
        """, (comp_id,))
        matches = []
        for r in cur.fetchall():
            d = dict(r)
            d['equipo_local'] = clean_team_name(d['equipo_local'])
            d['equipo_visitante'] = clean_team_name(d['equipo_visitante'])
            matches.append(d)
        return matches

    def get_upcoming_matches(self, comp_id: int) -> List[Dict[str, Any]]:
        conn = self.connect()
        cur = conn.cursor()
        cur.execute("""
            SELECT id, competicion_id, tipo, jornada, fecha_hora,
                   equipo_local, equipo_visitante, link, estado
            FROM partidos
            WHERE competicion_id = ? AND tipo = 'proximo'
            ORDER BY rowid ASC
        """, (comp_id,))
        matches = []
        for r in cur.fetchall():
            d = dict(r)
            d['equipo_local'] = clean_team_name(d['equipo_local'])
            d['equipo_visitante'] = clean_team_name(d['equipo_visitante'])
            matches.append(d)
        return matches

    def get_incidents_for_matches(self, match_ids: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        if not match_ids:
            return {}
        conn = self.connect()
        cur = conn.cursor()
        
        incidents_by_match: Dict[str, List[Dict[str, Any]]] = {mid: [] for mid in match_ids}
        chunk_size = 500
        for i in range(0, len(match_ids), chunk_size):
            chunk = match_ids[i:i + chunk_size]
            placeholders = ",".join("?" * len(chunk))
            cur.execute(f"""
                SELECT id, partido_id, periodo, minuto, equipo, tipo, jugador, nota
                FROM partidos_incidentes
                WHERE partido_id IN ({placeholders})
                ORDER BY partido_id, rowid ASC
            """, chunk)
            for r in cur.fetchall():
                d = dict(r)
                incidents_by_match[d['partido_id']].append(d)
                
        return incidents_by_match
