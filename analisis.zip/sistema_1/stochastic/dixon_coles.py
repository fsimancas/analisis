import math
from typing import List, Dict, Any, Tuple
from collections import defaultdict

class DixonColesModel:
    """
    Modelo de goles bivariado Dixon-Coles con corrección de marcadores bajos:
    - Estima parámetros de ataque (alpha) y defensa (beta) para cada equipo
    - Estima ventaja de localía (h) y nivel base de goles de la liga (mu)
    - Calcula las intensidades de gol esperadas (lambda_H, lambda_A) para cualquier partido
    - Aplica corrección tau(x, y) con parámetro rho para (0-0, 1-0, 0-1, 1-1)
    """

    def __init__(self, rho: float = -0.05):
        self.rho = rho
        self.mu = 0.0
        self.home_adv = 0.25
        self.attack_strengths: Dict[str, float] = {}
        self.defense_strengths: Dict[str, float] = {}
        self.teams: List[str] = []

    def fit(self, matches: List[Dict[str, Any]]) -> "DixonColesModel":
        if not matches:
            return self

        teams_set = set()
        for m in matches:
            teams_set.add(m['equipo_local'])
            teams_set.add(m['equipo_visitante'])
        self.teams = sorted(list(teams_set))
        n_teams = len(self.teams)
        if n_teams == 0:
            return self

        total_matches = len(matches)
        total_goals = sum(int(m['goles_local']) + int(m['goles_visitante']) for m in matches)
        home_goals = sum(int(m['goles_local']) for m in matches)
        away_goals = sum(int(m['goles_visitante']) for m in matches)

        # Baseline mu y ventaja de localía h
        avg_goals_match = total_goals / total_matches if total_matches > 0 else 2.5
        self.mu = math.log(max(avg_goals_match / 2.0, 0.1))
        self.home_adv = math.log(max(home_goals / max(away_goals, 1), 0.5)) / 2.0

        goals_scored = defaultdict(float)
        goals_conceded = defaultdict(float)
        matches_played = defaultdict(float)

        for m in matches:
            h = m['equipo_local']
            a = m['equipo_visitante']
            gh = int(m['goles_local'])
            ga = int(m['goles_visitante'])

            goals_scored[h] += gh
            goals_conceded[h] += ga
            matches_played[h] += 1

            goals_scored[a] += ga
            goals_conceded[a] += gh
            matches_played[a] += 1

        avg_team_goals_per_game = total_goals / (2.0 * total_matches) if total_matches > 0 else 1.25

        raw_att = {}
        raw_def = {}
        for t in self.teams:
            gp = matches_played[t]
            att_rate = (goals_scored[t] / gp) / avg_team_goals_per_game if gp > 0 else 1.0
            def_rate = (goals_conceded[t] / gp) / avg_team_goals_per_game if gp > 0 else 1.0
            raw_att[t] = math.log(max(att_rate, 0.1))
            raw_def[t] = math.log(max(def_rate, 0.1))

        # Restricción de suma cero: sum(alpha) = 0, sum(beta) = 0
        mean_att = sum(raw_att.values()) / n_teams
        mean_def = sum(raw_def.values()) / n_teams

        self.attack_strengths = {t: round(raw_att[t] - mean_att, 4) for t in self.teams}
        self.defense_strengths = {t: round(raw_def[t] - mean_def, 4) for t in self.teams}

        return self

    def predict_lambdas(self, home_team: str, away_team: str) -> Tuple[float, float]:
        att_h = self.attack_strengths.get(home_team, 0.0)
        def_a = self.defense_strengths.get(away_team, 0.0)

        att_a = self.attack_strengths.get(away_team, 0.0)
        def_h = self.defense_strengths.get(home_team, 0.0)

        log_lambda_h = self.mu + self.home_adv + att_h + def_a
        log_lambda_a = self.mu + att_a + def_h

        # Bounds check
        lambda_h = max(0.1, min(6.0, math.exp(log_lambda_h)))
        lambda_a = max(0.1, min(6.0, math.exp(log_lambda_a)))

        return round(lambda_h, 3), round(lambda_a, 3)

    def tau_correction(self, x: int, y: int, lambda_h: float, lambda_a: float) -> float:
        if x == 0 and y == 0:
            return max(0.0, 1.0 - (lambda_h * lambda_a * self.rho))
        elif x == 1 and y == 0:
            return max(0.0, 1.0 + (lambda_a * self.rho))
        elif x == 0 and y == 1:
            return max(0.0, 1.0 + (lambda_h * self.rho))
        elif x == 1 and y == 1:
            return max(0.0, 1.0 - self.rho)
        return 1.0
