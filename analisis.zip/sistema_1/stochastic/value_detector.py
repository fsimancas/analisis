import sqlite3
from typing import Dict, Any, List, Optional
from ..config import DB_PATH

class ValueDetector:
    """
    Detector de valor cuantitativo frente a las cuotas reales de BetPlay:
    - Cruza las probabilidades de la simulación Monte Carlo contra betplay_cuotas
    - Calcula la probabilidad implícita: P_imp = 1 / cuota
    - Calcula el Edge (Ventaja matemática): Edge = P_modelo - P_imp
    - Calcula el Valor Esperado: EV = (P_modelo * cuota) - 1
    - Clasifica oportunidades: ALTA (EV > 10%), MEDIA (EV 5-10%), BAJA (EV 2-5%)
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path

    def _find_betplay_odds_for_match(
        self,
        home_team: str,
        away_team: str
    ) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Search in betplay_partidos
        cur.execute("""
            SELECT id, partido, equipo_local, equipo_visitante, competicion, fecha_partido
            FROM betplay_partidos
            WHERE (equipo_local LIKE ? OR partido LIKE ?)
              AND (equipo_visitante LIKE ? OR partido LIKE ?)
            LIMIT 1;
        """, (f"%{home_team}%", f"%{home_team}%", f"%{away_team}%", f"%{away_team}%"))
        bp = cur.fetchone()

        if not bp:
            # Fallback search with looser matching
            h_part = home_team.split()[0]
            a_part = away_team.split()[0]
            cur.execute("""
                SELECT id, partido, equipo_local, equipo_visitante, competicion, fecha_partido
                FROM betplay_partidos
                WHERE partido LIKE ? AND partido LIKE ?
                LIMIT 1;
            """, (f"%{h_part}%", f"%{a_part}%"))
            bp = cur.fetchone()

        if not bp:
            conn.close()
            return []

        partido_id = bp['id']
        cur.execute("""
            SELECT categoria, mercado, tipo, opcion, cuota, linea
            FROM betplay_cuotas
            WHERE partido_id = ?
        """, (partido_id,))
        odds = [dict(r) for r in cur.fetchall()]
        conn.close()
        return odds

    def evaluate_value(
        self,
        simulation_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        home_team = simulation_data['home_team']
        away_team = simulation_data['away_team']
        markets = simulation_data['markets']

        betplay_odds = self._find_betplay_odds_for_match(home_team, away_team)
        if not betplay_odds:
            return {
                "match": f"{home_team} vs {away_team}",
                "betplay_linked": False,
                "message": f"No se encontraron cuotas activas de BetPlay para {home_team} vs {away_team} en la base de datos.",
                "value_opportunities": []
            }

        opportunities = []

        # 1. Evaluate 1X2 ('Resultado Final')
        p_1 = markets['1x2']['home_win']['probability']
        p_x = markets['1x2']['draw']['probability']
        p_2 = markets['1x2']['away_win']['probability']

        for o in betplay_odds:
            m_name = o.get('mercado', '')
            opcion = str(o.get('opcion', '')).strip()
            cuota_val = o.get('cuota')
            if cuota_val is None:
                continue
            try:
                cuota = float(cuota_val)
            except (ValueError, TypeError):
                continue
            if cuota <= 1.0:
                continue

            prob_model = None
            market_label = ""

            if 'Resultado Final' in m_name:
                if opcion in ('1', home_team):
                    prob_model = p_1
                    market_label = f"Victoria {home_team} (1)"
                elif opcion in ('X', 'Empate'):
                    prob_model = p_x
                    market_label = "Empate (X)"
                elif opcion in ('2', away_team):
                    prob_model = p_2
                    market_label = f"Victoria {away_team} (2)"

            elif 'Ambos Equipos Marcar' in m_name:
                if opcion.lower() in ('sí', 'si', 'yes'):
                    prob_model = markets['btts']['yes']['probability']
                    market_label = "Ambos Marcan - SÍ"
                elif opcion.lower() in ('no'):
                    prob_model = markets['btts']['no']['probability']
                    market_label = "Ambos Marcan - NO"

            elif 'Total de goles' in m_name and o.get('linea') is not None:
                line_str = str(o.get('linea'))
                ou_data = markets['over_under'].get(line_str)
                if ou_data:
                    if 'Más' in opcion or 'Over' in opcion:
                        prob_model = ou_data['over']
                        market_label = f"Más de {line_str} goles"
                    elif 'Menos' in opcion or 'Under' in opcion:
                        prob_model = ou_data['under']
                        market_label = f"Menos de {line_str} goles"

            if prob_model is not None and prob_model > 0:
                prob_implied = round(1.0 / cuota, 4)
                raw_edge = prob_model - prob_implied
                ev = round((prob_model * cuota) - 1.0, 4)
                fair_odd = round(1.0 / prob_model, 2)

                if ev > 0.02 and raw_edge > 0.02:
                    priority = "ALTA" if ev >= 0.10 else ("MEDIA" if ev >= 0.05 else "BAJA")
                    opportunities.append({
                        "market": market_label,
                        "selection": opcion,
                        "betplay_odd": cuota,
                        "fair_odd": fair_odd,
                        "prob_model": f"{round(prob_model * 100, 1)}%",
                        "prob_implied": f"{round(prob_implied * 100, 1)}%",
                        "edge": f"+{round(raw_edge * 100, 1)}%",
                        "ev": f"+{round(ev * 100, 1)}%",
                        "priority": priority,
                        "recommendation": f"Entrada con valor matemático: Cuota ofrecida {cuota} > Cuota justa {fair_odd} (Edge: +{round(raw_edge * 100, 1)}%)"
                    })

        # Sort by EV desc
        opportunities.sort(key=lambda x: float(x['ev'].replace('+', '').replace('%', '')), reverse=True)

        return {
            "match": f"{home_team} vs {away_team}",
            "betplay_linked": True,
            "total_odds_evaluated": len(betplay_odds),
            "value_bets_count": len(opportunities),
            "value_opportunities": opportunities
        }
