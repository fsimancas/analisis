from typing import Dict, Any, List

class StochasticVisualizer:
    """
    Renderiza los resultados de la simulación Monte Carlo (N=10,000)
    y las oportunidades de valor frente a BetPlay en la consola.
    """

    @staticmethod
    def render(
        sim_data: Dict[str, Any],
        val_data: Dict[str, Any]
    ) -> str:
        lines = []
        match_title = sim_data.get("match", "Partido")
        xg = sim_data.get("expected_goals", {})
        markets = sim_data.get("markets", {})
        m_1x2 = markets.get("1x2", {})
        dc = markets.get("double_chance", {})
        ou = markets.get("over_under", {})
        btts = markets.get("btts", {})
        top_sc = sim_data.get("top_scorelines", [])

        lines.append("=" * 88)
        lines.append(f" SIMULACIÓN ESTOCÁSTICA FAIS (MONTE CARLO N = {sim_data.get('simulations_run', 10000)}): {match_title.upper()}")
        lines.append(f" Goles esperados (Dixon-Coles): Local (λ_H): {xg.get('home_lambda')} | Visitante (λ_A): {xg.get('away_lambda')} | Total: {xg.get('total_expected_goals')}")
        lines.append("=" * 88)

        # 1. 1X2 y Doble Oportunidad
        lines.append("\n[+] MERCADOS PRINCIPALES (PROBABILIDAD Y CUOTA JUSTA):")
        lines.append("  -- Resultado Final (1X2) --")
        h_res = m_1x2.get("home_win", {})
        d_res = m_1x2.get("draw", {})
        a_res = m_1x2.get("away_win", {})
        lines.append(f"  * Victoria Local (1):       {h_res.get('percentage'):<10} Cuota Justa: {h_res.get('fair_odd')}")
        lines.append(f"  * Empate (X):               {d_res.get('percentage'):<10} Cuota Justa: {d_res.get('fair_odd')}")
        lines.append(f"  * Victoria Visitante (2):   {a_res.get('percentage'):<10} Cuota Justa: {a_res.get('fair_odd')}")

        lines.append("\n  -- Doble Oportunidad --")
        lines.append(f"  * 1X: {dc.get('1X', {}).get('percentage')} (Cuota: {dc.get('1X', {}).get('fair_odd')})  |  12: {dc.get('12', {}).get('percentage')} (Cuota: {dc.get('12', {}).get('fair_odd')})  |  X2: {dc.get('X2', {}).get('percentage')} (Cuota: {dc.get('X2', {}).get('fair_odd')})")

        # 2. Over / Under y BTTS
        lines.append("\n" + "-" * 88)
        lines.append("[+] LÍNEAS DE TOTALES Y AMBOS MARCAN:")
        for line in ["1.5", "2.5", "3.5"]:
            l_info = ou.get(line, {})
            p_ov = round(l_info.get("over", 0.0) * 100, 1)
            p_un = round(l_info.get("under", 0.0) * 100, 1)
            lines.append(f"  * Línea {line} goles:   Más de: {p_ov}% (Cuota {l_info.get('fair_odd_over')})   |   Menos de: {p_un}% (Cuota {l_info.get('fair_odd_under')})")

        btts_y = btts.get("yes", {})
        btts_n = btts.get("no", {})
        lines.append(f"  * Ambos Marcan (BTTS):  Sí: {btts_y.get('percentage')} (Cuota {btts_y.get('fair_odd')})   |   No: {btts_n.get('percentage')} (Cuota {btts_n.get('fair_odd')})")

        # 3. Top Marcadores Exactos
        lines.append("\n" + "-" * 88)
        lines.append("[+] TOP 6 MARCADORES EXACTOS MÁS PROBABLES:")
        sc_strs = [f"{sc['score']} ({sc['percentage']} - Cuota: {sc['fair_odd']})" for sc in top_sc[:6]]
        lines.append(f"  {', '.join(sc_strs[:3])}")
        lines.append(f"  {', '.join(sc_strs[3:6])}")

        # 4. Value Bets vs BetPlay
        lines.append("\n" + "-" * 88)
        lines.append("[+] ANÁLISIS DE VALOR MATEMÁTICO FRENTE A BETPLAY:")
        opps = val_data.get("value_opportunities", [])
        if opps:
            lines.append(f"  * Se detectaron {len(opps)} apuestas con valor matemático positivo (Edge > +2%, EV > 0):\n")
            for idx, op in enumerate(opps[:5], start=1):
                lines.append(f"  [{idx}] {op['market'].upper()} — Prioridad: {op['priority']}")
                lines.append(f"      Cuota BetPlay: {op['betplay_odd']}  vs  Cuota Justa: {op['fair_odd']}")
                lines.append(f"      Prob. Modelo:  {op['prob_model']}  vs  Prob. Implícita: {op['prob_implied']}")
                lines.append(f"      Ventaja (Edge): {op['edge']} | Valor Esperado (EV): {op['ev']}")
                lines.append(f"      Dictamen: {op['recommendation']}\n")
        else:
            msg = val_data.get("message", "No se detectaron apuestas con valor o no hay cuotas activas para este partido.")
            lines.append(f"  * {msg}")

        lines.append("=" * 88)
        return "\n".join(lines)
