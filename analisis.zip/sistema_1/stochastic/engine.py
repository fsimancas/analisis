import os
import json
from typing import Dict, Any, Optional, List

from ..db import Database, clean_team_name
from ..config import DB_PATH, OUTPUT_DIR
from .dixon_coles import DixonColesModel
from .monte_carlo import MonteCarloSimulator
from .value_detector import ValueDetector

class StochasticEngine:
    """
    Fachada orquestadora del Motor Estocástico FAIS:
    1. Ajusta el modelo Dixon-Coles sobre el historial de partidos finalizados.
    2. Estima los parámetros ofensivos y defensivos de cada equipo y la ventaja local.
    3. Para un partido objetivo, proyecta las intensidades lambda_H y lambda_A.
    4. Ejecuta la simulación de Monte Carlo con N = 10,000 iteraciones.
    5. Deriva las probabilidades de todos los mercados y sus cuotas justas.
    6. Cruza los resultados contra betplay_cuotas y detecta Value Bets (Edge & EV).
    """

    def __init__(self, db_path: str = DB_PATH, n_simulations: int = 10000):
        self.db = Database(db_path)
        self.db_path = db_path
        self.n_sims = n_simulations
        self.dixon_coles = DixonColesModel()
        self.monte_carlo = MonteCarloSimulator(n_simulations=n_simulations)
        self.value_detector = ValueDetector(db_path=db_path)
        self._fitted = False

    def close(self):
        self.db.close()

    def fit_competition(self, comp_id: int = 84) -> "StochasticEngine":
        results = self.db.get_completed_matches(comp_id)
        if not results:
            raise ValueError(f"No hay partidos con resultado para ajustar el modelo en comp_id {comp_id}.")
        self.dixon_coles.fit(results)
        self._fitted = True
        return self

    def simulate_fixture(
        self,
        home_team: str,
        away_team: str,
        comp_id: int = 84
    ) -> Dict[str, Any]:
        if not self._fitted:
            self.fit_competition(comp_id)

        home_team = clean_team_name(home_team)
        away_team = clean_team_name(away_team)

        lambda_h, lambda_a = self.dixon_coles.predict_lambdas(home_team, away_team)
        sim_data = self.monte_carlo.simulate(home_team, away_team, lambda_h, lambda_a)
        val_data = self.value_detector.evaluate_value(sim_data)

        payload = {
            "simulation": sim_data,
            "value_analysis": val_data
        }
        return payload

    def simulate_next_fixtures(
        self,
        comp_id: int = 84,
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        if not self._fitted:
            self.fit_competition(comp_id)

        upcoming = self.db.get_upcoming_matches(comp_id)
        results = []

        for m in upcoming[:limit]:
            h = m['equipo_local']
            a = m['equipo_visitante']
            sim_res = self.simulate_fixture(h, a, comp_id=comp_id)
            sim_res['fixture_info'] = {
                "match_id": m.get('id'),
                "jornada": m.get('jornada'),
                "fecha_hora": m.get('fecha_hora')
            }
            results.append(sim_res)

        return results

    def export_simulation_json(
        self,
        sim_payload: Dict[str, Any],
        output_path: Optional[str] = None
    ) -> str:
        sim = sim_payload.get("simulation", {})
        h = sim.get("home_team", "home").lower().replace(" ", "_")
        a = sim.get("away_team", "away").lower().replace(" ", "_")

        if not output_path:
            out_dir = os.path.join(OUTPUT_DIR, "simulations")
            os.makedirs(out_dir, exist_ok=True)
            output_path = os.path.join(out_dir, f"sim_{h}_vs_{a}.json")
        else:
            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(sim_payload, f, ensure_ascii=False, indent=2)

        return output_path
