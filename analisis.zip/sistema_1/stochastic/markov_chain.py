import random
from typing import Dict, Any, Tuple, List

class MarkovMatchSimulator:
    """
    Simulador de trayectoria de partido minuto a minuto mediante Cadena de Markov:
    - Espacio de estados S(t) = (goles_local, goles_visitante)
    - En cada minuto t de 1 a 90, calcula probabilidades de transición:
      P((g_H + 1, g_A)), P((g_H, g_A + 1)), P((g_H, g_A))
    - Modula las intensidades según el estado del marcador (Game-State dynamics):
      * Si un equipo va perdiendo, aumenta su urgencia ofensiva (Equalizing urge)
      * Si un equipo va ganando, aumenta su solidez de cierre (Lead defending)
    """

    def __init__(
        self,
        lambda_h: float,
        lambda_a: float,
        home_lead_defend_factor: float = 1.0,
        away_equalize_factor: float = 1.0,
        away_lead_defend_factor: float = 1.0,
        home_equalize_factor: float = 1.0
    ):
        self.base_rate_h = lambda_h / 90.0
        self.base_rate_a = lambda_a / 90.0
        self.h_defend = home_lead_defend_factor
        self.a_equalize = away_equalize_factor
        self.a_defend = away_lead_defend_factor
        self.h_equalize = home_equalize_factor

    def simulate_trajectory(self) -> Dict[str, Any]:
        gh = 0
        ga = 0
        timeline: List[Tuple[int, str]] = []  # (minuto, 'home' o 'away')

        for minute in range(1, 91):
            # Dynamic rates based on current game-state
            if gh > ga:
                # Home is leading: Away attacks with higher urgency; Home defends
                rate_h = self.base_rate_h * 0.95
                rate_a = self.base_rate_a * (1.10 * self.a_equalize)
            elif ga > gh:
                # Away is leading: Home attacks with higher urgency; Away defends
                rate_h = self.base_rate_h * (1.10 * self.h_equalize)
                rate_a = self.base_rate_a * 0.95
            else:
                # Level
                rate_h = self.base_rate_h
                rate_a = self.base_rate_a

            r = random.random()
            if r < rate_h:
                gh += 1
                timeline.append((minute, 'home'))
            elif r < (rate_h + rate_a):
                ga += 1
                timeline.append((minute, 'away'))

        return {
            "final_score": (gh, ga),
            "timeline": timeline,
            "total_goals": gh + ga
        }
