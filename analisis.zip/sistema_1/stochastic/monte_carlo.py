import math
import random
from typing import Dict, Any, Tuple, List
from collections import Counter

def poisson_pmf(k: int, lam: float) -> float:
    return (lam ** k) * math.exp(-lam) / math.factorial(k)

class MonteCarloSimulator:
    """
    Motor de simulación Monte Carlo avanzado (N = 10,000 iteraciones):
    - Genera la matriz bivariada de probabilidad de marcadores exactos
    - Aplica corrección de baja anotación Dixon-Coles
    - Deriva probabilidades analíticas y empíricas de todos los mercados principales:
      * 1X2 (Local, Empate, Visitante)
      * Doble Oportunidad (1X, 12, X2)
      * Over / Under (0.5, 1.5, 2.5, 3.5, 4.5)
      * Ambos Equipos Marcarán (BTTS Sí / No)
    - Calcula la cuota justa matemática (Fair Odd = 1 / P) para cada mercado
    """

    def __init__(self, n_simulations: int = 10000):
        self.n_sims = n_simulations

    def simulate(
        self,
        home_team: str,
        away_team: str,
        lambda_h: float,
        lambda_a: float,
        rho: float = -0.05
    ) -> Dict[str, Any]:
        max_goals = 8

        # 1. Construir grilla bivariada Dixon-Coles
        grid: Dict[Tuple[int, int], float] = {}
        total_p = 0.0

        for x in range(max_goals + 1):
            for y in range(max_goals + 1):
                p = poisson_pmf(x, lambda_h) * poisson_pmf(y, lambda_a)
                # Corrección Dixon-Coles
                if x == 0 and y == 0:
                    p *= max(0.0, 1.0 - (lambda_h * lambda_a * rho))
                elif x == 1 and y == 0:
                    p *= max(0.0, 1.0 + (lambda_a * rho))
                elif x == 0 and y == 1:
                    p *= max(0.0, 1.0 + (lambda_h * rho))
                elif x == 1 and y == 1:
                    p *= max(0.0, 1.0 - rho)

                p = max(0.0, p)
                grid[(x, y)] = p
                total_p += p

        # Normalizar probabilidades
        for k in grid:
            grid[k] /= total_p

        # 2. Muestreo estocástico Monte Carlo (N = 10,000)
        items = list(grid.items())
        cum_probs = []
        c = 0.0
        for _, p in items:
            c += p
            cum_probs.append(c)

        sample_counts = Counter()
        for _ in range(self.n_sims):
            r = random.random()
            for idx, cp in enumerate(cum_probs):
                if r <= cp:
                    sample_counts[items[idx][0]] += 1
                    break

        # 3. Derivación de mercados probabilísticos
        n = float(self.n_sims)
        h_wins = sum(cnt for (x, y), cnt in sample_counts.items() if x > y)
        draws = sum(cnt for (x, y), cnt in sample_counts.items() if x == y)
        a_wins = sum(cnt for (x, y), cnt in sample_counts.items() if x < y)

        prob_1 = h_wins / n
        prob_x = draws / n
        prob_2 = a_wins / n

        prob_1x = prob_1 + prob_x
        prob_x2 = prob_x + prob_2
        prob_12 = prob_1 + prob_2

        # Over / Under
        lines = [0.5, 1.5, 2.5, 3.5, 4.5]
        over_under = {}
        for line in lines:
            over_cnt = sum(cnt for (x, y), cnt in sample_counts.items() if (x + y) > line)
            p_over = over_cnt / n
            p_under = 1.0 - p_over
            over_under[str(line)] = {
                "over": round(p_over, 4),
                "under": round(p_under, 4),
                "fair_odd_over": round(1.0 / p_over, 2) if p_over > 0 else 99.0,
                "fair_odd_under": round(1.0 / p_under, 2) if p_under > 0 else 99.0
            }

        # BTTS (Ambos marcan)
        btts_cnt = sum(cnt for (x, y), cnt in sample_counts.items() if x > 0 and y > 0)
        p_btts_yes = btts_cnt / n
        p_btts_no = 1.0 - p_btts_yes

        # Top 10 marcadores exactos
        top_scores = []
        for (x, y), cnt in sample_counts.most_common(10):
            p_score = cnt / n
            top_scores.append({
                "score": f"{x} - {y}",
                "count": cnt,
                "probability": round(p_score, 4),
                "percentage": f"{round(p_score * 100, 1)}%",
                "fair_odd": round(1.0 / p_score, 2) if p_score > 0 else 99.0
            })

        return {
            "match": f"{home_team} vs {away_team}",
            "home_team": home_team,
            "away_team": away_team,
            "expected_goals": {
                "home_lambda": lambda_h,
                "away_lambda": lambda_a,
                "total_expected_goals": round(lambda_h + lambda_a, 2)
            },
            "simulations_run": self.n_sims,
            "markets": {
                "1x2": {
                    "home_win": {
                        "probability": round(prob_1, 4),
                        "percentage": f"{round(prob_1 * 100, 1)}%",
                        "fair_odd": round(1.0 / prob_1, 2) if prob_1 > 0 else 99.0
                    },
                    "draw": {
                        "probability": round(prob_x, 4),
                        "percentage": f"{round(prob_x * 100, 1)}%",
                        "fair_odd": round(1.0 / prob_x, 2) if prob_x > 0 else 99.0
                    },
                    "away_win": {
                        "probability": round(prob_2, 4),
                        "percentage": f"{round(prob_2 * 100, 1)}%",
                        "fair_odd": round(1.0 / prob_2, 2) if prob_2 > 0 else 99.0
                    }
                },
                "double_chance": {
                    "1X": {
                        "probability": round(prob_1x, 4),
                        "percentage": f"{round(prob_1x * 100, 1)}%",
                        "fair_odd": round(1.0 / prob_1x, 2) if prob_1x > 0 else 99.0
                    },
                    "12": {
                        "probability": round(prob_12, 4),
                        "percentage": f"{round(prob_12 * 100, 1)}%",
                        "fair_odd": round(1.0 / prob_12, 2) if prob_12 > 0 else 99.0
                    },
                    "X2": {
                        "probability": round(prob_x2, 4),
                        "percentage": f"{round(prob_x2 * 100, 1)}%",
                        "fair_odd": round(1.0 / prob_x2, 2) if prob_x2 > 0 else 99.0
                    }
                },
                "over_under": over_under,
                "btts": {
                    "yes": {
                        "probability": round(p_btts_yes, 4),
                        "percentage": f"{round(p_btts_yes * 100, 1)}%",
                        "fair_odd": round(1.0 / p_btts_yes, 2) if p_btts_yes > 0 else 99.0
                    },
                    "no": {
                        "probability": round(p_btts_no, 4),
                        "percentage": f"{round(p_btts_no * 100, 1)}%",
                        "fair_odd": round(1.0 / p_btts_no, 2) if p_btts_no > 0 else 99.0
                    }
                }
            },
            "top_scorelines": top_scores
        }
