"""
Motor Estocástico y de Simulación FAIS (Sistema 1).
Implementa Dixon-Coles, Cadenas de Markov de 90 minutos,
Simulación Monte Carlo (N=10,000) y Detección de Valor vs Cuotas BetPlay.
"""

from .engine import StochasticEngine

__all__ = ["StochasticEngine"]
