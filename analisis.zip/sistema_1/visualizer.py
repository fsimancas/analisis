from typing import List, Dict, Any

def format_table(headers: List[str], rows: List[List[Any]]) -> str:
    """Alinea limpiamente una tabla de texto ASCII."""
    str_rows = [[str(cell) for cell in row] for row in rows]
    col_widths = [len(h) for h in headers]
    for row in str_rows:
        for idx, cell in enumerate(row):
            if idx < len(col_widths):
                col_widths[idx] = max(col_widths[idx], len(cell))
            else:
                col_widths.append(len(cell))

    header_line = "  ".join(h.ljust(col_widths[i]) if i < 2 else h.rjust(col_widths[i]) for i, h in enumerate(headers))
    separator = "  ".join("-" * col_widths[i] for i in range(len(headers)))
    data_lines = []
    for r in str_rows:
        line = "  ".join(r[i].ljust(col_widths[i]) if i < 2 else r[i].rjust(col_widths[i]) for i in range(len(r)))
        data_lines.append(line)

    return f"{header_line}\n{separator}\n" + "\n".join(data_lines)


class CLIReportVisualizer:
    """
    Renderiza todas las secciones analíticas en la terminal
    emulando la interfaz y estructura de SoccerStats latest.asp.
    """

    @staticmethod
    def render(data: Dict[str, Any]) -> str:
        lines = []
        comp = data.get('competition', {})
        ov = data.get('league_overview', {})
        table = data.get('league_table', [])
        avg = data.get('league_table_average', {})
        sub = data.get('tables_overview', {})
        seg = data.get('segments_table', {})
        pm = data.get('prematch_stats', [])
        gt = data.get('goal_times_and_leads', {})
        sc = data.get('full_time_scores', {})

        comp_name = comp.get('nombre_flashscore', 'Competición')
        country = comp.get('pais_nombre', '')

        lines.append("=" * 88)
        lines.append(f" SOCCERSTATS REVERSE ENGINEERING REPORT: {comp_name.upper()} ({country.upper()})")
        lines.append("=" * 88)
        lines.append(f"{ov.get('matches_played')} matches played / {ov.get('total_matches')}    {ov.get('goals_per_match')} goals per match    ({ov.get('completion_pct')} completed)")
        lines.append("-" * 88)

        # 1. League Table
        lines.append("\n[+] LEAGUE TABLE:")
        headers = ["#", "Team", "GP", "W", "D", "L", "GF", "GA", "GD", "Pts", "PPG", "last 8", "CS", "SR", "MPP"]
        rows = []
        for r in table:
            sign = "+" if r['GD'] > 0 else ""
            rows.append([
                r['rank'], r['team'], r['GP'], r['W'], r['D'], r['L'], r['GF'], r['GA'],
                f"{sign}{r['GD']}", r['Pts'], f"{r['PPG']:.2f}", f"{r['last_8']:.2f}",
                r['CS'], r['SR'], r['MPP']
            ])
        if avg:
            rows.append([
                "-", avg.get('team', 'Average'), avg.get('GP'), avg.get('W'), avg.get('D'), avg.get('L'),
                avg.get('GF'), avg.get('GA'), avg.get('GD'), avg.get('Pts'), f"{avg.get('PPG'):.2f}",
                f"{avg.get('last_8'):.2f}", avg.get('CS'), avg.get('SR'), avg.get('MPP')
            ])
        lines.append(format_table(headers, rows))
        lines.append("PPG: Points Per Game, last 8: PPG last 8 matches, CS: Clean Sheets, SR: Scoring Rate, MPP: Maximum Possible Points")

        # 2. Pre-Match Stats
        if pm:
            lines.append("\n" + "-" * 88)
            lines.append("[+] PRE-MATCH STATS (Home results of home team / Away results of away team):")
            pm_headers = ["Cond.", "Team", "% PPG", "GF", "GA", "TG", "2.5+", "Last 4"]
            for match in pm[:6]:
                ht = match['home_team']
                at = match['away_team']
                lines.append(f"\nMatch: {ht['team']} vs {at['team']} ({match.get('jornada')}) - {match.get('fecha_hora')}")
                pm_rows = [
                    ["home", ht['team'], ht['pct_ppg'], ht['avg_gf'], ht['avg_ga'], ht['tg'], ht['over_25_pct'], ht['last_4']],
                    ["away", at['team'], at['pct_ppg'], at['avg_gf'], at['avg_ga'], at['tg'], at['over_25_pct'], at['last_4']]
                ]
                lines.append(format_table(pm_headers, pm_rows))

        # 3. Segments Table
        if seg:
            lines.append("\n" + "-" * 88)
            lines.append("[+] SEGMENTS TABLE (5 Quintiles based on leader points):")
            for seg_key in ["1st Segment", "2nd Segment", "3rd Segment", "4th Segment", "5th Segment"]:
                sinfo = seg.get(seg_key, {})
                t_strs = [t['display'] for t in sinfo.get('teams', [])]
                lines.append(f"  * {seg_key.upper()} ({sinfo.get('range')}): {', '.join(t_strs) if t_strs else 'None'}")

        # 4. Tables Overview (12 Mini Rankings)
        if sub:
            lines.append("\n" + "-" * 88)
            lines.append("[+] TABLES OVERVIEW (Top 5 en cada categoría):")
            cat_map = [
                ("Points (Total)", sub.get('points', []), "pts"),
                ("Form (Last 8)", sub.get('form_last_8', []), "pts"),
                ("Home Points", sub.get('home', []), "pts"),
                ("Away Points", sub.get('away', []), "pts"),
                ("Offence (GF Total)", sub.get('offence', []), "GF"),
                ("Defence (GA Total)", sub.get('defence', []), "GA"),
                ("Offence Last 8", sub.get('offence_last_8', []), "GF"),
                ("Defence Last 8", sub.get('defence_last_8', []), "GA"),
                ("Offence Home", sub.get('offence_home', []), "GF"),
                ("Defence Home", sub.get('defence_home', []), "GA"),
                ("Offence Away", sub.get('offence_away', []), "GF"),
                ("Defence Away", sub.get('defence_away', []), "GA"),
            ]
            for cat_title, items, metric_key in cat_map:
                top_items = [f"{idx+1}. {it['team']} ({it[metric_key]})" for idx, it in enumerate(items[:5])]
                lines.append(f"  - {cat_title:<22}: {', '.join(top_items)}")

        # 4. Global Stats & Goals
        lines.append("\n" + "-" * 88)
        lines.append("[+] LEAGUE GLOBAL STATS:")
        lines.append(f"  Home wins:           {ov.get('home_wins_pct'):<10} Over 1.5 goals:      {ov.get('over_1_5_pct')}")
        lines.append(f"  Draws:               {ov.get('draws_pct'):<10} Over 2.5 goals:      {ov.get('over_2_5_pct')}")
        lines.append(f"  Away wins:           {ov.get('away_wins_pct'):<10} Over 3.5 goals:      {ov.get('over_3_5_pct')}")
        lines.append(f"  Total Goals:         {ov.get('total_goals'):<10} Both teams scored:   {ov.get('btts_pct')}")
        lines.append(f"  Home goals / match:  {ov.get('home_goals_per_match'):<10} Away goals / match:  {ov.get('away_goals_per_match')}")

        # 5. Goal Times & Lead Dynamics
        if gt:
            lines.append("\n" + "-" * 88)
            lines.append("[+] GOAL TIMES & LEAD DYNAMICS:")
            lines.append(f"  Home team scored first:                   {gt.get('home_team_scored_first_pct')}")
            lines.append(f"  No goal scored (0-0):                     {gt.get('no_goal_scored_pct')}")
            lines.append(f"  Away team scored first:                   {gt.get('away_team_scored_first_pct')}")
            lines.append(f"  Average minute when home team scored 1st: {gt.get('avg_minute_home_scored_first')}")
            lines.append(f"  Average minute when away team scored 1st: {gt.get('avg_minute_away_scored_first')}")
            lines.append(f"  Home team lead-defending rate:            {gt.get('home_team_lead_defending_rate')}")
            lines.append(f"  Away team lead-defending rate:            {gt.get('away_team_lead_defending_rate')}")
            lines.append(f"  Home team equalizing rate:                {gt.get('home_team_equalizing_rate')}")
            lines.append(f"  Away team equalizing rate:                {gt.get('away_team_equalizing_rate')}")
            lines.append(f"  Home team lead duration (% of minutes):   {gt.get('home_team_lead_duration_pct')}")
            lines.append(f"  Teams level in goals (% of minutes):      {gt.get('teams_level_duration_pct')}")
            lines.append(f"  Away team lead duration (% of minutes):   {gt.get('away_team_lead_duration_pct')}")
            lines.append(f"  Home PPG when home team scored first:     {gt.get('home_ppg_when_scored_first')}")
            lines.append(f"  Away PPG when away team scored first:     {gt.get('away_ppg_when_scored_first')}")

        # 6. Full-time Scores Distribution
        if sc and sc.get('distribution'):
            lines.append("\n" + "-" * 88)
            lines.append("[+] FULL-TIME SCORES FREQUENCY:")
            dist = sc['distribution'][:12]
            sc_headers = ["Score", "Matches", "%", "Score", "Matches", "%"]
            sc_rows = []
            half = len(dist) // 2
            for i in range(half):
                col1 = dist[i]
                col2 = dist[i + half] if (i + half) < len(dist) else {"score": "-", "matches": "-", "percentage": "-"}
                sc_rows.append([
                    col1['score'], col1['matches'], col1['percentage'],
                    col2['score'], col2['matches'], col2['percentage']
                ])
            lines.append(format_table(sc_headers, sc_rows))
            lines.append(f"\n{sc.get('summary_text', '')}")

        lines.append("=" * 88)
        return "\n".join(lines)
