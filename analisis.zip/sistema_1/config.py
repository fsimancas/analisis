import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "betplay_flashscore.db")
DEFAULT_COMP_ID = 84  # LaLiga EA Sports
OUTPUT_DIR = os.path.join(BASE_DIR, "sistema_1", "output")
