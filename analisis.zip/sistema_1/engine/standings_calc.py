import re
from typing import List, Dict, Any, Tuple

def parse_jornada_num(jornada_str: Any) -> int:
    if not jornada_str:
        return 999
    m = re.search(r'\d+', str(jornada_str))
    return int(m.group()) if m else 999

class StandingsCalculator:
    """
    Calcula la tabla de posiciones general (League Table) y las tablas Local/Visitante:
    - GP, W, D, L, GF, GA, GD, Pts
    - Form (PPG últimos 8 partidos)
    - PPG (Puntos por partido)
    - CS (% Clean Sheets / Portería a cero)
    - SR (% Scoring Rate / Tasa de partidos marcando)
    - MPP (Máximos puntos posibles en la temporada)
    - Fila de Promedios Generales de la Liga (Average)
    """

    @staticmethod
    def calculate(
        results: List[Dict[str, Any]],
        upcoming: List[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Dict[str, Any]]]:
        # 1. Identificar todos los equipos
        teams_set = set()
        for m in results:
            teams_set.add(m['equipo_local'])
            teams_set.add(m['equipo_visitante'])
        for m in upcoming:
            teams_set.add(m['equipo_local'])
            teams_set.add(m['equipo_visitante'])
        teams = sorted(list(teams_set))
        num_teams = len(teams)
        total_season_matches_per_team = (num_teams - 1) * 2 if num_teams > 1 else 38

        # 2. Inicializar acumuladores por equipo
        team_stats: Dict[str, Dict[str, Any]] = {}
        for t in teams:
            team_stats[t] = {
                'team': t,
                'home': {'GP': 0, 'W': 0, 'D': 0, 'L': 0, 'GF': 0, 'GA': 0, 'GD': 0, 'Pts': 0, 'CS': 0, 'SR': 0, 'matches': []},
                'away': {'GP': 0, 'W': 0, 'D': 0, 'L': 0, 'GF': 0, 'GA': 0, 'GD': 0, 'Pts': 0, 'CS': 0, 'SR': 0, 'matches': []},
                'total': {'GP': 0, 'W': 0, 'D': 0, 'L': 0, 'GF': 0, 'GA': 0, 'GD': 0, 'Pts': 0, 'CS': 0, 'SR': 0, 'matches': []},
                'upcoming_home': [],
                'upcoming_away': []
            }

        # 3. Orden cronológico de resultados
        sorted_results = sorted(
            results,
            key=lambda m: (parse_jornada_num(m.get('jornada')), str(m.get('fecha_hora', '')))
        )

        # 4. Procesar resultados
        for m in sorted_results:
            home = m['equipo_local']
            away = m['equipo_visitante']
            gh = int(m['goles_local'])
            ga = int(m['goles_visitante'])

            if gh > ga:
                wh, dh, lh = 1, 0, 0
                ptsh = 3
                wa, da, la = 0, 0, 1
                ptsa = 0
            elif gh == ga:
                wh, dh, lh = 0, 1, 0
                ptsh = 1
                wa, da, la = 0, 1, 0
                ptsa = 1
            else:
                wh, dh, lh = 0, 0, 1
                ptsh = 0
                wa, da, la = 1, 0, 0
                ptsa = 3

            csh = 1 if ga == 0 else 0
            srh = 1 if gh > 0 else 0
            csa = 1 if gh == 0 else 0
            sra = 1 if ga > 0 else 0

            # Actualizar local
            sh = team_stats[home]['home']
            sth = team_stats[home]['total']
            for s in (sh, sth):
                s['GP'] += 1
                s['W'] += wh
                s['D'] += dh
                s['L'] += lh
                s['GF'] += gh
                s['GA'] += ga
                s['GD'] += (gh - ga)
                s['Pts'] += ptsh
                s['CS'] += csh
                s['SR'] += srh

            rec_h = {'opponent': away, 'venue': 'home', 'gf': gh, 'ga': ga, 'pts': ptsh, 'jornada': m.get('jornada')}
            team_stats[home]['home']['matches'].append(rec_h)
            team_stats[home]['total']['matches'].append(rec_h)

            # Actualizar visitante
            sa = team_stats[away]['away']
            sta = team_stats[away]['total']
            for s in (sa, sta):
                s['GP'] += 1
                s['W'] += wa
                s['D'] += da
                s['L'] += la
                s['GF'] += ga
                s['GA'] += gh
                s['GD'] += (ga - gh)
                s['Pts'] += ptsa
                s['CS'] += csa
                s['SR'] += sra

            rec_a = {'opponent': home, 'venue': 'away', 'gf': ga, 'ga': gh, 'pts': ptsa, 'jornada': m.get('jornada')}
            team_stats[away]['away']['matches'].append(rec_a)
            team_stats[away]['total']['matches'].append(rec_a)

        # 5. Procesar partidos próximos
        sorted_upcoming = sorted(
            upcoming,
            key=lambda m: (parse_jornada_num(m.get('jornada')), str(m.get('fecha_hora', '')))
        )
        for m in sorted_upcoming:
            h = m['equipo_local']
            a = m['equipo_visitante']
            if h in team_stats:
                team_stats[h]['upcoming_home'].append(m)
            if a in team_stats:
                team_stats[a]['upcoming_away'].append(m)

        # 6. Construir filas de la tabla general
        league_table = []
        for t, data in team_stats.items():
            tot = data['total']
            gp = tot['GP']
            pts = tot['Pts']
            ppg = round(pts / gp, 2) if gp > 0 else 0.0

            # Forma últimos 8 partidos
            last_8 = tot['matches'][-8:]
            pts_last_8 = sum(x['pts'] for x in last_8)
            gp_last_8 = len(last_8)
            last_8_ppg = round(pts_last_8 / gp_last_8, 2) if gp_last_8 > 0 else 0.0

            cs_pct = round((tot['CS'] / gp) * 100) if gp > 0 else 0
            sr_pct = round((tot['SR'] / gp) * 100) if gp > 0 else 0

            remaining_matches = total_season_matches_per_team - gp
            mpp = pts + (3 * max(0, remaining_matches))

            row = {
                'team': t,
                'GP': gp,
                'W': tot['W'],
                'D': tot['D'],
                'L': tot['L'],
                'GF': tot['GF'],
                'GA': tot['GA'],
                'GD': tot['GD'],
                'Pts': pts,
                'PPG': ppg,
                'last_8': last_8_ppg,
                'CS': f"{cs_pct}%",
                'SR': f"{sr_pct}%",
                'MPP': mpp,
                '_raw_cs': cs_pct,
                '_raw_sr': sr_pct
            }
            league_table.append(row)

        # Ordenar por Puntos desc, GD desc, GF desc
        league_table.sort(key=lambda x: (x['Pts'], x['GD'], x['GF']), reverse=True)
        for idx, row in enumerate(league_table, start=1):
            row['rank'] = idx

        # 7. Fila de Promedios (Average row)
        n = len(league_table)
        if n > 0:
            avg_gp = round(sum(r['GP'] for r in league_table) / n, 1)
            avg_w = round(sum(r['W'] for r in league_table) / n, 1)
            avg_d = round(sum(r['D'] for r in league_table) / n, 1)
            avg_l = round(sum(r['L'] for r in league_table) / n, 1)
            avg_gf = round(sum(r['GF'] for r in league_table) / n, 1)
            avg_ga = round(sum(r['GA'] for r in league_table) / n, 1)
            avg_gd = round(sum(r['GD'] for r in league_table) / n, 1)
            avg_pts = round(sum(r['Pts'] for r in league_table) / n, 1)
            avg_ppg = round(sum(r['PPG'] for r in league_table) / n, 2)
            avg_last8 = round(sum(r['last_8'] for r in league_table) / n, 2)
            avg_cs = round(sum(r['_raw_cs'] for r in league_table) / n, 1)
            avg_sr = round(sum(r['_raw_sr'] for r in league_table) / n, 1)

            average_row = {
                'team': 'Average',
                'GP': avg_gp,
                'W': avg_w,
                'D': avg_d,
                'L': avg_l,
                'GF': avg_gf,
                'GA': avg_ga,
                'GD': avg_gd,
                'Pts': avg_pts,
                'PPG': avg_ppg,
                'last_8': avg_last8,
                'CS': f"{avg_cs}%",
                'SR': f"{avg_sr}%",
                'MPP': '-'
            }
        else:
            average_row = {}

        return league_table, average_row, team_stats
