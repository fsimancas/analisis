from typing import List, Dict, Any

class SegmentsCalculator:
    """
    Calcula la Tabla de Segmentos (Segments Table):
    Divide a los equipos en 5 segmentos iguales basados en el puntaje del líder (1er puesto).
    Cada segmento abarca un quinto (20%) del total de puntos del líder.
    - 1st Segment: [Líder - 1/5, Líder]
    - 2nd Segment: [Líder - 2/5, Líder - 1/5]
    - 3rd Segment: [Líder - 3/5, Líder - 2/5]
    - 4th Segment: [Líder - 4/5, Líder - 3/5]
    - 5th Segment: [0, Líder - 4/5]
    """

    @staticmethod
    def calculate(league_table: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not league_table:
            return {}

        max_pts = max((r['Pts'] for r in league_table), default=0)
        if max_pts <= 0:
            max_pts = 1

        seg_width = round(max_pts / 5.0, 1)

        # Boundaries
        b1 = seg_width
        b2 = round(seg_width * 2, 1)
        b3 = round(seg_width * 3, 1)
        b4 = round(seg_width * 4, 1)
        b5 = float(max_pts)

        segments = {
            "5th Segment": {
                "title": "5th Segment",
                "range": f"hasta {b1} pts",
                "min": 0.0,
                "max": b1,
                "teams": []
            },
            "4th Segment": {
                "title": "4th Segment",
                "range": f"de {b1 + 0.1:.1f} a {b2} pts",
                "min": b1,
                "max": b2,
                "teams": []
            },
            "3rd Segment": {
                "title": "3rd Segment",
                "range": f"de {b2 + 0.1:.1f} a {b3} pts",
                "min": b2,
                "max": b3,
                "teams": []
            },
            "2nd Segment": {
                "title": "2nd Segment",
                "range": f"de {b3 + 0.1:.1f} a {b4} pts",
                "min": b3,
                "max": b4,
                "teams": []
            },
            "1st Segment": {
                "title": "1st Segment",
                "range": f"de {b4 + 0.1:.1f} a {max_pts} pts",
                "min": b4,
                "max": b5 + 1.0,
                "teams": []
            }
        }

        # Assign teams
        for row in league_table:
            p = row['Pts']
            entry = {
                "team": row['team'],
                "gp": row['GP'],
                "pts": row['Pts'],
                "display": f"({row['GP']}) {row['Pts']} {row['team']}"
            }
            if p <= b1:
                segments["5th Segment"]["teams"].append(entry)
            elif p <= b2:
                segments["4th Segment"]["teams"].append(entry)
            elif p <= b3:
                segments["3rd Segment"]["teams"].append(entry)
            elif p <= b4:
                segments["2nd Segment"]["teams"].append(entry)
            else:
                segments["1st Segment"]["teams"].append(entry)

        # Order teams inside each segment by Pts desc
        for seg in segments.values():
            seg["teams"].sort(key=lambda x: x["pts"], reverse=True)

        return segments
