from typing import List, Dict, Any

class PreMatchCalculator:
    """
    Calcula las estadísticas Pre-Match (Home / Away) para próximos encuentros:
    Basadas estrictamente en:
    - Rendimiento como Local del equipo local.
    - Rendimiento como Visitante del equipo visitante.
    
    Métricas para cada condición:
    - % Points per game (% PPG relativo a los máximos posibles en casa/fuera)
    - GF (Promedio goles a favor)
    - GA (Promedio goles en contra)
    - TG (Total Goals promedio = GF + GA)
    - 2.5+ (% de partidos con más de 2.5 goles)
    - Last 4 (Racha/Resultados en los últimos 4 partidos en esa condición)
    """

    @staticmethod
    def calculate(
        upcoming_matches: List[Dict[str, Any]],
        team_stats: Dict[str, Dict[str, Any]],
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        prematch_list = []

        for m in upcoming_matches[:limit]:
            home = m['equipo_local']
            away = m['equipo_visitante']

            h_stats = team_stats.get(home, {}).get('home', {})
            a_stats = team_stats.get(away, {}).get('away', {})

            # --- Estadísticas del Local (en casa) ---
            h_gp = h_stats.get('GP', 0)
            h_pts = h_stats.get('Pts', 0)
            h_gf = h_stats.get('GF', 0)
            h_ga = h_stats.get('GA', 0)
            h_matches = h_stats.get('matches', [])

            h_pct_ppg = round((h_pts / (h_gp * 3)) * 100) if h_gp > 0 else 0
            h_avg_gf = round(h_gf / h_gp, 2) if h_gp > 0 else 0.0
            h_avg_ga = round(h_ga / h_gp, 2) if h_gp > 0 else 0.0
            h_tg = round(h_avg_gf + h_avg_ga, 2)
            h_over25_cnt = sum(1 for match in h_matches if (match['gf'] + match['ga']) > 2.5)
            h_over25_pct = round((h_over25_cnt / h_gp) * 100) if h_gp > 0 else 0

            # Last 4 home results: W, D, L
            h_last_4_symbols = []
            for match in h_matches[-4:]:
                if match['pts'] == 3:
                    h_last_4_symbols.append('W')
                elif match['pts'] == 1:
                    h_last_4_symbols.append('D')
                else:
                    h_last_4_symbols.append('L')
            h_last_4_str = "".join(h_last_4_symbols)

            # --- Estadísticas del Visitante (fuera de casa) ---
            a_gp = a_stats.get('GP', 0)
            a_pts = a_stats.get('Pts', 0)
            a_gf = a_stats.get('GF', 0)
            a_ga = a_stats.get('GA', 0)
            a_matches = a_stats.get('matches', [])

            a_pct_ppg = round((a_pts / (a_gp * 3)) * 100) if a_gp > 0 else 0
            a_avg_gf = round(a_gf / a_gp, 2) if a_gp > 0 else 0.0
            a_avg_ga = round(a_ga / a_gp, 2) if a_gp > 0 else 0.0
            a_tg = round(a_avg_gf + a_avg_ga, 2)
            a_over25_cnt = sum(1 for match in a_matches if (match['gf'] + match['ga']) > 2.5)
            a_over25_pct = round((a_over25_cnt / a_gp) * 100) if a_gp > 0 else 0

            a_last_4_symbols = []
            for match in a_matches[-4:]:
                if match['pts'] == 3:
                    a_last_4_symbols.append('W')
                elif match['pts'] == 1:
                    a_last_4_symbols.append('D')
                else:
                    a_last_4_symbols.append('L')
            a_last_4_str = "".join(a_last_4_symbols)

            item = {
                "match_id": m.get('id', ''),
                "jornada": m.get('jornada', ''),
                "fecha_hora": m.get('fecha_hora', ''),
                "home_team": {
                    "team": home,
                    "pct_ppg": f"{h_pct_ppg}%",
                    "avg_gf": f"{h_avg_gf:.2f}",
                    "avg_ga": f"{h_avg_ga:.2f}",
                    "tg": f"{h_tg:.2f}",
                    "over_25_pct": f"{h_over25_pct}%",
                    "last_4": h_last_4_str
                },
                "away_team": {
                    "team": away,
                    "pct_ppg": f"{a_pct_ppg}%",
                    "avg_gf": f"{a_avg_gf:.2f}",
                    "avg_ga": f"{a_avg_ga:.2f}",
                    "tg": f"{a_tg:.2f}",
                    "over_25_pct": f"{a_over25_pct}%",
                    "last_4": a_last_4_str
                }
            }
            prematch_list.append(item)

        return prematch_list
