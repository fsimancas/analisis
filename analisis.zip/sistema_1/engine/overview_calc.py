from typing import List, Dict, Any

class OverviewCalculator:
    """
    Calcula las estadísticas globales de la liga:
    - Partidos jugados / programados y % completado
    - Distribución de resultados: % Victorias Local, % Empates, % Victorias Visitante
    - Totales y promedios de goles (General, Local, Visitante)
    - Mercados de goles: Over 1.5, Over 2.5, Over 3.5 y Ambos Marcan (BTTS)
    """

    @staticmethod
    def calculate(results: List[Dict[str, Any]], upcoming: List[Dict[str, Any]]) -> Dict[str, Any]:
        total_played = len(results)
        total_scheduled = total_played + len(upcoming)
        completion_pct = round((total_played / total_scheduled) * 100.0, 1) if total_scheduled > 0 else 0.0

        if total_played == 0:
            return {
                "matches_played": 0,
                "total_matches": total_scheduled,
                "completion_pct": "0.0%",
                "home_wins_pct": "0%",
                "draws_pct": "0%",
                "away_wins_pct": "0%",
                "total_goals": 0,
                "goals_per_match": 0.0,
                "home_goals_per_match": 0.0,
                "away_goals_per_match": 0.0,
                "over_1_5_pct": "0%",
                "over_2_5_pct": "0%",
                "over_3_5_pct": "0%",
                "btts_pct": "0%"
            }

        home_wins = sum(1 for m in results if m['goles_local'] > m['goles_visitante'])
        draws = sum(1 for m in results if m['goles_local'] == m['goles_visitante'])
        away_wins = sum(1 for m in results if m['goles_local'] < m['goles_visitante'])

        home_goals = sum(m['goles_local'] for m in results)
        away_goals = sum(m['goles_visitante'] for m in results)
        total_goals = home_goals + away_goals

        over_1_5 = sum(1 for m in results if (m['goles_local'] + m['goles_visitante']) > 1.5)
        over_2_5 = sum(1 for m in results if (m['goles_local'] + m['goles_visitante']) > 2.5)
        over_3_5 = sum(1 for m in results if (m['goles_local'] + m['goles_visitante']) > 3.5)
        btts = sum(1 for m in results if m['goles_local'] > 0 and m['goles_visitante'] > 0)

        return {
            "matches_played": total_played,
            "total_matches": total_scheduled,
            "completion_pct": f"{completion_pct}%",
            "home_wins_pct": f"{int(round((home_wins / total_played) * 100))}%",
            "draws_pct": f"{int(round((draws / total_played) * 100))}%",
            "away_wins_pct": f"{int(round((away_wins / total_played) * 100))}%",
            "total_goals": total_goals,
            "goals_per_match": round(total_goals / total_played, 2),
            "home_goals_per_match": round(home_goals / total_played, 2),
            "away_goals_per_match": round(away_goals / total_played, 2),
            "over_1_5_pct": f"{int(round((over_1_5 / total_played) * 100))}%",
            "over_2_5_pct": f"{int(round((over_2_5 / total_played) * 100))}%",
            "over_3_5_pct": f"{int(round((over_3_5 / total_played) * 100))}%",
            "btts_pct": f"{int(round((btts / total_played) * 100))}%"
        }
