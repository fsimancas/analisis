from typing import List, Dict, Any
from collections import Counter

class ScoresCalculator:
    """
    Calcula la distribución de resultados a tiempo completo (Full-Time Scores):
    - Marcador exacto (FT score)
    - Conteo de partidos
    - Porcentaje sobre el total de partidos jugados
    - Identificación del resultado más frecuente
    """

    @staticmethod
    def calculate(results: List[Dict[str, Any]]) -> Dict[str, Any]:
        total_matches = len(results)
        if total_matches == 0:
            return {"distribution": [], "most_frequent": None}

        score_counter = Counter(f"{m['goles_local']} - {m['goles_visitante']}" for m in results)
        
        distribution = []
        for score, count in score_counter.most_common():
            pct = round((count / total_matches) * 100)
            distribution.append({
                "score": score,
                "matches": count,
                "percentage": f"{pct}%",
                "raw_pct": round((count / total_matches) * 100, 1)
            })

        most_freq = distribution[0] if distribution else None
        summary_text = (
            f"El resultado más frecuente en lo que va de temporada ha sido {most_freq['score']}, "
            f"registrado en {most_freq['matches']} partidos ({most_freq['percentage']})."
            if most_freq else "No hay partidos registrados."
        )

        return {
            "distribution": distribution,
            "most_frequent": most_freq,
            "summary_text": summary_text
        }
