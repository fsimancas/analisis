"""
Módulos de cálculo analítico e ingeniería inversa de SoccerStats.
"""
