from typing import Dict, List, Any

class SubtablesCalculator:
    """
    Calcula las 12 sub-tablas de ranking de SoccerStats (Tables overview):
    1. Points (Puntos totales)
    2. Form (last 8) (Puntos en los últimos 8 partidos)
    3. Home (Puntos como local)
    4. Away (Puntos como visitante)
    5. Offence (Goles a favor totales)
    6. Defence (Goles en contra totales, menor es mejor)
    7. Offence (last 8) (Goles a favor en los últimos 8 partidos)
    8. Defence (last 8) (Goles en contra en los últimos 8 partidos, menor es mejor)
    9. Offence (home) (Goles a favor como local)
    10. Defence (home) (Goles en contra como local, menor es mejor)
    11. Offence (away) (Goles a favor como visitante)
    12. Defence (away) (Goles en contra como visitante, menor es mejor)
    """

    @staticmethod
    def calculate(team_stats: Dict[str, Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        # Helper extraction
        points_list = []
        form_list = []
        home_list = []
        away_list = []
        offence_list = []
        defence_list = []
        offence_last8_list = []
        defence_last8_list = []
        offence_home_list = []
        defence_home_list = []
        offence_away_list = []
        defence_away_list = []

        for t, data in team_stats.items():
            tot = data['total']
            h = data['home']
            a = data['away']

            # Total points
            points_list.append({'team': t, 'GP': tot['GP'], 'pts': tot['Pts']})

            # Form last 8
            last_8 = tot['matches'][-8:]
            pts_last_8 = sum(m['pts'] for m in last_8)
            form_list.append({'team': t, 'GP': len(last_8), 'pts': pts_last_8})

            # Home / Away points
            home_list.append({'team': t, 'GP': h['GP'], 'pts': h['Pts']})
            away_list.append({'team': t, 'GP': a['GP'], 'pts': a['Pts']})

            # Offence / Defence total
            offence_list.append({'team': t, 'GP': tot['GP'], 'GF': tot['GF']})
            defence_list.append({'team': t, 'GP': tot['GP'], 'GA': tot['GA']})

            # Offence / Defence last 8
            gf_last_8 = sum(m['gf'] for m in last_8)
            ga_last_8 = sum(m['ga'] for m in last_8)
            offence_last8_list.append({'team': t, 'GP': len(last_8), 'GF': gf_last_8})
            defence_last8_list.append({'team': t, 'GP': len(last_8), 'GA': ga_last_8})

            # Offence / Defence Home
            offence_home_list.append({'team': t, 'GP': h['GP'], 'GF': h['GF']})
            defence_home_list.append({'team': t, 'GP': h['GP'], 'GA': h['GA']})

            # Offence / Defence Away
            offence_away_list.append({'team': t, 'GP': a['GP'], 'GF': a['GF']})
            defence_away_list.append({'team': t, 'GP': a['GP'], 'GA': a['GA']})

        # Sorting
        points_list.sort(key=lambda x: x['pts'], reverse=True)
        form_list.sort(key=lambda x: x['pts'], reverse=True)
        home_list.sort(key=lambda x: x['pts'], reverse=True)
        away_list.sort(key=lambda x: x['pts'], reverse=True)

        offence_list.sort(key=lambda x: x['GF'], reverse=True)
        defence_list.sort(key=lambda x: x['GA'])  # ascending: fewest conceded is best

        offence_last8_list.sort(key=lambda x: x['GF'], reverse=True)
        defence_last8_list.sort(key=lambda x: x['GA'])

        offence_home_list.sort(key=lambda x: x['GF'], reverse=True)
        defence_home_list.sort(key=lambda x: x['GA'])

        offence_away_list.sort(key=lambda x: x['GF'], reverse=True)
        defence_away_list.sort(key=lambda x: x['GA'])

        return {
            "points": points_list,
            "form_last_8": form_list,
            "home": home_list,
            "away": away_list,
            "offence": offence_list,
            "defence": defence_list,
            "offence_last_8": offence_last8_list,
            "defence_last_8": defence_last8_list,
            "offence_home": offence_home_list,
            "defence_home": defence_home_list,
            "offence_away": offence_away_list,
            "defence_away": defence_away_list
        }
