import re
from typing import List, Dict, Any

def parse_minute(min_str: Any) -> int:
    if not min_str:
        return 90
    m = re.search(r'(\d+)(?:\+(\d+))?', str(min_str))
    if m:
        base = int(m.group(1))
        extra = int(m.group(2)) if m.group(2) else 0
        return base + extra
    return 90

class GoalTimesCalculator:
    """
    Calcula las dinámicas de tiempo de gol y liderazgo (Goal Times / Lead Durations):
    - % Equipo local marcó primero
    - % Sin goles (0 - 0)
    - % Equipo visitante marcó primero
    - Minuto promedio cuando el local marcó primero
    - Minuto promedio cuando el visitante marcó primero
    - Tasa de defensa de ventaja local (Home team lead-defending rate)
    - Tasa de defensa de ventaja visitante (Away team lead-defending rate)
    - Tasa de empate/remontada local (Home team equalizing rate)
    - Tasa de empate/remontada visitante (Away team equalizing rate)
    - Duración de ventaja del local (% minutos en ventaja)
    - Equipos empatados (% minutos empatados)
    - Duración de ventaja del visitante (% minutos en ventaja)
    - PPG del local cuando marcó primero
    - PPG del visitante cuando marcó primero
    """

    @staticmethod
    def calculate(
        results: List[Dict[str, Any]],
        incidents_by_match: Dict[str, List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        total_matches = len(results)
        if total_matches == 0:
            return {}

        home_first_count = 0
        away_first_count = 0
        no_goal_count = 0

        home_first_minutes: List[int] = []
        away_first_minutes: List[int] = []

        home_first_wins = 0
        home_first_pts: List[int] = []

        away_first_wins = 0
        away_first_pts: List[int] = []

        # Equalizing rate
        home_trailed_count = 0   # Matches where away scored first
        home_equalized_count = 0 # Matches where home scored at least one goal after trailing

        away_trailed_count = 0   # Matches where home scored first
        away_equalized_count = 0 # Matches where away scored at least one goal after trailing

        # Lead minutes (90 min per match)
        total_home_lead_mins = 0
        total_away_lead_mins = 0
        total_draw_mins = 0

        for m in results:
            mid = m['id']
            gh = int(m['goles_local'])
            ga = int(m['goles_visitante'])
            incs = incidents_by_match.get(mid, [])

            # Extract goal events chronologically
            goals = []
            for inc in incs:
                periodo = str(inc.get('periodo', ''))
                min_str = inc.get('minuto', '')
                equipo = inc.get('equipo', '')
                tipo = str(inc.get('tipo', ''))
                nota = str(inc.get('nota', ''))

                is_goal = False
                if tipo in ('Gol', 'Gol en propia puerta'):
                    is_goal = True
                elif tipo == 'evento':
                    if 'Tarjeta' not in nota and 'Sustitución' not in nota:
                        is_goal = True

                if is_goal and equipo in ('home', 'away'):
                    m_minute = parse_minute(min_str)
                    goals.append((m_minute, equipo))

            goals.sort(key=lambda x: x[0])

            # Lead duration timeline across 90 minutes
            curr_h = 0
            curr_a = 0
            curr_m = 0
            h_lead_m = 0
            a_lead_m = 0
            draw_m = 0

            for gmin, geq in goals:
                dur = min(gmin, 90) - curr_m
                if dur > 0:
                    if curr_h > curr_a:
                        h_lead_m += dur
                    elif curr_a > curr_h:
                        a_lead_m += dur
                    else:
                        draw_m += dur
                curr_m = min(gmin, 90)
                if geq == 'home':
                    curr_h += 1
                else:
                    curr_a += 1

            rem = 90 - curr_m
            if rem > 0:
                if curr_h > curr_a:
                    h_lead_m += rem
                elif curr_a > curr_h:
                    a_lead_m += rem
                else:
                    draw_m += rem

            total_home_lead_mins += h_lead_m
            total_away_lead_mins += a_lead_m
            total_draw_mins += draw_m

            # First goal statistics
            if gh == 0 and ga == 0:
                no_goal_count += 1
            elif goals:
                first_g = goals[0]
                if first_g[1] == 'home':
                    home_first_count += 1
                    home_first_minutes.append(first_g[0])
                    away_trailed_count += 1

                    if gh > ga:
                        home_first_wins += 1
                        home_first_pts.append(3)
                    elif gh == ga:
                        home_first_pts.append(1)
                    else:
                        home_first_pts.append(0)

                    # Equalizing rate for away: did away score at least 1 goal?
                    if ga > 0:
                        away_equalized_count += 1

                else:  # away scored first
                    away_first_count += 1
                    away_first_minutes.append(first_g[0])
                    home_trailed_count += 1

                    if ga > gh:
                        away_first_wins += 1
                        away_first_pts.append(3)
                    elif gh == ga:
                        away_first_pts.append(1)
                    else:
                        away_first_pts.append(0)

                    # Equalizing rate for home: did home score at least 1 goal?
                    if gh > 0:
                        home_equalized_count += 1
            else:
                # Fallback if incidents were missing but score was not 0-0
                if gh > 0 and ga == 0:
                    home_first_count += 1
                    home_first_wins += 1
                    home_first_pts.append(3)
                    away_trailed_count += 1
                elif ga > 0 and gh == 0:
                    away_first_count += 1
                    away_first_wins += 1
                    away_first_pts.append(3)
                    home_trailed_count += 1

        total_mins_all = total_matches * 90
        avg_home_first_min = round(sum(home_first_minutes) / len(home_first_minutes)) if home_first_minutes else 0
        avg_away_first_min = round(sum(away_first_minutes) / len(away_first_minutes)) if away_first_minutes else 0

        home_defend_rate = round((home_first_wins / home_first_count) * 100) if home_first_count > 0 else 0
        away_defend_rate = round((away_first_wins / away_first_count) * 100) if away_first_count > 0 else 0

        home_equalize_rate = round((home_equalized_count / home_trailed_count) * 100) if home_trailed_count > 0 else 0
        away_equalize_rate = round((away_equalized_count / away_trailed_count) * 100) if away_trailed_count > 0 else 0

        home_lead_dur_pct = round((total_home_lead_mins / total_mins_all) * 100) if total_mins_all > 0 else 0
        draw_dur_pct = round((total_draw_mins / total_mins_all) * 100) if total_mins_all > 0 else 0
        away_lead_dur_pct = round((total_away_lead_mins / total_mins_all) * 100) if total_mins_all > 0 else 0

        home_ppg_scored_first = round(sum(home_first_pts) / len(home_first_pts), 2) if home_first_pts else 0.0
        away_ppg_scored_first = round(sum(away_first_pts) / len(away_first_pts), 2) if away_first_pts else 0.0

        return {
            "home_team_scored_first_pct": f"{round((home_first_count / total_matches) * 100)}%",
            "no_goal_scored_pct": f"{round((no_goal_count / total_matches) * 100)}%",
            "away_team_scored_first_pct": f"{round((away_first_count / total_matches) * 100)}%",
            "avg_minute_home_scored_first": f"{avg_home_first_min} min.",
            "avg_minute_away_scored_first": f"{avg_away_first_min} min.",
            "home_team_lead_defending_rate": f"{home_defend_rate}%",
            "away_team_lead_defending_rate": f"{away_defend_rate}%",
            "home_team_equalizing_rate": f"{home_equalize_rate}%",
            "away_team_equalizing_rate": f"{away_equalize_rate}%",
            "home_team_lead_duration_pct": f"{home_lead_dur_pct}%",
            "teams_level_duration_pct": f"{draw_dur_pct}%",
            "away_team_lead_duration_pct": f"{away_lead_dur_pct}%",
            "home_ppg_when_scored_first": home_ppg_scored_first,
            "away_ppg_when_scored_first": away_ppg_scored_first
        }
