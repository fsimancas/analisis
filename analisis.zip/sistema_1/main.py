import sys
import os
import argparse
import json

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(CURRENT_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from sistema_1.analyzer import SoccerStatsAnalyzer
from sistema_1.visualizer import CLIReportVisualizer
from sistema_1.profiles.engine import TeamProfileEngine
from sistema_1.profiles.visualizer import ProfileVisualizer
from sistema_1.stochastic.engine import StochasticEngine
from sistema_1.stochastic.visualizer import StochasticVisualizer
from sistema_1.scanner.market_screener import GlobalMarketScreener
from sistema_1.scanner.visualizer import GlobalScannerVisualizer
from sistema_1.ledger.ledger_manager import PredictionLedger
from sistema_1.config import DEFAULT_COMP_ID, DB_PATH, OUTPUT_DIR

def main():
    parser = argparse.ArgumentParser(
        description="Sistema 1 - Motor de Analítica, Perfiles, Escaneo Global y Simulación Estocástica FAIS"
    )
    parser.add_argument(
        "--comp",
        type=int,
        default=DEFAULT_COMP_ID,
        help=f"ID de la competición a analizar (por defecto: {DEFAULT_COMP_ID} para LaLiga EA Sports)"
    )
    parser.add_argument(
        "--team",
        type=str,
        default=None,
        help="Nombre del equipo a perfilar (ej. 'Barcelona', 'Real Madrid')"
    )
    parser.add_argument(
        "--match",
        type=str,
        default=None,
        help="Partido a simular estocásticamente: 'Local vs Visitante' (ej. 'Barcelona vs Real Madrid')"
    )
    parser.add_argument(
        "--sim-next",
        type=int,
        default=None,
        help="Simular con Monte Carlo los próximos N partidos del fixture (ej. 5)"
    )
    parser.add_argument(
        "--sims",
        type=int,
        default=10000,
        help="Número de iteraciones Monte Carlo por partido (por defecto: 10,000)"
    )
    parser.add_argument(
        "--screen-markets",
        action="store_true",
        help="Escanear todas las competiciones (197) y árbitros (2,215) para clasificar nichos de mercado (Over 1.5, Under 2.5, BTTS, Tarjetas, Empates)"
    )
    parser.add_argument(
        "--ledger",
        action="store_true",
        help="Consultar la bitácora de predicciones walk-forward (FAIS Walk-Forward Ledger)"
    )
    parser.add_argument(
        "--settle-ledger",
        action="store_true",
        help="Resolver y liquidar automáticamente predicciones pendientes contra resultados finales en SQLite"
    )
    parser.add_argument(
        "--db",
        type=str,
        default=DB_PATH,
        help="Ruta a la base de datos SQLite 'betplay_flashscore.db'"
    )
    parser.add_argument(
        "--export",
        choices=["json", "none"],
        default="json",
        help="Exportar el resultado a archivo JSON (por defecto: json)"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="No imprimir el reporte en consola (solo exportar)"
    )

    args = parser.parse_args()

    # MODO LEDGER: Consulta de bitácora walk-forward
    if args.ledger:
        ledger = PredictionLedger(db_path=args.db)
        records = ledger.list_all_predictions()
        print(f"\n================================================================================")
        print(f"       BITÁCORA DE PREDICCIONES Y AUDITORÍA WALK-FORWARD (FAIS LEDGER)         ")
        print(f"================================================================================")
        print(f"Total registros: {len(records)}\n")
        for idx, r in enumerate(records, 1):
            if r.get('type') == 'PARLAY':
                print(f"[{idx}] COMBINADA: {r.get('strategy_name')} | ID: {r.get('prediction_id')}")
                print(f"    Fecha Objetivo: {r.get('target_date')} | Estado: {r.get('status')}")
                print(f"    Cuota Total BetPlay: {r.get('total_odd')} | Prob. Conjunta Modelo: {r.get('model_joint_prob')*100:.1f}%")
                print(f"    Edge Conjunto: {r.get('joint_edge')} | Valor Esperado (EV): {r.get('joint_ev')}")
                print(f"    Estrategia: {r.get('description')}")
                print(f"    Líneas de la Combinada (4 Eventos):")
                for leg_idx, leg in enumerate(r.get('legs', []), 1):
                    line_str = f" {leg.get('line')}" if leg.get('line') is not None else ""
                    print(f"      {leg_idx}. {leg.get('home_team')} vs {leg.get('away_team')} ({leg.get('competition')})")
                    print(f"         Mercado: {leg.get('market')} -> {leg.get('selection')}{line_str} @ Cuota {leg.get('odd')} (Prob: {leg.get('model_prob')*100:.1f}%)")
                if r.get('status') == 'SETTLED':
                    out = r.get('outcome', {})
                    print(f"    [LIQUIDADO] Acierto: {out.get('all_won')} | P&L: {out.get('pnl_units')}u | ROI: {out.get('roi_pct')}")
            else:
                print(f"[{idx}] PARTIDO SIMPLE: {r.get('home_team')} vs {r.get('away_team')} | ID: {r.get('prediction_id')}")
                print(f"    Competición: {r.get('competition')} ({r.get('jornada')}) | Estado: {r.get('status')}")
                print(f"    Kickoff: {r.get('kickoff')} | Modelo: {r.get('model_version')}")
                xg = r.get('expected_goals', {})
                print(f"    xG Esperados: Local {xg.get('home_lambda', '-')} | Visitante {xg.get('away_lambda', '-')} | Total: {xg.get('total', '-')}")
                print(f"    Señales Registradas ({len(r.get('signals', []))} mercados con Edge):")
                for s in r.get('signals', []):
                    print(f"      • {s.get('market')}: Cuota BetPlay {s.get('betplay_odd')} | Cuota Justa {s.get('fair_odd')} | Edge {s.get('edge')} | EV {s.get('ev')}")
                if r.get('status') == 'SETTLED':
                    out = r.get('outcome', {})
                    print(f"    [LIQUIDADO] Marcador: {out.get('actual_score')} | P&L: {out.get('pnl_units')}u | ROI: {out.get('roi_pct')}")
            print("-" * 80)
        return

    # MODO SETTLE: Liquidación de predicciones
    if args.settle_ledger:
        ledger = PredictionLedger(db_path=args.db)
        res = ledger.settle_predictions()
        print(f"\n================================================================================")
        print(f"                LIQUIDACIÓN AUTOMÁTICA DE PREDICCIONES (FAIS)                   ")
        print(f"================================================================================")
        print(f"Predicciones liquidadas en esta corrida: {res.get('total_settled_now')}")
        print(f"P&L acumulado: {res.get('accumulated_pnl_units')} unidades")
        print(f"Stake total apostado: {res.get('accumulated_staked_units')} unidades")
        print(f"ROI acumulado: {res.get('accumulated_roi')}")
        return

    # MODO 0: Escáner Global de Mercados (Competiciones, Árbitros, Nichos de Oportunidad)
    if args.screen_markets:
        screener = GlobalMarketScreener(db_path=args.db)
        data = screener.generate_market_opportunities()

        if not args.quiet:
            cli_text = GlobalScannerVisualizer.render(data)
            print(cli_text)

        if args.export == "json":
            out_dir = os.path.join(OUTPUT_DIR, "scanner")
            os.makedirs(out_dir, exist_ok=True)
            out_file = os.path.join(out_dir, "oportunidades_mercados_global.json")
            with open(out_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print(f"\n[✓] Oportunidades globales exportadas exitosamente a: {out_file}")
        return

    # MODO 1: Simulación de un partido específico con Monte Carlo (Dixon-Coles + Value Bets)
    if args.match:
        parts = [p.strip() for p in args.match.split("vs")]
        if len(parts) != 2:
            print("[!] Formato de partido incorrecto. Use: --match 'Local vs Visitante'", file=sys.stderr)
            sys.exit(1)
        h_team, a_team = parts[0], parts[1]

        engine = StochasticEngine(db_path=args.db, n_simulations=args.sims)
        try:
            payload = engine.simulate_fixture(h_team, a_team, comp_id=args.comp)
            if not args.quiet:
                report = StochasticVisualizer.render(payload['simulation'], payload['value_analysis'])
                print(report)
            if args.export == "json":
                out_p = engine.export_simulation_json(payload)
                print(f"\n[✓] Simulación exportada exitosamente a: {out_p}")
        finally:
            engine.close()
        return

    # MODO 2: Simulación de los próximos N partidos del calendario
    if args.sim_next:
        engine = StochasticEngine(db_path=args.db, n_simulations=args.sims)
        try:
            fixtures = engine.simulate_next_fixtures(comp_id=args.comp, limit=args.sim_next)
            print(f"\n[*] Simulando {len(fixtures)} próximos encuentros con {args.sims} iteraciones Monte Carlo cada uno...")
            for fix in fixtures:
                if not args.quiet:
                    info = fix.get('fixture_info', {})
                    print(f"\n>>> JORNADA {info.get('jornada')} | {info.get('fecha_hora')}")
                    report = StochasticVisualizer.render(fix['simulation'], fix['value_analysis'])
                    print(report)
                if args.export == "json":
                    out_p = engine.export_simulation_json(fix)
                    print(f"[✓] Exportado: {out_p}")
        finally:
            engine.close()
        return

    # MODO 3: Perfil Táctico y Contextual de un Equipo
    if args.team:
        profile_engine = TeamProfileEngine(db_path=args.db)
        try:
            profile = profile_engine.generate_profile(args.team, comp_id=args.comp)
            if "error" in profile:
                print(f"\n[!] Error: {profile['error']}", file=sys.stderr)
                sys.exit(1)

            if not args.quiet:
                report_str = ProfileVisualizer.render(profile)
                print(report_str)

            if args.export == "json":
                out_path = profile_engine.export_profile_json(profile)
                print(f"\n[✓] Perfil táctico exportado exitosamente a: {out_path}")
        finally:
            profile_engine.close()
        return

    # MODO 4: Reporte General de la Liga (SoccerStats)
    analyzer = SoccerStatsAnalyzer(db_path=args.db)
    try:
        data = analyzer.analyze_league(args.comp)

        if "error" in data:
            print(f"\n[!] Error: {data['error']}", file=sys.stderr)
            sys.exit(1)

        if not args.quiet:
            cli_text = CLIReportVisualizer.render(data)
            print(cli_text)

        if args.export == "json":
            out_file = analyzer.export_json(data)
            print(f"\n[✓] Datos de liga exportados exitosamente a: {out_file}")

    finally:
        analyzer.close()

if __name__ == "__main__":
    main()
