"""
Sistema 1: Motor Analítico de Ingeniería Inversa estilo SoccerStats.
Calcula métricas de liga, tablas, forma, liderazgo, tiempos de gol y pre-match
a partir de la base de datos relacional.
"""

__version__ = "1.0.0"
