import math

mu = math.log(1.49) # average goals per match / 2
h = 0.15 # home adv
# Barcelona attack: 36 goals in 9 games (4.0 g/g) vs avg 1.49 -> att = log(4.0/1.49) = 0.98
# Real Madrid defense: 8 goals in 8 games (1.0 g/g) vs avg 1.49 -> def_rate = 1.0/1.49 = 0.67, log = -0.39
# If def is vulnerability: beta_A = -0.39
# lambda_H = exp(mu + h + alpha_H + beta_A) = exp(0.40 + 0.15 + 0.98 - 0.39) = exp(1.14) = 3.12 goals!
# And Real Madrid attack: 19/8 = 2.375 -> att = log(2.375/1.49) = 0.46
# Barcelona defense: 8/9 = 0.88 -> def_rate = 0.88/1.49 = 0.59, log = -0.52
# lambda_A = exp(mu + alpha_A + beta_H) = exp(0.40 + 0.46 - 0.52) = exp(0.34) = 1.40 goals!
print(f"Barcelona lambda_H: {math.exp(0.40 + 0.15 + 0.98 - 0.39):.2f}")
print(f"Real Madrid lambda_A: {math.exp(0.40 + 0.46 - 0.52):.2f}")
