# Sistema 1: Motor Analítico, Perfiles y Simulación Estocástica FAIS

Implementación limpia, modular y desacoplada para análisis cuantitativo de fútbol profesional.
Basado en datos relacionales de SQLite (`betplay_flashscore.db`) integrando FlashScore, FotMob (Opta) y Cuotas de BetPlay.

---

## 1. Arquitectura del Sistema

```text
sistema_1/
├── __init__.py
├── config.py              # Rutas y parámetros globales
├── db.py                  # Capa de datos SQLite con sanitización
├── main.py                # CLI unificada (Liga, Perfiles, Simulaciones)
│
├── engine/                # Módulos estilo SoccerStats (Macro-Liga)
│   ├── overview_calc.py   # Progreso, goles, Over/Under y BTTS
│   ├── standings_calc.py  # Clasificación general, PPG, CS%, SR%, MPP
│   ├── subtables_calc.py  # 12 sub-rankings
│   ├── segments_calc.py   # Quintiles de clasificación
│   ├── prematch_calc.py   # Comparativa Home vs Away
│   ├── goal_times_calc.py # Tiempos de gol y dinámicas de liderazgo
│   └── scores_calc.py     # Distribución de marcadores exactos
│
├── profiles/              # Motor de Perfiles Tácticos y Contextuales
│   ├── team_style.py      # Con y sin balón (Posesión, xG, tiros, duelos, errores)
│   ├── game_state.py      # Splits (ganando, empatando, perdiendo y reacción)
│   ├── personnel.py       # Once tipo, formaciones, relevos y ausencias
│   ├── environment.py     # Árbitros, césped, aforo y temperatura
│   ├── table_impact.py    # Simulador determinístico What-If en la tabla
│   └── engine.py          # Orquestador TeamProfileEngine
│
├── scanner/               # Escáner Global de Mercados (Competiciones y Árbitros)
│   ├── market_screener.py # 197 Ligas, 76 Países y 2,215 Árbitros
│   └── visualizer.py      # Ranking de oportunidades (Over 1.5, Under 2.5, BTTS, etc.)
│
├── ledger/                # Bitácora Walk-Forward y Auditoría OOS (FAIS)
│   └── ledger_manager.py  # Registro inmutable pre-partido y liquidación automática
│
└── stochastic/            # Motor Estocástico y de Simulación FAIS
    ├── dixon_coles.py     # Ajuste Poisson / Dixon-Coles (alpha, beta, h, rho)
    ├── markov_chain.py    # Simulación minuto a minuto de estados de marcador
    ├── monte_carlo.py     # 10,000 iteraciones Monte Carlo y matriz de marcadores
    ├── value_detector.py  # Cruce con BetPlay (Edge, EV y Value Bets)
    └── engine.py          # Orquestador StochasticEngine
```

---

## 2. Modos de Uso por Línea de Comandos

### A. Simulación Estocástica Monte Carlo (Dixon-Coles + BetPlay Value Bets)
Simular un partido específico con 10,000 iteraciones:
```powershell
python sistema_1/main.py --match "Barcelona vs Real Madrid"
```

Simular los próximos $N$ partidos del fixture y detectar oportunidades de valor:
```powershell
python sistema_1/main.py --sim-next 5
```

### B. Perfil Táctico y Contextual de un Equipo
Generar el perfil completo de un equipo (estilo con/sin balón, estados de juego, once recurrente, bajas y what-if de tabla):
```powershell
python sistema_1/main.py --team "Barcelona"
python sistema_1/main.py --team "Tottenham" --comp 126
```

### C. Escáner Global de Mercados (197 Ligas y 2,215 Árbitros)
Identificar las mejores ligas del mundo para Over 1.5, Under 2.5, Ambos Marcan y árbitros más severos:
```powershell
python sistema_1/main.py --screen-markets
```

### D. Bitácora de Predicciones y Auditoría Walk-Forward (Ledger)
Consultar todas las predicciones registradas de forma inmutable:
```powershell
python sistema_1/main.py --ledger
```

Liquidar automáticamente predicciones terminadas contra resultados oficiales en SQLite:
```powershell
python sistema_1/main.py --settle-ledger
```

### E. Reporte General de Liga (SoccerStats)
Generar la clasificación completa, sub-tablas, segmentos y dinámicas de gol:
```powershell
python sistema_1/main.py
```
O para otra liga:
```powershell
python sistema_1/main.py --comp 126
```
