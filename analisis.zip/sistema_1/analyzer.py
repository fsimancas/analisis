import os
import json
from typing import Dict, Any, Optional

from .db import Database
from .config import DB_PATH, OUTPUT_DIR
from .engine.overview_calc import OverviewCalculator
from .engine.standings_calc import StandingsCalculator
from .engine.subtables_calc import SubtablesCalculator
from .engine.segments_calc import SegmentsCalculator
from .engine.prematch_calc import PreMatchCalculator
from .engine.goal_times_calc import GoalTimesCalculator
from .engine.scores_calc import ScoresCalculator

class SoccerStatsAnalyzer:
    """
    Motor principal de ingeniería inversa de SoccerStats.
    Orquesta la extracción desde la base de datos relacional y
    el cómputo de todas las secciones analíticas.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db = Database(db_path)

    def close(self):
        self.db.close()

    def analyze_league(self, comp_id: int) -> Dict[str, Any]:
        comp_info = self.db.get_competition(comp_id)
        if not comp_info:
            return {"error": f"Competición con ID {comp_id} no encontrada en la base de datos."}

        results = self.db.get_completed_matches(comp_id)
        upcoming = self.db.get_upcoming_matches(comp_id)

        if not results:
            return {
                "competition": comp_info,
                "error": "No se encontraron partidos finalizados con marcador para esta competición."
            }

        # 1. League Overview (Progreso y estadísticas generales de goles)
        league_overview = OverviewCalculator.calculate(results, upcoming)

        # 2. Standings & Team Accumulators (Clasificación General y promedio de liga)
        league_table, average_row, team_stats = StandingsCalculator.calculate(results, upcoming)

        # 3. Sub-tables (12 tablas de desglose)
        subtables = SubtablesCalculator.calculate(team_stats)

        # 4. Segments Table (5 quintiles)
        segments = SegmentsCalculator.calculate(league_table)

        # 5. Pre-Match Stats (Próximos partidos: Local en casa vs Visitante fuera)
        prematch_stats = PreMatchCalculator.calculate(upcoming, team_stats)

        # 6. Goal Times, Leads & Equalizing Dynamics
        match_ids = [m['id'] for m in results]
        incidents = self.db.get_incidents_for_matches(match_ids)
        goal_times_stats = GoalTimesCalculator.calculate(results, incidents)

        # 7. Full-Time Scores Distribution
        scores_distribution = ScoresCalculator.calculate(results)

        payload = {
            "competition": comp_info,
            "league_overview": league_overview,
            "league_table": league_table,
            "league_table_average": average_row,
            "tables_overview": subtables,
            "segments_table": segments,
            "prematch_stats": prematch_stats,
            "goal_times_and_leads": goal_times_stats,
            "full_time_scores": scores_distribution
        }

        return payload

    def export_json(self, data: Dict[str, Any], output_path: Optional[str] = None) -> str:
        if not output_path:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            comp_id = data.get("competition", {}).get("id", "general")
            output_path = os.path.join(OUTPUT_DIR, f"soccerstats_comp_{comp_id}.json")
        else:
            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        return output_path
