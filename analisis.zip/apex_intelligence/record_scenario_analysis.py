import json
import sqlite3
import os
from datetime import datetime

DB_PATH = r"c:\Users\SIMANCAS\Documents\rey\betplay_flashscore.db"
LEDGER_FILE = r"c:\Users\SIMANCAS\Documents\rey\sistema_1\output\ledger\predictions_ledger.json"

scenarios_data = [
    {
        "scenario_key": "base",
        "name": "BASE (Rendimiento Real)",
        "xg_total": 1.47,
        "home_win_pct": "29.2%",
        "draw_pct": "36.2%",
        "away_win_pct": "34.5%",
        "under_2_5_pct": "81.7%",
        "btts_pct": "26.5%",
        "dom_regime": "LOW_EVENT (40%)"
    },
    {
        "scenario_key": "esc_1_tot_att_plus_25",
        "name": "ESC. 1: +25% Ataque Tottenham",
        "xg_total": 1.64,
        "home_win_pct": "34.2%",
        "draw_pct": "35.0%",
        "away_win_pct": "30.7%",
        "under_2_5_pct": "77.6%",
        "btts_pct": "31.1%",
        "dom_regime": "LOW_EVENT (35%)"
    },
    {
        "scenario_key": "esc_2_cov_att_plus_25",
        "name": "ESC. 2: +25% Ataque Coventry",
        "xg_total": 1.67,
        "home_win_pct": "24.5%",
        "draw_pct": "32.8%",
        "away_win_pct": "42.7%",
        "under_2_5_pct": "75.8%",
        "btts_pct": "31.6%",
        "dom_regime": "NORMAL (38%)"
    },
    {
        "scenario_key": "esc_3_open_game",
        "name": "ESC. 3: Partido Abierto (OPEN_GAME)",
        "xg_total": 1.69,
        "home_win_pct": "29.4%",
        "draw_pct": "33.4%",
        "away_win_pct": "37.2%",
        "under_2_5_pct": "75.3%",
        "btts_pct": "32.2%",
        "dom_regime": "OPEN_GAME (100% forzado)"
    },
    {
        "scenario_key": "esc_4_chaotic_vol_plus_40",
        "name": "ESC. 4: Régimen Caótico (+40% Volatilidad)",
        "xg_total": 1.47,
        "home_win_pct": "27.8%",
        "draw_pct": "37.8%",
        "away_win_pct": "34.5%",
        "under_2_5_pct": "82.2%",
        "btts_pct": "26.5%",
        "dom_regime": "CHAOTIC (100% forzado)"
    }
]

def record():
    # 1. Guardar en SQLite (predictive_analyses)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO predictive_analyses (
            match_id, analysis_version, status, data_cutoff_at,
            deterministic_result, probabilistic_result, scenario_result,
            simulation_result, uncertainty_result, confidence_score
        )
        VALUES (?, 'APEX-v1.0-ScenarioLab', 'READY', ?, ?, ?, ?, ?, ?, ?)
    """, (
        '0zSjbNHM',
        '2026-10-19T14:00:00Z',
        json.dumps({"home_lambda": 0.681, "away_lambda": 0.792, "total_xg": 1.473}),
        json.dumps({"rho": -0.11, "p_0_0": 0.232, "p_0_1": 0.175, "p_1_0": 0.161}),
        json.dumps({"scenarios": scenarios_data, "robustness": "Under 2.5 > 75% in all scenarios, X2 > 65% in all scenarios"}),
        json.dumps({"n_simulations": 50000, "base_home_win": 0.292, "base_draw": 0.362, "base_away_win": 0.345}),
        json.dumps({"confidence_score": 75, "level": "HIGH", "factors": "Strict temporal cut, balanced sample"}),
        75
    ))
    db_id = cur.lastrowid
    conn.commit()
    conn.close()
    print(f"[✓] Análisis persistido en SQLite: tabla 'predictive_analyses' (Fila ID: {db_id})")

    # 2. Actualizar Bitácora JSON (predictions_ledger.json)
    if os.path.exists(LEDGER_FILE):
        with open(LEDGER_FILE, "r", encoding="utf-8") as f:
            ledger = json.load(f)

        for record in ledger:
            if record.get('match_id') == '0zSjbNHM':
                record['scenario_lab'] = {
                    "total_simulations_evaluated": 50000,
                    "updated_at": datetime.now().isoformat(),
                    "scenarios": scenarios_data,
                    "stress_test_verdict": "APROBADO. El mercado Under 2.5 y la Doble Oportunidad X2 se mantienen con valor positivo en el 100% de los escenarios tácticos simulados."
                }
                break

        with open(LEDGER_FILE, "w", encoding="utf-8") as f:
            json.dump(ledger, f, ensure_ascii=False, indent=2)

        print(f"[✓] Bitácora walk-forward '{LEDGER_FILE}' actualizada con el módulo Scenario Lab.")

if __name__ == "__main__":
    record()
