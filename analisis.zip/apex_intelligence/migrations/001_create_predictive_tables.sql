-- Migration: 001_create_predictive_tables.sql
-- Database: SQLite (backend/storage/db.sqlite3)
-- Purpose: Schema persistence for APEX Intelligence (Feature Store & Inmutable Predictive Analyses)

CREATE TABLE IF NOT EXISTS feature_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id INTEGER NOT NULL,
    competition_id INTEGER NOT NULL,
    season_id INTEGER,
    cutoff_date TEXT NOT NULL,
    feature_version TEXT NOT NULL,
    payload JSON NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(team_id) REFERENCES teams(id)
);

CREATE INDEX IF NOT EXISTS idx_feat_team_cutoff ON feature_snapshots(team_id, cutoff_date);

CREATE TABLE IF NOT EXISTS predictive_analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL,
    analysis_version TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('READY', 'STALE', 'ERROR')),
    data_cutoff_at TEXT NOT NULL,
    deterministic_result JSON NOT NULL,
    probabilistic_result JSON NOT NULL,
    scenario_result JSON NOT NULL,
    simulation_result JSON NOT NULL,
    uncertainty_result JSON NOT NULL,
    confidence_score INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(match_id) REFERENCES matches(id)
);

CREATE INDEX IF NOT EXISTS idx_pred_match_cutoff ON predictive_analyses(match_id, data_cutoff_at);
