import sqlite3
import os
import sys

def run_migration(db_path: str = None):
    if db_path is None:
        # Default path in Apex Analytics layout
        db_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "backend", "storage", "db.sqlite3")
        )

    migration_file = os.path.join(os.path.dirname(__file__), "001_create_predictive_tables.sql")

    if not os.path.exists(migration_file):
        print(f"[!] Archivo de migración no encontrado: {migration_file}", file=sys.stderr)
        sys.exit(1)

    print(f"[*] Aplicando migración predictiva sobre: {db_path}")
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)

    with open(migration_file, "r", encoding="utf-8") as f:
        sql_script = f.read()

    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()
        cur.executescript(sql_script)
        conn.commit()
        print("[✓] Tablas 'feature_snapshots' y 'predictive_analyses' creadas exitosamente.")
    except Exception as e:
        print(f"[!] Error al ejecutar migración: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        conn.close()

if __name__ == "__main__":
    target_db = sys.argv[1] if len(sys.argv) > 1 else None
    run_migration(target_db)
