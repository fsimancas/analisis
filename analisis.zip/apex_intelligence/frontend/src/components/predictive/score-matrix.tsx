// Component: ScoreMatrix
// Path: src/components/predictive/score-matrix.tsx

import React from 'react';
import { ScoreProbability } from '../../lib/api/predictive';

interface Props {
  scores: ScoreProbability[];
}

export const ScoreMatrix: React.FC<Props> = ({ scores }) => {
  return (
    <div className="flex flex-col gap-4 p-5 rounded-xl border border-slate-800 bg-slate-900/80">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
          Marcadores Más Probables (Monte Carlo)
        </h3>
        <span className="text-xs text-slate-500">Top 5 Resultados</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {scores.map((s, idx) => {
          const probPct = Math.round(s.probability * 1000) / 10;
          return (
            <div
              key={idx}
              className={`flex flex-col items-center justify-center p-3 rounded-lg border transition-all ${
                idx === 0
                  ? 'border-indigo-500/50 bg-indigo-500/10 text-indigo-300'
                  : 'border-slate-800 bg-slate-950/40 text-slate-300'
              }`}
            >
              <span className="text-lg font-mono font-bold tracking-wider">{s.score}</span>
              <span className="text-xs font-semibold mt-1">{probPct}%</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
