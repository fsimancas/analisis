// Component: ScenarioLab
// Path: src/components/predictive/scenario-lab.tsx

import React, { useState } from 'react';
import { ScenarioAdjustment } from '../../lib/api/predictive';

interface Props {
  onSimulate: (adj: ScenarioAdjustment) => void;
  isSimulating: boolean;
}

export const ScenarioLab: React.FC<Props> = ({ onSimulate, isSimulating }) => {
  const [homeAtt, setHomeAtt] = useState<number>(0);
  const [awayAtt, setAwayAtt] = useState<number>(0);
  const [volatility, setVolatility] = useState<number>(0);
  const [regime, setRegime] = useState<string>('');

  const handleApply = () => {
    onSimulate({
      home_attack_adjustment: homeAtt / 100.0,
      away_attack_adjustment: awayAtt / 100.0,
      volatility: volatility / 100.0,
      regime_override: regime || undefined,
    });
  };

  const handleReset = () => {
    setHomeAtt(0);
    setAwayAtt(0);
    setVolatility(0);
    setRegime('');
    onSimulate({});
  };

  return (
    <div className="flex flex-col gap-5 p-5 rounded-xl border border-indigo-900/40 bg-indigo-950/20 shadow-lg">
      <div className="flex items-center justify-between border-b border-indigo-900/40 pb-3">
        <div>
          <h3 className="text-base font-bold text-indigo-300">Scenario Lab (Simulación Interactiva)</h3>
          <p className="text-xs text-slate-400">
            Ajustá variables tácticas para re-ejecutar 10.000 escenarios Monte Carlo en memoria.
          </p>
        </div>
        <button
          onClick={handleReset}
          className="text-xs text-slate-400 hover:text-slate-200 underline"
        >
          Restablecer
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Sliders */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-300 font-medium flex justify-between">
            <span>Ataque Local</span>
            <span className="font-mono text-indigo-400">{homeAtt > 0 ? `+${homeAtt}` : homeAtt}%</span>
          </label>
          <input
            type="range"
            min="-50"
            max="50"
            step="5"
            value={homeAtt}
            onChange={(e) => setHomeAtt(Number(e.target.value))}
            className="accent-indigo-500 cursor-pointer"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-300 font-medium flex justify-between">
            <span>Ataque Visitante</span>
            <span className="font-mono text-cyan-400">{awayAtt > 0 ? `+${awayAtt}` : awayAtt}%</span>
          </label>
          <input
            type="range"
            min="-50"
            max="50"
            step="5"
            value={awayAtt}
            onChange={(e) => setAwayAtt(Number(e.target.value))}
            className="accent-cyan-500 cursor-pointer"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-300 font-medium flex justify-between">
            <span>Volatilidad Estocástica</span>
            <span className="font-mono text-amber-400">+{volatility}%</span>
          </label>
          <input
            type="range"
            min="0"
            max="50"
            step="5"
            value={volatility}
            onChange={(e) => setVolatility(Number(e.target.value))}
            className="accent-amber-500 cursor-pointer"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs text-slate-300 font-medium">Forzar Régimen</label>
          <select
            value={regime}
            onChange={(e) => setRegime(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded p-1.5 focus:outline-none focus:border-indigo-500"
          >
            <option value="">Automático</option>
            <option value="LOW_EVENT">Low Event (Cerrado)</option>
            <option value="NORMAL">Normal (Estándar)</option>
            <option value="OPEN_GAME">Open Game (Abierto)</option>
            <option value="HIGH_DOMINANCE">High Dominance (Asimétrico)</option>
            <option value="CHAOTIC">Chaotic (Alta Varianza)</option>
          </select>
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <button
          onClick={handleApply}
          disabled={isSimulating}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow transition-all flex items-center gap-2"
        >
          {isSimulating ? 'Simulando 10.000 iteraciones...' : 'Ejecutar Simulación Monte Carlo'}
        </button>
      </div>
    </div>
  );
};
