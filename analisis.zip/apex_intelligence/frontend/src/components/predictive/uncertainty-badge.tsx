// Component: UncertaintyBadge
// Path: src/components/predictive/uncertainty-badge.tsx

import React from 'react';
import { Uncertainty } from '../../lib/api/predictive';

interface Props {
  uncertainty: Uncertainty;
}

export const UncertaintyBadge: React.FC<Props> = ({ uncertainty }) => {
  const { confidence_score, level, explanation } = uncertainty;

  const colorStyles = {
    HIGH: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    MEDIUM: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    LOW: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
  }[level];

  return (
    <div className="flex flex-col gap-2 p-3 rounded-lg border border-slate-800 bg-slate-900/60 backdrop-blur">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Índice de Confianza (APEX Uncertainty)
        </span>
        <span className={`px-2.5 py-0.5 text-xs font-medium rounded-full border ${colorStyles}`}>
          {confidence_score}% · {level}
        </span>
      </div>
      <p className="text-xs text-slate-400 leading-relaxed">
        {explanation}
      </p>
    </div>
  );
};
