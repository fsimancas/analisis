// Component: MarketsCard
// Path: src/components/predictive/markets-card.tsx

import React from 'react';
import { Markets } from '../../lib/api/predictive';

interface Props {
  markets: Markets;
}

export const MarketsCard: React.FC<Props> = ({ markets }) => {
  const items = [
    { label: 'Más de 1.5 Goles', prob: markets.over_1_5, threshold: '80%' },
    { label: 'Más de 2.5 Goles', prob: markets.over_2_5, threshold: '55%' },
    { label: 'Menos de 2.5 Goles', prob: markets.under_2_5, threshold: '55%' },
    { label: 'Ambos Marcan (Sí)', prob: markets.btts_yes, threshold: '50%' },
    { label: 'Más de 3.5 Goles', prob: markets.over_3_5, threshold: '30%' },
    { label: 'Menos de 3.5 Goles', prob: markets.under_3_5, threshold: '70%' },
  ];

  return (
    <div className="flex flex-col gap-4 p-5 rounded-xl border border-slate-800 bg-slate-900/80">
      <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
        Probabilidades de Mercados Principales
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {items.map((m, idx) => {
          const pct = Math.round(m.prob * 100);
          const isHigh = pct >= 65;
          return (
            <div
              key={idx}
              className="flex items-center justify-between p-3 rounded-lg border border-slate-800/80 bg-slate-950/40"
            >
              <span className="text-xs text-slate-300 font-medium">{m.label}</span>
              <span
                className={`text-sm font-mono font-bold ${
                  isHigh ? 'text-emerald-400' : 'text-slate-200'
                }`}
              >
                {pct}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
