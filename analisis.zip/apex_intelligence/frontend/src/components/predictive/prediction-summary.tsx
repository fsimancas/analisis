// Component: PredictionSummary
// Path: src/components/predictive/prediction-summary.tsx

import React from 'react';
import { PredictiveAnalysis } from '../../lib/api/predictive';

interface Props {
  prediction: PredictiveAnalysis;
}

export const PredictionSummary: React.FC<Props> = ({ prediction }) => {
  const { home_team, away_team, win_probabilities, expected_goals, regimes } = prediction;

  const pHome = Math.round(win_probabilities.home_win * 100);
  const pDraw = Math.round(win_probabilities.draw * 100);
  const pAway = Math.round(win_probabilities.away_win * 100);

  const dominantRegime = regimes.reduce((prev, curr) => 
    curr.probability > prev.probability ? curr : prev, regimes[0]
  );

  return (
    <div className="flex flex-col gap-6 p-6 rounded-xl border border-slate-800 bg-slate-900/80 shadow-xl">
      {/* Cabecera del Partido */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
        <div className="flex-1 text-center">
          <h2 className="text-xl font-bold text-white tracking-tight">{home_team}</h2>
          <span className="text-xs text-slate-400">Local (xG: {expected_goals.home})</span>
        </div>
        <div className="px-4 py-1 text-xs font-semibold rounded bg-slate-800 text-slate-300">
          VS
        </div>
        <div className="flex-1 text-center">
          <h2 className="text-xl font-bold text-white tracking-tight">{away_team}</h2>
          <span className="text-xs text-slate-400">Visitante (xG: {expected_goals.away})</span>
        </div>
      </div>

      {/* Probabilidades 1X2 */}
      <div className="flex flex-col gap-2">
        <div className="flex justify-between text-xs font-semibold uppercase tracking-wider text-slate-400">
          <span>Victoria Local ({pHome}%)</span>
          <span>Empate ({pDraw}%)</span>
          <span>Victoria Visitante ({pAway}%)</span>
        </div>
        <div className="h-4 w-full flex rounded-full overflow-hidden bg-slate-800 p-0.5 gap-0.5">
          <div
            style={{ width: `${pHome}%` }}
            className="bg-indigo-500 rounded-l-full transition-all duration-500"
            title={`Local: ${pHome}%`}
          />
          <div
            style={{ width: `${pDraw}%` }}
            className="bg-amber-500 transition-all duration-500"
            title={`Empate: ${pDraw}%`}
          />
          <div
            style={{ width: `${pAway}%` }}
            className="bg-cyan-500 rounded-r-full transition-all duration-500"
            title={`Visitante: ${pAway}%`}
          />
        </div>
      </div>

      {/* Métricas Clave y Régimen */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
        <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60 flex flex-col">
          <span className="text-xs text-slate-400">Goles Esperados (Total)</span>
          <span className="text-lg font-bold text-slate-100">{expected_goals.total}</span>
        </div>
        <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60 flex flex-col">
          <span className="text-xs text-slate-400">Régimen Probable</span>
          <span className="text-sm font-semibold text-emerald-400 mt-0.5">
            {dominantRegime.regime} ({Math.round(dominantRegime.probability * 100)}%)
          </span>
        </div>
        <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60 flex flex-col col-span-2 sm:col-span-1">
          <span className="text-xs text-slate-400">Corte Temporal</span>
          <span className="text-xs font-mono text-slate-300 mt-1 truncate">
            {prediction.cutoff_date.split('T')[0] || prediction.cutoff_date}
          </span>
        </div>
      </div>
    </div>
  );
};
