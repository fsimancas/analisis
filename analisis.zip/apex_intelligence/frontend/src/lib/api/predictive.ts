// APEX Predictive Intelligence - API Client
// Path: src/lib/api/predictive.ts

export interface ExpectedGoals {
  home: number;
  away: number;
  total: number;
}

export interface WinProbabilities {
  home_win: number;
  draw: number;
  away_win: number;
}

export interface Markets {
  over_1_5: number;
  under_1_5: number;
  over_2_5: number;
  under_2_5: number;
  over_3_5: number;
  under_3_5: number;
  btts_yes: number;
  btts_no: number;
}

export interface ScoreProbability {
  score: string;
  home_goals: number;
  away_goals: number;
  probability: number;
}

export interface MatchRegime {
  regime: string;
  probability: number;
  description: string;
}

export interface Uncertainty {
  confidence_score: number;
  level: 'HIGH' | 'MEDIUM' | 'LOW';
  sample_size_matches: number;
  has_advanced_stats: boolean;
  explanation: string;
}

export interface PredictiveAnalysis {
  match_id: number;
  home_team: string;
  away_team: string;
  competition_id: number;
  season_id?: number;
  cutoff_date: string;
  status: string;
  expected_goals: ExpectedGoals;
  win_probabilities: WinProbabilities;
  markets: Markets;
  most_likely_scores: ScoreProbability[];
  regimes: MatchRegime[];
  uncertainty: Uncertainty;
  models_evaluated: string[];
}

export interface ScenarioAdjustment {
  home_attack_adjustment?: number;
  away_attack_adjustment?: number;
  home_defense_adjustment?: number;
  away_defense_adjustment?: number;
  volatility?: number;
  regime_override?: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/v1';

export async function fetchMatchPrediction(matchId: number): Promise<PredictiveAnalysis> {
  const res = await fetch(`${API_BASE_URL}/predict/matches/${matchId}`);
  if (!res.ok) {
    throw new Error(`Error fetching match prediction: ${res.statusText}`);
  }
  return res.json();
}

export async function simulateScenario(
  matchId: number,
  adjustments: ScenarioAdjustment
): Promise<PredictiveAnalysis> {
  const res = await fetch(`${API_BASE_URL}/predict/matches/${matchId}/scenario`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(adjustments),
  });
  if (!res.ok) {
    throw new Error(`Error simulating scenario: ${res.statusText}`);
  }
  return res.json();
}
