// Hook: useMatchPrediction
// Path: src/hooks/use-match-prediction.ts

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  fetchMatchPrediction,
  simulateScenario,
  PredictiveAnalysis,
  ScenarioAdjustment
} from '../lib/api/predictive';

export function useMatchPrediction(matchId: number) {
  const queryClient = useQueryClient();

  const query = useQuery<PredictiveAnalysis, Error>({
    queryKey: ['match-prediction', matchId],
    queryFn: () => fetchMatchPrediction(matchId),
    staleTime: 1000 * 60 * 15, // 15 minutos en caché
    enabled: !!matchId,
  });

  const scenarioMutation = useMutation<PredictiveAnalysis, Error, ScenarioAdjustment>({
    mutationFn: (adjustments: ScenarioAdjustment) => simulateScenario(matchId, adjustments),
    onSuccess: (data) => {
      // Opcionalmente actualizar estado temporal
      queryClient.setQueryData(['match-prediction-scenario', matchId], data);
    },
  });

  return {
    prediction: query.data,
    isLoading: query.isLoading,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
    simulateScenario: scenarioMutation.mutate,
    isSimulating: scenarioMutation.isPending,
    scenarioResult: scenarioMutation.data,
  };
}
