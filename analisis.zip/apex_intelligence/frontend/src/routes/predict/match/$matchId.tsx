// TanStack Router Route: /predict/match/$matchId
// Path: src/routes/predict/match/$matchId.tsx

import React from 'react';
import { createFileRoute } from '@tanstack/react-router';
import { useMatchPrediction } from '../../hooks/use-match-prediction';
import { PredictionSummary } from '../../components/predictive/prediction-summary';
import { UncertaintyBadge } from '../../components/predictive/uncertainty-badge';
import { ScoreMatrix } from '../../components/predictive/score-matrix';
import { MarketsCard } from '../../components/predictive/markets-card';
import { ScenarioLab } from '../../components/predictive/scenario-lab';

export const Route = createFileRoute('/predict/match/$matchId')({
  component: MatchPredictorPage,
});

function MatchPredictorPage() {
  const { matchId } = Route.useParams();
  const id = Number(matchId);

  const {
    prediction,
    isLoading,
    isError,
    error,
    simulateScenario,
    isSimulating,
    scenarioResult,
  } = useMatchPrediction(id);

  if (isLoading) {
    return (
      <div className="flex h-96 items-center justify-center text-slate-400">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-500 border-t-transparent" />
          <span className="text-sm font-medium">Ejecutando Modelos Predictivos y Monte Carlo...</span>
        </div>
      </div>
    );
  }

  if (isError || !prediction) {
    return (
      <div className="p-8 text-center text-rose-400">
        <h3 className="text-lg font-bold">Error al cargar la predicción</h3>
        <p className="text-sm text-slate-400 mt-1">{error?.message || 'Partido no encontrado.'}</p>
      </div>
    );
  }

  // Si el usuario ejecutó una simulación en el Scenario Lab, usamos los resultados reactivos
  const activeData = scenarioResult || prediction;

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto p-4 sm:p-6">
      {/* Cabecera Superior */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
            APEX Intelligence · Predictive Module
          </span>
          <h1 className="text-2xl font-black text-white tracking-tight">
            Análisis Predictivo del Partido
          </h1>
        </div>
        <UncertaintyBadge uncertainty={activeData.uncertainty} />
      </div>

      {/* Resumen Principal (1X2 y xG) */}
      <PredictionSummary prediction={activeData} />

      {/* Cuadrícula de Marcadores y Mercados */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ScoreMatrix scores={activeData.most_likely_scores} />
        <MarketsCard markets={activeData.markets} />
      </div>

      {/* Laboratorio Interactivo de Escenarios */}
      <ScenarioLab onSimulate={simulateScenario} isSimulating={isSimulating} />
    </div>
  );
}
