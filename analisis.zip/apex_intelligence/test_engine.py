import sqlite3
import json
from datetime import datetime
from apex_intelligence.backend.app.predictive.features.team_features import TeamFeatureExtractor
from apex_intelligence.backend.app.predictive.models.deterministic import DeterministicCore
from apex_intelligence.backend.app.predictive.models.dixon_coles import DixonColesModel
from apex_intelligence.backend.app.predictive.models.regimes import RegimeClassifier
from apex_intelligence.backend.app.predictive.simulation.monte_carlo import MonteCarloSimulator
from apex_intelligence.backend.app.predictive.uncertainty.engine import UncertaintyEngine

def test_pipeline():
    print("[*] Iniciando test integral del motor APEX Intelligence...")

    # Crear base de datos SQLite en memoria con el esquema exacto de ESPN
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()

    cur.executescript("""
        CREATE TABLE teams (id INTEGER PRIMARY KEY, name TEXT);
        CREATE TABLE matches (id INTEGER PRIMARY KEY, competition_id INTEGER, season_id INTEGER, start_time TEXT, status TEXT);
        CREATE TABLE match_competitors (id INTEGER PRIMARY KEY, match_id INTEGER, team_id INTEGER, home_away TEXT, score INTEGER);
        CREATE TABLE match_team_stats (id INTEGER PRIMARY KEY, match_id INTEGER, team_id INTEGER, shots INTEGER, shots_on_target INTEGER, corners INTEGER, possession REAL, fouls INTEGER, yellow_cards INTEGER, red_cards INTEGER, saves INTEGER);

        INSERT INTO teams VALUES (1, 'Real Madrid'), (2, 'FC Barcelona'), (3, 'Atletico Madrid'), (4, 'Sevilla');

        -- Partidos pasados
        INSERT INTO matches VALUES (101, 84, 2026, '2026-09-10T20:00:00Z', 'finished');
        INSERT INTO match_competitors VALUES (1, 101, 1, 'home', 3), (2, 101, 3, 'away', 1);
        INSERT INTO match_team_stats VALUES (1, 101, 1, 15, 6, 7, 58.0, 10, 1, 0, 3);
        INSERT INTO match_team_stats VALUES (2, 101, 3, 8, 3, 3, 42.0, 14, 2, 0, 4);

        INSERT INTO matches VALUES (102, 84, 2026, '2026-09-17T20:00:00Z', 'finished');
        INSERT INTO match_competitors VALUES (3, 102, 2, 'home', 2), (4, 102, 4, 'away', 0);
        INSERT INTO match_team_stats VALUES (3, 102, 2, 18, 8, 8, 64.0, 8, 0, 0, 2);
        INSERT INTO match_team_stats VALUES (4, 102, 4, 6, 2, 2, 36.0, 16, 3, 0, 6);

        -- Partido a predecir: Real Madrid vs Barcelona (2026-10-25)
        INSERT INTO matches VALUES (200, 84, 2026, '2026-10-25T19:00:00Z', 'scheduled');
        INSERT INTO match_competitors VALUES (5, 200, 1, 'home', NULL), (6, 200, 2, 'away', NULL);
    """)
    conn.commit()

    # 1. Feature Extraction (t < t_m)
    cutoff = '2026-10-25T19:00:00Z'
    extractor = TeamFeatureExtractor(conn)
    h_feats = extractor.extract_features(team_id=1, competition_id=84, cutoff_date=cutoff)
    a_feats = extractor.extract_features(team_id=2, competition_id=84, cutoff_date=cutoff)

    print(f"[✓] Features Real Madrid - Ataque: {h_feats['attack_strength']}, Muestra: {h_feats['sample_size']}")
    print(f"[✓] Features Barcelona   - Ataque: {a_feats['attack_strength']}, Muestra: {a_feats['sample_size']}")

    # 2. Deterministic Lambdas
    lambdas = DeterministicCore.calculate_lambdas(h_feats, a_feats)
    print(f"[✓] Goles Esperados - Local: {lambdas['home_lambda']} | Visitante: {lambdas['away_lambda']} | Total: {lambdas['total_expected_goals']}")

    # 3. Dixon-Coles Bivariate
    dc = DixonColesModel(rho=-0.11)
    matrix = dc.compute_bivariate_matrix(lambdas['home_lambda'], lambdas['away_lambda'])
    print(f"[✓] Matriz Bivariada Dixon-Coles calculada (P(0-0): {round(matrix[0][0]*100, 2)}%)")

    # 4. Regimes
    regimes = RegimeClassifier.classify(h_feats, a_feats, lambdas['total_expected_goals'])
    print(f"[✓] Régimen dominante: {regimes[1]['regime']} ({round(regimes[1]['probability']*100, 1)}%)")

    # 5. Monte Carlo (10.000 iteraciones)
    sim = MonteCarloSimulator(n_simulations=10000)
    res = sim.run_simulation(lambdas['home_lambda'], lambdas['away_lambda'])
    win_p = res['win_probabilities']
    print(f"[✓] Monte Carlo 10k - 1X2: Local {round(win_p['home_win']*100, 1)}% | Empate {round(win_p['draw']*100, 1)}% | Visitante {round(win_p['away_win']*100, 1)}%")
    print(f"[✓] Marcador más probable: {res['most_likely_scores'][0]['score']} ({round(res['most_likely_scores'][0]['probability']*100, 1)}%)")

    # 6. Uncertainty
    unc = UncertaintyEngine.evaluate(h_feats, a_feats, res)
    print(f"[✓] Nivel de Incertidumbre: {unc['level']} (Score: {unc['confidence_score']}/100)")

    conn.close()
    print("\n[✓] ¡TODOS LOS TESTS PASARON EXITOSAMENTE! Motor listo para producción.")

if __name__ == "__main__":
    test_pipeline()
