import math
from typing import Dict, Any, List

class DixonColesModel:
    """
    Modelo Poisson Bivariado con Ajuste de Dixon-Coles (1997).
    Corrige la sobrestimación/subestimación en marcadores bajos (0-0, 1-0, 0-1, 1-1).
    """

    def __init__(self, rho: float = -0.11):
        self.rho = rho

    @staticmethod
    def _poisson_pmf(k: int, lamb: float) -> float:
        if lamb <= 0:
            return 1.0 if k == 0 else 0.0
        return (math.exp(-lamb) * (lamb ** k)) / math.factorial(k)

    def _tau(self, x: int, y: int, lambda_h: float, lambda_a: float) -> float:
        if x == 0 and y == 0:
            return 1.0 - (lambda_h * lambda_a * self.rho)
        elif x == 0 and y == 1:
            return 1.0 + (lambda_h * self.rho)
        elif x == 1 and y == 0:
            return 1.0 + (lambda_a * self.rho)
        elif x == 1 and y == 1:
            return 1.0 - self.rho
        else:
            return 1.0

    def compute_bivariate_matrix(self, lambda_h: float, lambda_a: float, max_goals: int = 8) -> List[List[float]]:
        matrix = []
        total_p = 0.0

        for h in range(max_goals + 1):
            row = []
            p_h = self._poisson_pmf(h, lambda_h)
            for a in range(max_goals + 1):
                p_a = self._poisson_pmf(a, lambda_a)
                adj = self._tau(h, a, lambda_h, lambda_a)
                p = max(0.0, p_h * p_a * adj)
                row.append(p)
                total_p += p
            matrix.append(row)

        # Normalizar para asegurar suma = 1.0
        if total_p > 0:
            for h in range(max_goals + 1):
                for a in range(max_goals + 1):
                    matrix[h][a] /= total_p

        return matrix
