from typing import Dict, Any, List

class RegimeClassifier:
    """
    Clasificador de Regímenes de Partido (Match Regimes).
    Descompone el partido en 5 estados contextuales plausibles:
    - LOW_EVENT: Partido trabado, pocas ocasiones, alta disciplina táctica.
    - NORMAL: Dinámica estándar de liga.
    - OPEN_GAME: Partido de transiciones rápidas, ida y vuelta con alto volumen ofensivo.
    - HIGH_DOMINANCE: Asimetría marcada entre un equipo dominante y uno replegado.
    - CHAOTIC: Alta volatilidad, faltas, tarjetas e imprevisibilidad.
    """

    @staticmethod
    def classify(
        home_features: Dict[str, Any],
        away_features: Dict[str, Any],
        total_lambda: float,
        override: str = None
    ) -> List[Dict[str, Any]]:
        if override:
            return [{
                "regime": override,
                "probability": 1.0,
                "description": f"Régimen forzado manualmente en Scenario Lab: {override}"
            }]

        h_att = home_features.get('attack_strength', 1.0)
        a_att = away_features.get('attack_strength', 1.0)
        h_def = home_features.get('defense_strength', 1.0)
        a_def = away_features.get('defense_strength', 1.0)

        ratio = (h_att / a_att) if a_att > 0 else 1.5

        # Heurística estocástica basada en tasas de goles y asimetría
        p_low = 0.15
        p_normal = 0.40
        p_open = 0.25
        p_dominant = 0.12
        p_chaotic = 0.08

        if total_lambda < 2.0:
            p_low += 0.25
            p_open -= 0.15
            p_normal -= 0.10
        elif total_lambda > 3.1:
            p_open += 0.30
            p_low -= 0.10
            p_normal -= 0.15

        if ratio > 1.8 or ratio < 0.55:
            p_dominant += 0.25
            p_normal -= 0.15

        # Normalizar probabilidades
        weights = [max(0.05, p_low), max(0.10, p_normal), max(0.05, p_open), max(0.05, p_dominant), max(0.05, p_chaotic)]
        total = sum(weights)
        norm = [w / total for w in weights]

        return [
            {
                "regime": "LOW_EVENT",
                "probability": round(norm[0], 3),
                "description": "Partido cerrado, control táctico y bajo volumen de ocasiones netas."
            },
            {
                "regime": "NORMAL",
                "probability": round(norm[1], 3),
                "description": "Desarrollo equilibrado conforme a los promedios históricos de la competición."
            },
            {
                "regime": "OPEN_GAME",
                "probability": round(norm[2], 3),
                "description": "Ritmo acelerado, transiciones directas y alto intercambio de tiros."
            },
            {
                "regime": "HIGH_DOMINANCE",
                "probability": round(norm[3], 3),
                "description": "Monopolio territorial y de posesión por parte del equipo favorito."
            },
            {
                "regime": "CHAOTIC",
                "probability": round(norm[4], 3),
                "description": "Escenario de alta varianza, interrupciones, tarjetas e incidentes críticos."
            }
        ]
