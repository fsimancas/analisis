from typing import Dict, Any

class DeterministicCore:
    """
    Núcleo Determinista de Goles Esperados (Expected Goals - Base Rates).
    Calcula lambda_home y lambda_away usando tasas base, fortalezas relativas
    y ajustes contextuales de localía y forma.
    """

    @staticmethod
    def calculate_lambdas(
        home_features: Dict[str, Any],
        away_features: Dict[str, Any],
        home_attack_adj: float = 0.0,
        away_attack_adj: float = 0.0,
        home_defense_adj: float = 0.0,
        away_defense_adj: float = 0.0
    ) -> Dict[str, float]:
        baselines = home_features.get('league_baselines', {})
        base_h = baselines.get('avg_home_goals', 1.45)
        base_a = baselines.get('avg_away_goals', 1.15)

        h_att = home_features.get('attack_strength', 1.0) * (1.0 + home_attack_adj)
        a_def = away_features.get('defense_strength', 1.0) * (1.0 + away_defense_adj)

        a_att = away_features.get('attack_strength', 1.0) * (1.0 + away_attack_adj)
        h_def = home_features.get('defense_strength', 1.0) * (1.0 + home_defense_adj)

        # Multiplicación estocástica estándar
        lambda_h = base_h * h_att * a_def
        lambda_a = base_a * a_att * h_def

        # Suavizado y límites fisiológicos de fútbol profesional
        lambda_h = max(0.15, min(5.50, lambda_h))
        lambda_a = max(0.15, min(5.50, lambda_a))

        return {
            "home_lambda": round(lambda_h, 3),
            "away_lambda": round(lambda_a, 3),
            "total_expected_goals": round(lambda_h + lambda_a, 3)
        }
