import math
import sqlite3
from datetime import datetime
from typing import Dict, Any, List, Optional

class TeamFeatureExtractor:
    """
    Extractor de características a nivel de equipo con estricta adherencia temporal (t < t_m).
    Diseñado para el esquema SQLite de ESPN (matches, match_competitors, match_team_stats).
    Implementa decaimiento exponencial y manejo de datos incompletos (Graceful Degradation).
    """

    def __init__(self, db_conn: sqlite3.Connection):
        self.conn = db_conn
        self.conn.row_factory = sqlite3.Row

    def get_league_baselines(self, competition_id: int, cutoff_date: str) -> Dict[str, float]:
        """
        Calcula las tasas base de la liga antes de la fecha de corte.
        """
        cur = self.conn.cursor()
        query = """
            SELECT 
                COUNT(m.id) as total_matches,
                SUM(mc_home.score) as total_home_goals,
                SUM(mc_away.score) as total_away_goals
            FROM matches m
            JOIN match_competitors mc_home ON m.id = mc_home.match_id AND mc_home.home_away = 'home'
            JOIN match_competitors mc_away ON m.id = mc_away.match_id AND mc_away.home_away = 'away'
            WHERE m.competition_id = ?
              AND m.start_time < ?
              AND mc_home.score IS NOT NULL
              AND mc_away.score IS NOT NULL
        """
        cur.execute(query, (competition_id, cutoff_date))
        row = cur.fetchone()

        total_m = row['total_matches'] if row and row['total_matches'] else 0
        if total_m == 0:
            # Fallback seguro para competiciones que inician
            return {
                "avg_home_goals": 1.45,
                "avg_away_goals": 1.15,
                "avg_total_goals": 2.60,
                "home_advantage": 1.26
            }

        avg_h = (row['total_home_goals'] or 0) / total_m
        avg_a = (row['total_away_goals'] or 0) / total_m
        avg_tot = avg_h + avg_a
        h_adv = (avg_h / avg_a) if avg_a > 0 else 1.20

        return {
            "avg_home_goals": round(avg_h, 3),
            "avg_away_goals": round(avg_a, 3),
            "avg_total_goals": round(avg_tot, 3),
            "home_advantage": round(h_adv, 3)
        }

    def extract_features(
        self,
        team_id: int,
        competition_id: int,
        cutoff_date: str,
        decay_lambda: float = 0.005
    ) -> Dict[str, Any]:
        """
        Extrae características agregadas y ventanas móviles para un equipo antes de cutoff_date.
        """
        cur = self.conn.cursor()

        # Query temporal estricto anti-leakage
        query = """
            SELECT 
                m.id as match_id,
                m.start_time,
                mc_team.home_away,
                mc_team.score as goals_scored,
                mc_opp.score as goals_conceded,
                mts.shots,
                mts.shots_on_target,
                mts.corners,
                mts.possession,
                mts.fouls,
                mts.yellow_cards,
                mts.red_cards,
                mts.saves
            FROM matches m
            JOIN match_competitors mc_team ON m.id = mc_team.match_id AND mc_team.team_id = ?
            JOIN match_competitors mc_opp ON m.id = mc_opp.match_id AND mc_opp.team_id != ?
            LEFT JOIN match_team_stats mts ON m.id = mts.match_id AND mts.team_id = ?
            WHERE m.competition_id = ?
              AND m.start_time < ?
              AND mc_team.score IS NOT NULL
              AND mc_opp.score IS NOT NULL
            ORDER BY m.start_time DESC
        """
        cur.execute(query, (team_id, team_id, team_id, competition_id, cutoff_date))
        rows = cur.fetchall()

        sample_size = len(rows)
        if sample_size == 0:
            return self._build_empty_fallback_features(team_id, cutoff_date)

        # Parsear fecha de corte para calcular días transcurridos
        try:
            cutoff_dt = datetime.fromisoformat(cutoff_date.replace("Z", "+00:00"))
        except Exception:
            cutoff_dt = datetime.now()

        # Calcular métricas ponderadas por decaimiento exponencial
        weighted_scored = 0.0
        weighted_conceded = 0.0
        total_weight = 0.0

        stats_available_count = 0
        total_shots = 0.0
        total_sot = 0.0
        total_corners = 0.0
        total_possession = 0.0
        total_fouls = 0.0

        # Ventanas móviles
        recent_3_scored, recent_3_conceded = [], []
        recent_5_scored, recent_5_conceded = [], []
        recent_10_scored, recent_10_conceded = [], []

        for idx, r in enumerate(rows):
            g_s = float(r['goals_scored'] or 0)
            g_c = float(r['goals_conceded'] or 0)

            # Cálculo de decaimiento temporal
            try:
                m_dt = datetime.fromisoformat(str(r['start_time']).replace("Z", "+00:00"))
                days_diff = max(0.0, (cutoff_dt - m_dt).total_seconds() / 86400.0)
            except Exception:
                days_diff = float(idx * 7)

            weight = math.exp(-decay_lambda * days_diff)
            total_weight += weight
            weighted_scored += g_s * weight
            weighted_conceded += g_c * weight

            # Ventanas móviles
            if idx < 3:
                recent_3_scored.append(g_s)
                recent_3_conceded.append(g_c)
            if idx < 5:
                recent_5_scored.append(g_s)
                recent_5_conceded.append(g_c)
            if idx < 10:
                recent_10_scored.append(g_s)
                recent_10_conceded.append(g_c)

            # Estadísticas avanzadas si existen
            if r['shots'] is not None:
                stats_available_count += 1
                total_shots += float(r['shots'] or 0)
                total_sot += float(r['shots_on_target'] or 0)
                total_corners += float(r['corners'] or 0)
                total_possession += float(r['possession'] or 50.0)
                total_fouls += float(r['fouls'] or 0)

        # Medias
        avg_scored_decay = weighted_scored / total_weight if total_weight > 0 else 1.0
        avg_conceded_decay = weighted_conceded / total_weight if total_weight > 0 else 1.0

        baselines = self.get_league_baselines(competition_id, cutoff_date)
        league_avg = baselines['avg_total_goals'] / 2.0 if baselines['avg_total_goals'] > 0 else 1.30

        # Fuerza relativa de ataque y defensa
        att_strength = avg_scored_decay / league_avg if league_avg > 0 else 1.0
        def_strength = avg_conceded_decay / league_avg if league_avg > 0 else 1.0

        has_advanced_stats = (stats_available_count > 0)
        adv_denom = float(stats_available_count) if has_advanced_stats else 1.0

        shots_avg = total_shots / adv_denom if has_advanced_stats else None
        sot_avg = total_sot / adv_denom if has_advanced_stats else None
        corners_avg = total_corners / adv_denom if has_advanced_stats else None
        possession_avg = total_possession / adv_denom if has_advanced_stats else None
        fouls_avg = total_fouls / adv_denom if has_advanced_stats else None

        shots_conv = (avg_scored_decay / shots_avg) if (has_advanced_stats and shots_avg and shots_avg > 0) else None

        return {
            "team_id": team_id,
            "cutoff_date": cutoff_date,
            "sample_size": sample_size,
            "has_advanced_stats": has_advanced_stats,
            "advanced_stats_coverage_pct": round((stats_available_count / sample_size) * 100, 1),
            "attack_strength": round(att_strength, 3),
            "defense_strength": round(def_strength, 3),
            "weighted_goals_scored_avg": round(avg_scored_decay, 2),
            "weighted_goals_conceded_avg": round(avg_conceded_decay, 2),
            "rolling_3": {
                "goals_scored_avg": round(sum(recent_3_scored) / len(recent_3_scored), 2) if recent_3_scored else 0.0,
                "goals_conceded_avg": round(sum(recent_3_conceded) / len(recent_3_conceded), 2) if recent_3_conceded else 0.0
            },
            "rolling_5": {
                "goals_scored_avg": round(sum(recent_5_scored) / len(recent_5_scored), 2) if recent_5_scored else 0.0,
                "goals_conceded_avg": round(sum(recent_5_conceded) / len(recent_5_conceded), 2) if recent_5_conceded else 0.0
            },
            "rolling_10": {
                "goals_scored_avg": round(sum(recent_10_scored) / len(recent_10_scored), 2) if recent_10_scored else 0.0,
                "goals_conceded_avg": round(sum(recent_10_conceded) / len(recent_10_conceded), 2) if recent_10_conceded else 0.0
            },
            "shots_avg": round(shots_avg, 2) if shots_avg is not None else None,
            "shots_on_target_avg": round(sot_avg, 2) if sot_avg is not None else None,
            "shots_conversion_rate": round(shots_conv, 3) if shots_conv is not None else None,
            "corners_avg": round(corners_avg, 2) if corners_avg is not None else None,
            "possession_avg": round(possession_avg, 1) if possession_avg is not None else None,
            "fouls_avg": round(fouls_avg, 2) if fouls_avg is not None else None,
            "league_baselines": baselines
        }

    def _build_empty_fallback_features(self, team_id: int, cutoff_date: str) -> Dict[str, Any]:
        return {
            "team_id": team_id,
            "cutoff_date": cutoff_date,
            "sample_size": 0,
            "has_advanced_stats": False,
            "advanced_stats_coverage_pct": 0.0,
            "attack_strength": 1.0,
            "defense_strength": 1.0,
            "weighted_goals_scored_avg": 1.25,
            "weighted_goals_conceded_avg": 1.25,
            "rolling_3": {"goals_scored_avg": 1.25, "goals_conceded_avg": 1.25},
            "rolling_5": {"goals_scored_avg": 1.25, "goals_conceded_avg": 1.25},
            "rolling_10": {"goals_scored_avg": 1.25, "goals_conceded_avg": 1.25},
            "shots_avg": None,
            "shots_on_target_avg": None,
            "shots_conversion_rate": None,
            "corners_avg": None,
            "possession_avg": None,
            "fouls_avg": None,
            "league_baselines": {
                "avg_home_goals": 1.45,
                "avg_away_goals": 1.15,
                "avg_total_goals": 2.60,
                "home_advantage": 1.26
            }
        }
