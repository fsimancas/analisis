import json
import sqlite3
from datetime import datetime
from typing import Dict, Any, Optional

from .schemas import (
    ScenarioAdjustmentRequest,
    PredictiveAnalysisResponse,
    ExpectedGoalsSchema,
    WinProbabilitiesSchema,
    MarketsSchema,
    ScoreProbabilitySchema,
    RegimeDistributionSchema,
    UncertaintySchema
)
from .features.team_features import TeamFeatureExtractor
from .models.deterministic import DeterministicCore
from .models.dixon_coles import DixonColesModel
from .models.regimes import RegimeClassifier
from .simulation.monte_carlo import MonteCarloSimulator
from .uncertainty.engine import UncertaintyEngine

class PredictionService:
    """
    Servicio Orquestador de Inteligencia Predictiva (APEX Intelligence Service).
    Ejecuta el pipeline completo de Feature Engineering, Modelado, Simulación y Persistencia.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def get_match_prediction(
        self,
        match_id: int,
        adjustments: Optional[ScenarioAdjustmentRequest] = None
    ) -> PredictiveAnalysisResponse:
        conn = self._get_connection()
        try:
            cur = conn.cursor()

            # 1. Obtener metadatos del partido y competidores
            cur.execute("""
                SELECT 
                    m.id as match_id,
                    m.competition_id,
                    m.season_id,
                    m.start_time,
                    m.status,
                    mc_home.team_id as home_team_id,
                    t_home.name as home_name,
                    mc_away.team_id as away_team_id,
                    t_away.name as away_name
                FROM matches m
                JOIN match_competitors mc_home ON m.id = mc_home.match_id AND mc_home.home_away = 'home'
                JOIN teams t_home ON mc_home.team_id = t_home.id
                JOIN match_competitors mc_away ON m.id = mc_away.match_id AND mc_away.home_away = 'away'
                JOIN teams t_away ON mc_away.team_id = t_away.id
                WHERE m.id = ?
            """, (match_id,))
            match_row = cur.fetchone()

            if not match_row:
                raise ValueError(f"Partido ID {match_id} no encontrado en la base de datos.")

            cutoff_date = match_row['start_time'] or datetime.now().isoformat()
            home_id = match_row['home_team_id']
            away_id = match_row['away_team_id']
            comp_id = match_row['competition_id']
            season_id = match_row['season_id']

            # 2. Extracción de Features (t < t_m estricto anti-leakage)
            extractor = TeamFeatureExtractor(conn)
            home_feats = extractor.extract_features(home_id, comp_id, cutoff_date)
            away_feats = extractor.extract_features(away_id, comp_id, cutoff_date)

            # Persistir snapshots si no es simulación temporal
            if adjustments is None:
                self._persist_feature_snapshot(conn, home_id, comp_id, season_id, cutoff_date, home_feats)
                self._persist_feature_snapshot(conn, away_id, comp_id, season_id, cutoff_date, away_feats)

            # 3. Núcleo Determinista
            h_att_adj = adjustments.home_attack_adjustment if adjustments else 0.0
            a_att_adj = adjustments.away_attack_adjustment if adjustments else 0.0
            h_def_adj = adjustments.home_defense_adjustment if adjustments else 0.0
            a_def_adj = adjustments.away_defense_adjustment if adjustments else 0.0
            volatility = adjustments.volatility if adjustments else 0.0
            regime_override = adjustments.regime_override if adjustments else None

            lambdas = DeterministicCore.calculate_lambdas(
                home_features=home_feats,
                away_features=away_feats,
                home_attack_adj=h_att_adj,
                away_attack_adj=a_att_adj,
                home_defense_adj=h_def_adj,
                away_defense_adj=a_def_adj
            )

            # 4. Modelo Dixon-Coles (Distribución Bivariada)
            dc = DixonColesModel(rho=-0.11)
            bivariate_matrix = dc.compute_bivariate_matrix(lambdas['home_lambda'], lambdas['away_lambda'])

            # 5. Regímenes de Partido
            regimes = RegimeClassifier.classify(
                home_features=home_feats,
                away_features=away_feats,
                total_lambda=lambdas['total_expected_goals'],
                override=regime_override
            )

            # 6. Simulación Monte Carlo (10.000 escenarios)
            simulator = MonteCarloSimulator(n_simulations=10000)
            sim_res = simulator.run_simulation(
                lambda_h=lambdas['home_lambda'],
                lambda_a=lambdas['away_lambda'],
                volatility=volatility
            )

            # 7. Evaluación de Incertidumbre
            uncertainty_res = UncertaintyEngine.evaluate(home_feats, away_feats, sim_res)

            # 8. Persistir Análisis Inmutable en SQLite
            if adjustments is None:
                self._persist_predictive_analysis(
                    conn=conn,
                    match_id=match_id,
                    cutoff_date=cutoff_date,
                    deterministic=lambdas,
                    probabilistic={"dixon_coles_bivariate": bivariate_matrix},
                    scenario={"regimes": regimes},
                    simulation=sim_res,
                    uncertainty=uncertainty_res,
                    confidence=uncertainty_res['confidence_score']
                )

            # 9. Construir respuesta estricta tipada
            return PredictiveAnalysisResponse(
                match_id=match_id,
                home_team=match_row['home_name'],
                away_team=match_row['away_name'],
                competition_id=comp_id,
                season_id=season_id,
                cutoff_date=cutoff_date,
                status="READY",
                expected_goals=ExpectedGoalsSchema(
                    home=lambdas['home_lambda'],
                    away=lambdas['away_lambda'],
                    total=lambdas['total_expected_goals']
                ),
                win_probabilities=WinProbabilitiesSchema(
                    home_win=sim_res['win_probabilities']['home_win'],
                    draw=sim_res['win_probabilities']['draw'],
                    away_win=sim_res['win_probabilities']['away_win']
                ),
                markets=MarketsSchema(**sim_res['markets']),
                most_likely_scores=[ScoreProbabilitySchema(**s) for s in sim_res['most_likely_scores']],
                regimes=[RegimeDistributionSchema(**r) for r in regimes],
                uncertainty=UncertaintySchema(**uncertainty_res),
                models_evaluated=["DeterministicCore", "DixonColesBivariate", "RegimeClassifier", "MonteCarlo10k"]
            )

        finally:
            conn.close()

    def _persist_feature_snapshot(
        self,
        conn: sqlite3.Connection,
        team_id: int,
        comp_id: int,
        season_id: Optional[int],
        cutoff_date: str,
        payload: Dict[str, Any]
    ):
        try:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO feature_snapshots (team_id, competition_id, season_id, cutoff_date, feature_version, payload)
                VALUES (?, ?, ?, ?, 'v1.0', ?)
            """, (team_id, comp_id, season_id, cutoff_date, json.dumps(payload)))
            conn.commit()
        except Exception:
            pass  # Si la tabla no existe o falla, no bloquea el flujo principal

    def _persist_predictive_analysis(
        self,
        conn: sqlite3.Connection,
        match_id: int,
        cutoff_date: str,
        deterministic: Dict[str, Any],
        probabilistic: Dict[str, Any],
        scenario: Dict[str, Any],
        simulation: Dict[str, Any],
        uncertainty: Dict[str, Any],
        confidence: int
    ):
        try:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO predictive_analyses (
                    match_id, analysis_version, status, data_cutoff_at,
                    deterministic_result, probabilistic_result, scenario_result,
                    simulation_result, uncertainty_result, confidence_score
                )
                VALUES (?, 'v1.0', 'READY', ?, ?, ?, ?, ?, ?, ?)
            """, (
                match_id,
                cutoff_date,
                json.dumps(deterministic),
                json.dumps(probabilistic),
                json.dumps(scenario),
                json.dumps(simulation),
                json.dumps(uncertainty),
                confidence
            ))
            conn.commit()
        except Exception:
            pass
