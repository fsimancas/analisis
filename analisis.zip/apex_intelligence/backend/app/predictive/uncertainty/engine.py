from typing import Dict, Any

class UncertaintyEngine:
    """
    Motor de Incertidumbre y Calidad de la Predicción (APEX Uncertainty Engine).
    Evalúa la confiabilidad matemática del pronóstico sin inventar datos:
    - Penaliza muestras pequeñas (< 5 partidos).
    - Penaliza ausencia de estadísticas avanzadas en match_team_stats.
    - Asigna una categoría cualitativa: ALTA, MEDIA o BAJA.
    """

    @staticmethod
    def evaluate(
        home_features: Dict[str, Any],
        away_features: Dict[str, Any],
        monte_carlo_res: Dict[str, Any]
    ) -> Dict[str, Any]:
        score = 100
        reasons = []

        h_samples = home_features.get('sample_size', 0)
        a_samples = away_features.get('sample_size', 0)
        min_samples = min(h_samples, a_samples)

        # 1. Penalización por tamaño de muestra
        if min_samples < 3:
            score -= 35
            reasons.append(f"Muestra histórica insuficiente ({min_samples} partidos previos).")
        elif min_samples < 6:
            score -= 20
            reasons.append(f"Muestra inicial en desarrollo ({min_samples} partidos analizados).")
        elif min_samples < 10:
            score -= 10

        # 2. Penalización por ausencia de estadísticas avanzadas (tiros, corners, posesión)
        has_adv_h = home_features.get('has_advanced_stats', False)
        has_adv_a = away_features.get('has_advanced_stats', False)

        if not has_adv_h or not has_adv_a:
            score -= 25
            reasons.append("Estadísticas de tiros y posesión no disponibles en SQLite para estos equipos; operando exclusivamente con resultados y goles históricos.")
        else:
            cov_h = home_features.get('advanced_stats_coverage_pct', 0)
            cov_a = away_features.get('advanced_stats_coverage_pct', 0)
            avg_cov = (cov_h + cov_a) / 2.0
            if avg_cov < 50.0:
                score -= 10
                reasons.append(f"Cobertura parcial de estadísticas avanzadas ({round(avg_cov, 1)}%).")

        # 3. Dispersión estocástica (entropía del 1X2)
        win_p = monte_carlo_res.get('win_probabilities', {})
        max_p = max(win_p.get('home_win', 0), win_p.get('draw', 0), win_p.get('away_win', 0))
        if max_p < 0.40:
            score -= 5
            reasons.append("Encuentro altamente parejo con dispersión simétrica de probabilidades.")

        score = max(20, min(95, score))

        if score >= 75:
            level = "HIGH"
        elif score >= 55:
            level = "MEDIUM"
        else:
            level = "LOW"

        explanation = " ".join(reasons) if reasons else "Datos completos y estables con amplia cobertura histórica y métricas avanzadas."

        return {
            "confidence_score": score,
            "level": level,
            "sample_size_matches": min_samples,
            "has_advanced_stats": (has_adv_h and has_adv_a),
            "explanation": explanation
        }
