import os
from fastapi import APIRouter, HTTPException, Depends
from typing import Optional

from .schemas import PredictiveAnalysisResponse, ScenarioAdjustmentRequest
from .service import PredictionService

router = APIRouter(prefix="/api/v1/predict", tags=["APEX Predictive Intelligence"])

# Ruta por defecto a la base SQLite de Apex Analytics
DEFAULT_DB_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "storage", "db.sqlite3")
)

def get_prediction_service() -> PredictionService:
    db_path = os.getenv("SQLITE_DB_PATH", DEFAULT_DB_PATH)
    return PredictionService(db_path=db_path)

@router.get(
    "/matches/{match_id}",
    response_model=PredictiveAnalysisResponse,
    summary="Obtener Análisis Predictivo Completo de un Partido"
)
def get_match_prediction_endpoint(
    match_id: int,
    service: PredictionService = Depends(get_prediction_service)
):
    """
    Devuelve probabilidades 1X2, xG esperados, mercados de goles,
    matriz de marcadores, regímenes y nivel de incertidumbre
    con estricto corte temporal anti-leakage (t < t_m).
    """
    try:
        return service.get_match_prediction(match_id=match_id)
    except ValueError as ve:
        raise HTTPException(status_code=404, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error en el motor predictivo: {str(e)}")

@router.post(
    "/matches/{match_id}/scenario",
    response_model=PredictiveAnalysisResponse,
    summary="Simulación Interactiva en Scenario Lab (Monte Carlo en Memoria)"
)
def run_scenario_simulation_endpoint(
    match_id: int,
    adjustments: ScenarioAdjustmentRequest,
    service: PredictionService = Depends(get_prediction_service)
):
    """
    Permite modificar en tiempo real el ataque, defensa o volatilidad
    y re-ejecutar 10.000 iteraciones Monte Carlo en memoria devolviendo
    las nuevas probabilidades reactivas en < 50ms.
    """
    try:
        return service.get_match_prediction(match_id=match_id, adjustments=adjustments)
    except ValueError as ve:
        raise HTTPException(status_code=404, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al simular escenario: {str(e)}")
