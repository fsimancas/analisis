import random
import math
from typing import Dict, Any, List

class MonteCarloSimulator:
    """
    Simulador Estocástico Monte Carlo (N=10.000 iteraciones).
    Capaz de ejecutarse en memoria en < 30ms utilizando generación estocástica Poisson pura.
    Permite ajustes en tiempo real para el Scenario Lab.
    """

    def __init__(self, n_simulations: int = 10000):
        self.n_sims = n_simulations

    @staticmethod
    def _poisson_knuth(lamb: float) -> int:
        """Algoritmo de Knuth para muestreo de Poisson en O(lambda)."""
        if lamb <= 0:
            return 0
        limit = math.exp(-lamb)
        k = 0
        p = 1.0
        while p > limit:
            k += 1
            p *= random.random()
        return k - 1

    def run_simulation(
        self,
        lambda_h: float,
        lambda_a: float,
        volatility: float = 0.0
    ) -> Dict[str, Any]:
        h_wins = 0
        draws = 0
        a_wins = 0

        over_1_5 = 0
        over_2_5 = 0
        over_3_5 = 0
        btts = 0

        score_counts: Dict[str, int] = {}
        matrix = [[0] * 7 for _ in range(7)]

        # Ajuste por volatilidad
        sd_factor = 1.0 + max(0.0, volatility)

        for _ in range(self.n_sims):
            # Muestreo estocástico con leve perturbación aleatoria por volatilidad
            l_h = max(0.05, lambda_h * (1.0 + random.gauss(0, 0.12 * sd_factor))) if volatility > 0 else lambda_h
            l_a = max(0.05, lambda_a * (1.0 + random.gauss(0, 0.12 * sd_factor))) if volatility > 0 else lambda_a

            gh = self._poisson_knuth(l_h)
            ga = self._poisson_knuth(l_a)

            # 1X2
            if gh > ga:
                h_wins += 1
            elif gh == ga:
                draws += 1
            else:
                a_wins += 1

            # Mercados
            tot = gh + ga
            if tot > 1.5:
                over_1_5 += 1
            if tot > 2.5:
                over_2_5 += 1
            if tot > 3.5:
                over_3_5 += 1

            if gh > 0 and ga > 0:
                btts += 1

            # Marcador exacto
            sc = f"{gh}-{ga}"
            score_counts[sc] = score_counts.get(sc, 0) + 1

            if gh < 7 and ga < 7:
                matrix[gh][ga] += 1

        n = float(self.n_sims)

        # Top 5 marcadores más probables
        sorted_scores = sorted(score_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        top_scores = []
        for sc, cnt in sorted_scores:
            parts = [int(p) for p in sc.split("-")]
            top_scores.append({
                "score": sc,
                "home_goals": parts[0],
                "away_goals": parts[1],
                "probability": round(cnt / n, 4)
            })

        # Matriz 7x7 normalizada
        norm_matrix = [[round(matrix[h][a] / n, 4) for a in range(7)] for h in range(7)]

        return {
            "iterations": self.n_sims,
            "win_probabilities": {
                "home_win": round(h_wins / n, 4),
                "draw": round(draws / n, 4),
                "away_win": round(a_wins / n, 4)
            },
            "markets": {
                "over_1_5": round(over_1_5 / n, 4),
                "under_1_5": round((self.n_sims - over_1_5) / n, 4),
                "over_2_5": round(over_2_5 / n, 4),
                "under_2_5": round((self.n_sims - over_2_5) / n, 4),
                "over_3_5": round(over_3_5 / n, 4),
                "under_3_5": round((self.n_sims - over_3_5) / n, 4),
                "btts_yes": round(btts / n, 4),
                "btts_no": round((self.n_sims - btts) / n, 4)
            },
            "most_likely_scores": top_scores,
            "score_matrix": norm_matrix
        }
