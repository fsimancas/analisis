from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

class ScenarioAdjustmentRequest(BaseModel):
    home_attack_adjustment: float = Field(0.0, description="Porcentaje de ajuste en ataque local (ej: 0.15 = +15%)")
    away_attack_adjustment: float = Field(0.0, description="Porcentaje de ajuste en ataque visitante (ej: -0.10 = -10%)")
    home_defense_adjustment: float = Field(0.0, description="Porcentaje de ajuste en defensa local")
    away_defense_adjustment: float = Field(0.0, description="Porcentaje de ajuste en defensa visitante")
    volatility: float = Field(0.0, description="Incremento de dispersión estocástica")
    regime_override: Optional[str] = Field(None, description="Forzar régimen: LOW_EVENT, NORMAL, OPEN_GAME, HIGH_DOMINANCE, CHAOTIC")

class ExpectedGoalsSchema(BaseModel):
    home: float
    away: float
    total: float

class WinProbabilitiesSchema(BaseModel):
    home_win: float
    draw: float
    away_win: float

class MarketsSchema(BaseModel):
    over_1_5: float
    under_1_5: float
    over_2_5: float
    under_2_5: float
    over_3_5: float
    under_3_5: float
    btts_yes: float
    btts_no: float

class ScoreProbabilitySchema(BaseModel):
    score: str
    home_goals: int
    away_goals: int
    probability: float

class RegimeDistributionSchema(BaseModel):
    regime: str
    probability: float
    description: str

class UncertaintySchema(BaseModel):
    confidence_score: int
    level: str  # HIGH, MEDIUM, LOW
    sample_size_matches: int
    has_advanced_stats: bool
    explanation: str

class PredictiveAnalysisResponse(BaseModel):
    match_id: int
    home_team: str
    away_team: str
    competition_id: int
    season_id: Optional[int] = None
    cutoff_date: str
    status: str
    expected_goals: ExpectedGoalsSchema
    win_probabilities: WinProbabilitiesSchema
    markets: MarketsSchema
    most_likely_scores: List[ScoreProbabilitySchema]
    regimes: List[RegimeDistributionSchema]
    uncertainty: UncertaintySchema
    models_evaluated: List[str]
