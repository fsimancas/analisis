# APEX Intelligence - Módulo Predictivo (Guía de Integración)

Este paquete contiene la implementación completa del **Módulo de Inteligencia Predictiva (APEX Intelligence)** diseñado para integrarse directamente en **Apex Analytics** (`backend/storage/db.sqlite3` y frontend TanStack/React).

---

## 1. Estructura de Archivos Generados

```text
apex_intelligence/
├── migrations/
│   └── 001_create_predictive_tables.sql       # Tablas feature_snapshots y predictive_analyses
│
├── backend/app/predictive/                    # Módulo Backend FastAPI
│   ├── __init__.py
│   ├── schemas.py                             # Esquemas Pydantic v2
│   ├── features/
│   │   ├── __init__.py
│   │   └── team_features.py                   # Extractor temporal t < t_m con decaimiento exponencial
│   ├── models/
│   │   ├── __init__.py
│   │   ├── deterministic.py                   # xG base rates y fuerzas relativas
│   │   ├── dixon_coles.py                     # Poisson bivariado y ajuste tau(rho)
│   │   └── regimes.py                         # Clasificador de 5 regímenes de partido
│   ├── simulation/
│   │   ├── __init__.py
│   │   └── monte_carlo.py                     # 10.000 iteraciones en memoria (< 30ms)
│   ├── uncertainty/
│   │   ├── __init__.py
│   │   └── engine.py                          # Score de confianza (0-100) y degradación de features
│   ├── service.py                             # Orquestador del pipeline y persistencia
│   └── router.py                              # Endpoints FastAPI: GET /matches y POST /scenario
│
└── frontend/src/                              # Módulo Frontend TanStack / React
    ├── lib/api/
    │   └── predictive.ts                      # Cliente API tipado (fetcher)
    ├── hooks/
    │   └── use-match-prediction.ts            # Hook con @tanstack/react-query
    ├── components/predictive/
    │   ├── uncertainty-badge.tsx              # Badge de confianza y explicación de datos
    │   ├── prediction-summary.tsx             # 1X2 barras porcentuales y xG esperados
    │   ├── score-matrix.tsx                   # Top 5 marcadores más probables
    │   ├── markets-card.tsx                   # Over/Under 1.5, 2.5, 3.5 y BTTS
    │   └── scenario-lab.tsx                   # Sliders interactivos para variar ataque/volatilidad
    └── routes/predict/match/
        └── $matchId.tsx                       # Página TanStack Router (/predict/match/:matchId)
```

---

## 2. Pasos para Copiar a tu Repositorio Apex Analytics

### Backend:
1. Copiá la carpeta `apex_intelligence/backend/app/predictive/` a:
   `apex-analytics-main - original/backend/app/predictive/`
2. En tu archivo principal de FastAPI (`backend/app/main.py`), registrá el router:
   ```python
   from app.predictive.router import router as predictive_router
   app.include_router(predictive_router)
   ```
3. Ejecutá la migración SQLite sobre `backend/storage/db.sqlite3`:
   ```bash
   sqlite3 backend/storage/db.sqlite3 < migrations/001_create_predictive_tables.sql
   ```

### Frontend:
1. Copiá `apex_intelligence/frontend/src/` dentro de `apex-analytics-main - original/frontend/src/`.
2. Tu servidor de desarrollo Vite/TanStack detectará automáticamente la nueva ruta:
   `/predict/match/$matchId`
3. En la vista existente del partido (`matches/$matchId`), agregá un botón o enlace:
   ```tsx
   <Link to="/predict/match/$matchId" params={{ matchId }}>
     Ver Inteligencia Predictiva (APEX)
   </Link>
   ```
