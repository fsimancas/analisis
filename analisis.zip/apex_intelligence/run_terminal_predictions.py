import os
import sys
import re
import argparse
import sqlite3
from typing import Dict, Any, List, Optional

# Ensure project root is in sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(CURRENT_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from apex_intelligence.backend.app.predictive.models.deterministic import DeterministicCore
from apex_intelligence.backend.app.predictive.models.dixon_coles import DixonColesModel
from apex_intelligence.backend.app.predictive.models.regimes import RegimeClassifier
from apex_intelligence.backend.app.predictive.simulation.monte_carlo import MonteCarloSimulator
from apex_intelligence.backend.app.predictive.uncertainty.engine import UncertaintyEngine

DB_PATH = r"c:\Users\SIMANCAS\Documents\rey\betplay_flashscore.db"

def clean_team_name(name: str) -> str:
    if not name:
        return ""
    name = re.sub(r'GOL$', '', name.strip())
    name = re.sub(r'\s*\([A-Za-z0-9]+\)$', '', name)
    return name.strip()

class TerminalPredictionRunner:
    """
    Ejecutor de Predicciones en Terminal para APEX Intelligence.
    Carga partidos reales de betplay_flashscore.db, extrae métricas históricas (t < t_m),
    ejecuta Dixon-Coles + Monte Carlo (10.000 iteraciones) e imprime el reporte analítico.
    """

    def __init__(self, db_path: str = DB_PATH, n_sims: int = 10000):
        self.db_path = db_path
        self.n_sims = n_sims
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row

    def close(self):
        self.conn.close()

    def get_competition_name(self, comp_id: int) -> str:
        cur = self.conn.cursor()
        cur.execute("SELECT pais_nombre, nombre_flashscore FROM competiciones WHERE id = ?", (comp_id,))
        row = cur.fetchone()
        if row:
            return f"{row['nombre_flashscore']} ({row['pais_nombre']})"
        return f"Competición #{comp_id}"

    def extract_team_stats(self, team_name: str, comp_id: int) -> Dict[str, Any]:
        cur = self.conn.cursor()
        cur.execute("""
            SELECT equipo_local, equipo_visitante, goles_local, goles_visitante
            FROM partidos
            WHERE competicion_id = ?
              AND tipo = 'resultado'
              AND (equipo_local LIKE ? OR equipo_visitante LIKE ?)
              AND goles_local IS NOT NULL
            ORDER BY id DESC
        """, (comp_id, f"%{team_name}%", f"%{team_name}%"))
        rows = cur.fetchall()

        sample_size = len(rows)
        if sample_size == 0:
            return {
                "team": team_name,
                "sample_size": 0,
                "has_advanced_stats": False,
                "attack_strength": 1.0,
                "defense_strength": 1.0,
                "goals_scored_avg": 1.25,
                "goals_conceded_avg": 1.25,
                "league_baselines": {"avg_home_goals": 1.45, "avg_away_goals": 1.15, "avg_total_goals": 2.60}
            }

        scored = []
        conceded = []
        for r in rows:
            h_clean = clean_team_name(r['equipo_local'])
            a_clean = clean_team_name(r['equipo_visitante'])
            gh = int(r['goles_local'])
            ga = int(r['goles_visitante'])

            if team_name.lower() in h_clean.lower():
                scored.append(gh)
                conceded.append(ga)
            else:
                scored.append(ga)
                conceded.append(gh)

        avg_s = sum(scored) / len(scored) if scored else 1.0
        avg_c = sum(conceded) / len(conceded) if conceded else 1.0

        # Liga baseline
        cur.execute("""
            SELECT COUNT(*), SUM(goles_local), SUM(goles_visitante)
            FROM partidos
            WHERE competicion_id = ? AND tipo = 'resultado' AND goles_local IS NOT NULL
        """, (comp_id,))
        l_row = cur.fetchone()
        tot_m = l_row[0] or 1
        l_avg_h = (l_row[1] or 0) / tot_m
        l_avg_a = (l_row[2] or 0) / tot_m
        league_team_avg = (l_avg_h + l_avg_a) / 2.0 if (l_avg_h + l_avg_a) > 0 else 1.30

        att_str = avg_s / league_team_avg if league_team_avg > 0 else 1.0
        def_str = avg_c / league_team_avg if league_team_avg > 0 else 1.0

        return {
            "team": team_name,
            "sample_size": sample_size,
            "has_advanced_stats": True,
            "attack_strength": round(att_str, 3),
            "defense_strength": round(def_str, 3),
            "goals_scored_avg": round(avg_s, 2),
            "goals_conceded_avg": round(avg_c, 2),
            "league_baselines": {
                "avg_home_goals": round(l_avg_h, 2),
                "avg_away_goals": round(l_avg_a, 2),
                "avg_total_goals": round(l_avg_h + l_avg_a, 2)
            }
        }

    def predict_match(
        self,
        home_team: str,
        away_team: str,
        comp_id: int,
        jornada: str = "",
        kickoff: str = "",
        home_att_adj: float = 0.0,
        away_att_adj: float = 0.0,
        volatility: float = 0.0,
        regime_override: Optional[str] = None
    ) -> Dict[str, Any]:
        h_clean = clean_team_name(home_team)
        a_clean = clean_team_name(away_team)

        h_stats = self.extract_team_stats(h_clean, comp_id)
        a_stats = self.extract_team_stats(a_clean, comp_id)

        # 1. Deterministic Core con ajustes de Scenario Lab
        lambdas = DeterministicCore.calculate_lambdas(
            home_features=h_stats,
            away_features=a_stats,
            home_attack_adj=home_att_adj,
            away_attack_adj=away_att_adj
        )

        # 2. Dixon-Coles Bivariate Matrix
        dc = DixonColesModel(rho=-0.11)
        dc_matrix = dc.compute_bivariate_matrix(lambdas['home_lambda'], lambdas['away_lambda'])

        # 3. Regímenes
        regimes = RegimeClassifier.classify(
            home_features=h_stats,
            away_features=a_stats,
            total_lambda=lambdas['total_expected_goals'],
            override=regime_override
        )
        dom_regime = max(regimes, key=lambda x: x['probability'])

        # 4. Monte Carlo (10.000 iteraciones)
        sim = MonteCarloSimulator(n_simulations=self.n_sims)
        res = sim.run_simulation(
            lambda_h=lambdas['home_lambda'],
            lambda_a=lambdas['away_lambda'],
            volatility=volatility
        )

        # 5. Uncertainty
        unc = UncertaintyEngine.evaluate(h_stats, a_stats, res)

        # Renderizar en terminal
        self.render_terminal_card(
            home_team=h_clean,
            away_team=a_clean,
            comp_name=self.get_competition_name(comp_id),
            jornada=jornada,
            kickoff=kickoff,
            lambdas=lambdas,
            res=res,
            dom_regime=dom_regime,
            unc=unc
        )

        return {
            "lambdas": lambdas,
            "simulation": res,
            "regime": dom_regime,
            "uncertainty": unc
        }

    def run_scenario_matrix(self, home_team: str, away_team: str, comp_id: int):
        h_clean = clean_team_name(home_team)
        a_clean = clean_team_name(away_team)

        scenarios = [
            {"name": "BASE (Rendimiento Real)", "h_att": 0.0, "a_att": 0.0, "vol": 0.0, "reg": None},
            {"name": "ESC. 1: +25% Ataque Tottenham", "h_att": 0.25, "a_att": 0.0, "vol": 0.0, "reg": None},
            {"name": "ESC. 2: +25% Ataque Coventry", "h_att": 0.0, "a_att": 0.25, "vol": 0.0, "reg": None},
            {"name": "ESC. 3: Partido Abierto (OPEN_GAME)", "h_att": 0.15, "a_att": 0.15, "vol": 0.15, "reg": "OPEN_GAME"},
            {"name": "ESC. 4: Régimen Caótico (+40% Volatilidad)", "h_att": 0.0, "a_att": 0.0, "vol": 0.40, "reg": "CHAOTIC"}
        ]

        print("\n" + "=" * 90)
        print(f"      APEX INTELLIGENCE · SCENARIO LAB: COMPARATIVA TÁCTICA MULTI-ESCENARIO      ")
        print("=" * 90)
        print(f"Partido: {h_clean.upper()} vs {a_clean.upper()} | {self.get_competition_name(comp_id)}")
        print(f"Iteraciones por escenario: {self.n_sims:,} corridas Monte Carlo en memoria\n")

        print(f"{'ESCENARIO':<32} | {'xG TOT':<6} | {'1 (Local)':<9} | {'X (Emp)':<8} | {'2 (Vis)':<8} | {'-2.5 G':<7} | {'BTTS':<6}")
        print("-" * 90)

        h_stats = self.extract_team_stats(h_clean, comp_id)
        a_stats = self.extract_team_stats(a_clean, comp_id)

        for sc in scenarios:
            lambdas = DeterministicCore.calculate_lambdas(
                home_features=h_stats,
                away_features=a_stats,
                home_attack_adj=sc['h_att'],
                away_attack_adj=sc['a_att']
            )
            sim = MonteCarloSimulator(n_simulations=self.n_sims)
            res = sim.run_simulation(lambdas['home_lambda'], lambdas['away_lambda'], volatility=sc['vol'])

            p = res['win_probabilities']
            m = res['markets']

            p_h = f"{round(p['home_win']*100, 1)}%"
            p_x = f"{round(p['draw']*100, 1)}%"
            p_a = f"{round(p['away_win']*100, 1)}%"
            u25 = f"{round(m['under_2_5']*100, 1)}%"
            btts = f"{round(m['btts_yes']*100, 1)}%"

            print(f"{sc['name']:<32} | {lambdas['total_expected_goals']:<6.2f} | {p_h:<9} | {p_x:<8} | {p_a:<8} | {u25:<7} | {btts:<6}")

        print("=" * 90)

    def render_terminal_card(
        self,
        home_team: str,
        away_team: str,
        comp_name: str,
        jornada: str,
        kickoff: str,
        lambdas: Dict[str, float],
        res: Dict[str, Any],
        dom_regime: Dict[str, Any],
        unc: Dict[str, Any]
    ):
        p = res['win_probabilities']
        m = res['markets']

        print("\n" + "=" * 82)
        print(f"  APEX INTELLIGENCE · MATCH PREDICTOR (MONTE CARLO 10.000 SCENARIOS)")
        print("=" * 82)
        print(f"  PARTIDO:     {home_team.upper()} vs {away_team.upper()}")
        print(f"  COMPETICIÓN: {comp_name} | {jornada} | {kickoff}")
        print(f"  CONFIANZA:   {unc['confidence_score']}% [{unc['level']}] · {unc['explanation']}")
        print("-" * 82)

        # Probabilidades 1X2
        p_h = round(p['home_win'] * 100, 1)
        p_x = round(p['draw'] * 100, 1)
        p_a = round(p['away_win'] * 100, 1)
        print(f"  PROBABILIDADES 1X2:  [1] {home_team}: {p_h}%   |   [X] Empate: {p_x}%   |   [2] {away_team}: {p_a}%")

        # Barra visual
        bar_h = int(p_h / 2.5)
        bar_x = int(p_x / 2.5)
        bar_a = int(p_a / 2.5)
        bar_str = "[" + "#" * bar_h + "=" * bar_x + "." * bar_a + "]"
        print(f"  DISTRIBUCIÓN:        {bar_str.ljust(50)} (#:Local, =:Empate, .:Visitante)")

        # Goles esperados
        print(f"  GOLES ESPERADOS xG:  Local: {lambdas['home_lambda']}  |  Visitante: {lambdas['away_lambda']}  |  Total: {lambdas['total_expected_goals']}")
        print(f"  RÉGIMEN DOMINANTE:   {dom_regime['regime']} ({round(dom_regime['probability']*100, 1)}%) - {dom_regime['description']}")
        print("-" * 82)

        # Mercados y Marcadores
        print("  MERCADOS PRINCIPALES:                     MARCADORES MÁS PROBABLES:")
        scores = res['most_likely_scores'][:4]
        s_lines = [f"{s['score']} ({round(s['probability']*100, 1)}%)" for s in scores]

        print(f"    • Más de 1.5 Goles:   {round(m['over_1_5']*100, 1)}%".ljust(44) + f"1º {s_lines[0] if len(s_lines) > 0 else '-'}")
        print(f"    • Menos de 2.5 Goles: {round(m['under_2_5']*100, 1)}%".ljust(44) + f"2º {s_lines[1] if len(s_lines) > 1 else '-'}")
        print(f"    • Más de 2.5 Goles:   {round(m['over_2_5']*100, 1)}%".ljust(44) + f"3º {s_lines[2] if len(s_lines) > 2 else '-'}")
        print(f"    • Ambos Marcan (Sí):  {round(m['btts_yes']*100, 1)}%".ljust(44) + f"4º {s_lines[3] if len(s_lines) > 3 else '-'}")
        print("=" * 82)

    def predict_next_fixtures(self, comp_id: int, limit: int = 5):
        cur = self.conn.cursor()
        cur.execute("""
            SELECT id, jornada, fecha_hora, equipo_local, equipo_visitante
            FROM partidos
            WHERE competicion_id = ? AND tipo = 'proximo'
            ORDER BY id ASC
            LIMIT ?
        """, (comp_id, limit))
        fixtures = cur.fetchall()

        if not fixtures:
            print(f"[!] No hay partidos próximos registrados para la competición #{comp_id}.")
            return

        print(f"\n[*] Ejecutando APEX Intelligence para los próximos {len(fixtures)} partidos de {self.get_competition_name(comp_id)}...")
        for fix in fixtures:
            self.predict_match(
                home_team=fix['equipo_local'],
                away_team=fix['equipo_visitante'],
                comp_id=comp_id,
                jornada=fix['jornada'] or "",
                kickoff=fix['fecha_hora'] or ""
            )

def main():
    parser = argparse.ArgumentParser(description="APEX Intelligence - Ejecutor Terminal de Predicciones")
    parser.add_argument("--comp", type=int, default=84, help="ID de la competición (84: LaLiga, 126: Premier League)")
    parser.add_argument("--next", type=int, default=3, help="Número de próximos partidos a predecir")
    parser.add_argument("--match", type=str, default=None, help="Partido específico: 'Local vs Visitante'")
    parser.add_argument("--scenario-lab", action="store_true", help="Ejecutar comparativa multi-escenario táctico en Scenario Lab")
    parser.add_argument("--sims", type=int, default=10000, help="Iteraciones Monte Carlo (default: 10,000)")
    args = parser.parse_args()

    runner = TerminalPredictionRunner(n_sims=args.sims)
    try:
        if args.match:
            parts = [p.strip() for p in args.match.split("vs")]
            if len(parts) == 2:
                if args.scenario_lab:
                    runner.run_scenario_matrix(parts[0], parts[1], comp_id=args.comp)
                else:
                    runner.predict_match(parts[0], parts[1], comp_id=args.comp, jornada="Partido Personalizado")
            else:
                print("[!] Formato de partido incorrecto. Use: --match 'Local vs Visitante'")
        else:
            runner.predict_next_fixtures(comp_id=args.comp, limit=args.next)
    finally:
        runner.close()

if __name__ == "__main__":
    main()
